.. toctree::
   :maxdepth: 1

   configuring
   watcher
