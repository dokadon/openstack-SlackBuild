/*
 * [The "BSD licence"]
 * Copyright (c) 2005-2008 Terence Parr
 * All rights reserved.
 *
 * Conversion to C#:
 * Copyright (c) 2008-2010 Sam Harwell, Pixel Mine, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace Antlr.Runtime {
    using CLSCompliant = System.CLSCompliantAttribute;

    /** <summary>
     *  Rules that return more than a single value must return an object
     *  containing all the values.  Besides the properties defined in
     *  RuleLabelScope.predefinedRulePropertiesScope there may be user-defined
     *  return values.  This class simply defines the minimum properties that
     *  are always defined and methods to access the others that might be
     *  available depending on output option such as template and tree.
     *  </summary>
     *
     *  <remarks>
     *  Note text is not an actual property of the return value, it is computed
     *  from start and stop using the input stream's toString() method.  I
     *  could add a ctor to this so that we can pass in and store the input
     *  stream, but I'm not sure we want to do that.  It would seem to be undefined
     *  to get the .text property anyway if the rule matches tokens from multiple
     *  input streams.
     *
     *  I do not use getters for fields of objects that are used simply to
     *  group values such as this aggregate.  The getters/setters are there to
     *  satisfy the superclass interface.
     *  </remarks>
     */
    public class ParserRuleReturnScope<TToken> : IRuleReturnScope<TToken>
        where TToken : IToken {
        private TToken _start;
        private TToken _stop;

        public TToken Start {
            get {
                return _start;
            }

            set {
                _start = value;
            }
        }

        public TToken Stop {
            get {
                return _stop;
            }

            set {
                _stop = value;
            }
        }
    }
}
