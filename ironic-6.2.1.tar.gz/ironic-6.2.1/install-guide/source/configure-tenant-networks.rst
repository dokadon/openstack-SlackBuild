.. _configure-tenant-networks:

Configure tenant networks
=========================

See `Multitenancy in Bare Metal service`_.

.. _`Multitenancy in Bare Metal service`: http://docs.openstack.org/developer/ironic/newton/deploy/multitenancy.html#multitenancy
