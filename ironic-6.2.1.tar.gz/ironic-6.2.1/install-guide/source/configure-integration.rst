=========================================
Integration with other OpenStack services
=========================================

.. include:: include/configure-identity.rst

.. include:: include/configure-nova-compute.rst

.. include:: include/configure-nova-flavors.rst

.. include:: include/configure-neutron-networks.rst

.. include:: include/configure-glance-images.rst
