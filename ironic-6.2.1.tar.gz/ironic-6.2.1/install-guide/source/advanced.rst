.. _advanced:

Advanced features
~~~~~~~~~~~~~~~~~

.. include:: include/local-boot-partition-images.rst

.. include:: include/root-device-hints.rst

.. include:: include/kernel-boot-parameters.rst

.. include:: include/trusted-boot.rst
