=============
osc-placement
=============

OpenStackClient plugin for the Placement service

This is an OpenStackClient plugin, that provides CLI for the Placement service.
Python API binding is not implemented - Placement API consumers are encouraged
to use the REST API directly, CLI is provided only for convenience of users.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/osc-placement
* Source: http://git.openstack.org/cgit/openstack/osc-placement
* Bugs: http://bugs.launchpad.net/osc-placement
