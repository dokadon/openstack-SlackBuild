============
Installation
============

At the command line::

    $ pip install paunch

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv paunch
    $ pip install paunch
