"""Barbican Client Library Binding"""
