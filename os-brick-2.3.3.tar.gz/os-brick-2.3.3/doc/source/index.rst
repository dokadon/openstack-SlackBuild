========
os-brick
========

`os-brick` is a Python package containing classes that help with volume
discovery and removal from a host.

Installation Guide
------------------

.. toctree::
   :maxdepth: 2

   install/index

Usage Guide
-----------

.. toctree::
   :maxdepth: 2

   user/tutorial

Reference
---------

.. toctree::
   :maxdepth: 2

   reference/index
