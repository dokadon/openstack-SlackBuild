Setting up Barbican
===================

.. toctree::
   :maxdepth: 1

   dev
   keystone
   devstack
   certificate
   troubleshooting
   noauth
   audit
   plugin_backends
