============================
Key Manager service overview
============================

The Key Manager service provides...

The Key Manager service consists of the following components:

``barbican-api`` service
  Accepts and responds to end user compute API calls...
