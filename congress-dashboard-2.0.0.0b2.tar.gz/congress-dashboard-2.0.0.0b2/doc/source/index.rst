=============================================
Welcome to Congress Dashboard Documentation!
=============================================

Introduction
============

Congress Dashboard is an extension for OpenStack Dashboard that provides a UI
for Congress that allows user to easily write the policies and rules for
governance of cloud.

For more information on Congress, see `the congress documentation`_.

.. _the congress documentation: https://docs.openstack.org/congress/latest/

Contents
========

.. toctree::
   :maxdepth: 1

   install/index
   contributor/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
