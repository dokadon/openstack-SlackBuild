PANEL = 'monitor'
PANEL_DASHBOARD = 'admin'
PANEL_GROUP = 'policy'
ADD_PANEL = 'congress_dashboard.monitoring.panel.Monitor'
AUTO_DISCOVER_STATIC_FILES = True
