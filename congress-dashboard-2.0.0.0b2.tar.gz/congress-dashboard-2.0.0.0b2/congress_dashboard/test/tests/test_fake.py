from oslotest import base


class TestCase(base.BaseTestCase):

    def test_fake(self):
        pass
