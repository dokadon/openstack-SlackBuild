============
Installation
============

At the command line::

    $ pip install python-magnumclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-magnumclient
    $ pip install python-magnumclient