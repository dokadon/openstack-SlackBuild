========
Usage
========

To use python-magnumclient in a project::

	import magnumclient