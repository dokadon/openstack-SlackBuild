#!/bin/bash

sudo modprobe iscsi_tcp
