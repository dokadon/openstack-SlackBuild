#!/bin/bash

# Install Congress devstack integration
source ./pre_test_hook_common.sh
CONGRESS_BASE=/opt/stack/new/congress/contrib/devstack

