.. _quota:

*****
Quota
*****

.. _quota-base:

Quota Base
==========

.. automodule:: designate.quota.base
    :members:
    :undoc-members:
    :show-inheritance:

.. _quota-storage:

Quota Storage
=============

.. automodule:: designate.quota.impl_storage
    :members:
    :undoc-members:
    :show-inheritance:


