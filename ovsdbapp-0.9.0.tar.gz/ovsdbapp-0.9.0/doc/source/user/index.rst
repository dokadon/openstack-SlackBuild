========
Usage
========

To use ovsdbapp in a project::

    import ovsdbapp
