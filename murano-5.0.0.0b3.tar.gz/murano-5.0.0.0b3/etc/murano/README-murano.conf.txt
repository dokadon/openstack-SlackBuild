To generate the sample murano.conf file, run the following
command from the top level of the murano directory:

tox -egenconfig
