.. _manage-categories:

===================
Managing categories
===================
