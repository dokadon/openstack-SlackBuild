==================================================
Publish your Murano app in the application catalog
==================================================

Join the OpenStack community
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Prepare testing environment
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Contribute your code to Murano-apps
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Contribute your code to App-catalog
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
