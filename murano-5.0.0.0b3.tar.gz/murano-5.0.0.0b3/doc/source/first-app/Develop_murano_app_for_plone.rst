============================
Develop Murano app for Plone
============================

Develop standalone Plone Murano app (single VM)
-----------------------------------------------

Plone server requirements
~~~~~~~~~~~~~~~~~~~~~~~~~

Define host VM requirements
...........................

Host VM operatting system requirements
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Host VM hardware resources requirements
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Define preinstalled software and libraries requirements
.......................................................

Define what the PloneServerApp should do
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Create and debug sh-script that fully deploys the Plone server on a single VM
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Create Murano package for your app
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Upload and deploy your Murano app to OpenStack cloud
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Develop cluster Plone Murano app (multi VM)
-------------------------------------------

Develop basic server-client Murano app
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Add load-balancing to the Plone cluster
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Add scalability to the Plone cluster
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Add self-healing to the Plone cluster
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
