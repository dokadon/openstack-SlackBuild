==============================
 Current Series Release Notes
==============================

.. release-notes::
   :ignore-notes:
     bp-allow-expired-f5d845b9601bc1ef.yaml,
     bp-shadow-mapping-06fc7c71a401d707.yaml,
     bp-support-federated-attr-94084d4073f50280.yaml,
     integrate-osprofiler-ad0e16a542b12899.yaml,
     bug-1561054-dbe88b552a936a05.yaml,
     bug-1642687-5497fb56fe86806d.yaml,
     bug-1642687-c7ab1c9be152db20.yaml,
     bug-1642687-5497fb56fe86806d.yaml,
     bug-1659995-f3e716de743b7291.yaml,
     bug-1636950-8fa1a47fce440977.yaml,
     bug-1659995-f3e716de743b7291.yaml,
     bug-1652012-b3aea7c0d5affdb6.yaml
