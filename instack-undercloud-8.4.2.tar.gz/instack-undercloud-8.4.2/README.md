Team and repository tags
========================

[![Team and repository tags](https://governance.openstack.org/badges/instack-undercloud.svg)](https://governance.openstack.org/reference/tags/index.html)

<!-- Change things from this point on -->

Undercloud Install via instack
==============================

instack-undercloud is tooling for installing a TripleO undercloud.

It is part of the TripleO project:
https://docs.openstack.org/developer/tripleo-docs/index.html

* Free software: Apache license
* Source: https://git.openstack.org/cgit/openstack/instack-undercloud
* Bugs: https://bugs.launchpad.net/tripleo
