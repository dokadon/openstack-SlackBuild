============
Installation
============

At the command line::

    $ pip install os-traits

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv os-traits
    $ pip install os-traits
