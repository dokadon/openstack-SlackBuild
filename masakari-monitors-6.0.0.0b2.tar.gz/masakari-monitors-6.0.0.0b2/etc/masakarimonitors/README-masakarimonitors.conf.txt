To generate the sample masakarimonitors.conf file, run the following command from the top
level of the masakari directory:

    tox -egenconfig
