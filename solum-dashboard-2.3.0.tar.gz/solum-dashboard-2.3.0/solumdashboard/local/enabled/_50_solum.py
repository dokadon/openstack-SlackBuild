DASHBOARD = 'solum'
ADD_INSTALLED_APPS = ['solumdashboard']
DEFAULT = True
ADD_EXCEPTIONS = {}
