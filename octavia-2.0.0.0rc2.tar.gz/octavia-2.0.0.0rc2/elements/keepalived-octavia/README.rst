Element to install an Octavia Amphora with keepalived backend.


