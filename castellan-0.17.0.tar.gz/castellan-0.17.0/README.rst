=========
Castellan
=========

Generic Key Manager interface for OpenStack.

* License: Apache License, Version 2.0
* Documentation: https://docs.openstack.org/castellan/latest
* Source: https://git.openstack.org/cgit/openstack/castellan
* Bugs: https://bugs.launchpad.net/castellan

Team and repository tags
========================

.. image:: https://governance.openstack.org/badges/castellan.svg
    :target: https://governance.openstack.org/reference/tags/index.html
