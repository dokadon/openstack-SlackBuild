#!/bin/bash

set -ex

$BASE/new/devstack-gate/devstack-vm-gate.sh
