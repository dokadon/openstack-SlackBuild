=======================
volume transfer request
=======================

Block Storage v1, v2

volume transfer request list
----------------------------

Lists all volume transfer requests.

.. program:: volume transfer request list
.. code:: bash

    os volume transfer request list
        --all-projects

.. option:: --all-projects

    Shows detail for all projects. Admin only.
    (defaults to False)