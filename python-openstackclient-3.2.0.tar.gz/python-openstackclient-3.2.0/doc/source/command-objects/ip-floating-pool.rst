================
ip floating pool
================

Compute v2

ip floating pool list
---------------------

List pools of floating IP addresses
(Deprecated, please use ``floating ip pool list`` instead)

.. program:: ip floating pool list
.. code:: bash

    os ip floating pool list
