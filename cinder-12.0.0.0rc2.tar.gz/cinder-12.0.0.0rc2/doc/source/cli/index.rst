================================
Command-Line Interface Reference
================================

.. toctree::
   :maxdepth: 1

   cli-manage-volumes
   cli-set-quotas
   cli-cinder-quotas
   cli-cinder-scheduling
