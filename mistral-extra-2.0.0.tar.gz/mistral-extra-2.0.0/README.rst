==============
Mistral Extras
==============

Contains Mistral examples.

To see more detailed information about particular examples use README files
located in corresponding folders under ``examples/``.
