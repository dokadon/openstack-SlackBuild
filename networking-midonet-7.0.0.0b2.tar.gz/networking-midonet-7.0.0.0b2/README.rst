========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/networking-midonet.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

==================
networking-midonet
==================

This is the official Midonet Neutron plugin.

Documentation:

- https://docs.openstack.org/networking-midonet/latest/
- https://docs.midonet.org/
