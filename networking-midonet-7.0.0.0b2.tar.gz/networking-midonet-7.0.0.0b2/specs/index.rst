.. networking-midonet specs documentation index

==============
Specifications
==============

Kilo specs
==========

.. toctree::
   :glob:
   :maxdepth: 1

   kilo/*

Mitaka specs
============

.. toctree::
   :glob:
   :maxdepth: 1

   mitaka/*

Ocata specs
============

.. toctree::
   :glob:
   :maxdepth: 1

   ocata/*
