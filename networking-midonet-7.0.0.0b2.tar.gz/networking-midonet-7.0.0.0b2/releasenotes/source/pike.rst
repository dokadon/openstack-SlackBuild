===================================
 Pike Series Release Notes
===================================

.. release-notes::
   :branch: stable/pike
   :ignore-notes:
     gateway-management-2a14ac7fd9a0cf9f.yaml,
     lbaas-haproxy-provider-3231cbffbdd26d30.yaml,
     l2-gateway-4dca2095d0925dba.yaml,
     vpnaas-plugin-57fcdcd38ceba35a.yaml,
     start-reno-8fa73b6787b639ec.yaml,
     bgp-dynamic-routing-support-96c503f2786aa214.yaml,
     tap-as-a-service-aee029a693394696.yaml,
     logging-resource-support-e875290948524950.yaml,
     lbaasv2-fa5c948d4116ee3f.yaml,
     qos-fe2072952151800e.yaml,
     remove-v1-plugin-00e9e4a0d8fa0add.yaml
