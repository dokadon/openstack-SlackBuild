====
tooz
====

.. _tooz_1.62.0:

1.62.0
======

.. _tooz_1.62.0_New Features:

New Features
------------

.. releasenotes/notes/etcd3gw-group-support-598832a8764a8aa6.yaml @ b'6ab8c380c8d6a2e15611b225da7594e820cc773e'

- The etcd3gw driver now supports the group membership API.

