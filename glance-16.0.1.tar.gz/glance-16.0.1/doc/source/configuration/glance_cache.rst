.. _glance-cache.conf:

-----------------
glance-cache.conf
-----------------

.. show-options::
   :config-file: etc/oslo-config-generator/glance-cache.conf
