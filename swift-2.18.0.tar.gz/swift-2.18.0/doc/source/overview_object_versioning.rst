Object Versioning
=================

.. automodule:: swift.common.middleware.versioned_writes
    :show-inheritance:
