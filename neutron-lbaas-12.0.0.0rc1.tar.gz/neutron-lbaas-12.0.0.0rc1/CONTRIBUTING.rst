.. warning::
   Neutron-lbaas is now deprecated. Please see the FAQ: https://wiki.openstack.org/wiki/Neutron/LBaaS/Deprecation
   New features will not be accepted on this project.

Please see the Neutron CONTRIBUTING.rst file for how to contribute to
neutron-lbaas:

`Neutron CONTRIBUTING.rst <http://git.openstack.org/cgit/openstack/neutron/tree/CONTRIBUTING.rst>`_
