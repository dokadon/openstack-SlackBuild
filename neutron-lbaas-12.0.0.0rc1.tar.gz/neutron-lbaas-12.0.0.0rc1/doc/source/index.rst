.. documentation master file

Neutron LBaaS Documentation
===========================

.. warning::
   Neutron-lbaas is now deprecated. Please see the FAQ: https://wiki.openstack.org/wiki/Neutron/LBaaS/Deprecation


Dashboards
==========

There is a collection of dashboards to help developers and reviewers
located here.

.. toctree::
   :maxdepth: 2

   dashboards/index
