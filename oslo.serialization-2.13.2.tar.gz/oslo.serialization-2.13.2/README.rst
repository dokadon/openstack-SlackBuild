====================
 oslo.serialization
====================

.. image:: https://img.shields.io/pypi/v/oslo.serialization.svg
    :target: https://pypi.python.org/pypi/oslo.serialization/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/oslo.serialization.svg
    :target: https://pypi.python.org/pypi/oslo.serialization/
    :alt: Downloads

The oslo.serialization library provides support for representing objects
in transmittable and storable formats, such as Base64, JSON and MessagePack.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.serialization
* Source: http://git.openstack.org/cgit/openstack/oslo.serialization
* Bugs: http://bugs.launchpad.net/oslo.serialization
