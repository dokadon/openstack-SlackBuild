.. _verify:

Verify operation
~~~~~~~~~~~~~~~~

Verify operation of the Telemetry Alarming service.

TBD
