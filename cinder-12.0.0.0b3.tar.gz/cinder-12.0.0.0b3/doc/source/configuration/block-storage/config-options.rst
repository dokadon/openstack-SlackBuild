==================
Additional options
==================

These options can also be set in the ``cinder.conf`` file.

.. include:: ../tables/cinder-api.inc
.. include:: ../tables/cinder-auth.inc
.. include:: ../tables/cinder-backups.inc
.. include:: ../tables/cinder-block-device.inc
.. include:: ../tables/cinder-common.inc
.. include:: ../tables/cinder-compute.inc
.. include:: ../tables/cinder-coordination.inc
.. include:: ../tables/cinder-debug.inc
.. include:: ../tables/cinder-drbd.inc
.. include:: ../tables/cinder-emc.inc
.. include:: ../tables/cinder-eternus.inc
.. include:: ../tables/cinder-flashsystem.inc
.. include:: ../tables/cinder-hgst.inc
.. include:: ../tables/cinder-hpelefthand.inc
.. include:: ../tables/cinder-hpexp.inc
.. include:: ../tables/cinder-huawei.inc
.. include:: ../tables/cinder-hyperv.inc
.. include:: ../tables/cinder-images.inc
.. include:: ../tables/cinder-nas.inc
.. include:: ../tables/cinder-profiler.inc
.. include:: ../tables/cinder-pure.inc
.. include:: ../tables/cinder-quota.inc
.. include:: ../tables/cinder-redis.inc
.. include:: ../tables/cinder-san.inc
.. include:: ../tables/cinder-scheduler.inc
.. include:: ../tables/cinder-scst.inc
.. include:: ../tables/cinder-storage.inc
.. include:: ../tables/cinder-zones.inc
