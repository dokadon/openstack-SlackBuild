#!/bin/bash

# Install Mistral devstack integration
. ./pre_test_hook_common.sh
MISTRAL_BASE=/opt/stack/new/mistral/contrib/devstack
