===================
Murano Core Classes
===================

This folder contains common Murano classes combined to *Core Library*.

The content of this folder needs to be zipped and imported into Murano.
After that Murano applications can be deployed.

To find murano-applications and explore how the common classes are used in Murano Applications,
please refer to `Murano Application Repository <https://github.com/openstack/murano-apps>`_
