Murano applications
===================

Files for Murano benchmarking

Structure
---------

* <application_name>/ directories. Each directory stores a simple Murano package
  that is used to prepare the Murano context that is used to deploy an environment
  with a package. Other files needed for applications can be placed here as well.


Useful links
------------

* More about Murano: http://murano.readthedocs.org/
