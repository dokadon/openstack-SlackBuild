Sahara extra tools
==================

This folder contains bunch of tools for building artificats
of subprojects located in sahara-extra repository.
