===============
Available Hooks
===============

Below listed are the available hooks.


.. toctree::
   :maxdepth: 1

   hooks/ansible
   hooks/apply-config
   hooks/cfn-init
   hooks/chef
   hooks/docker-cmd
   hooks/docker-compose
   hooks/hiera
   hooks/json-file
   hooks/kubelet
   hooks/puppet
   hooks/salt
   hooks/script


