========
cfn-init
========

A hook which consumes configuration in the format of AWS::CloudFormation::Init
metadata. It is provided to enable migrating from CloudFormation metadata
configuration to configuration using config and deployment resources.
