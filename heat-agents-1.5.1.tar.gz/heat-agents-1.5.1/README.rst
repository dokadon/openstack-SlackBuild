========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/badges/heat-agents.svg
    :target: https://governance.openstack.org/reference/tags/index.html

.. Change things from this point on

===========
Heat Agents
===========

Heat Agents are python hooks for deploying software configurations using heat.
