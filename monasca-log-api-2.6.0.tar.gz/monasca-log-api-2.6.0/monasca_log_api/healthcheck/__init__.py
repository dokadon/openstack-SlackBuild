"""Base package for monasca-log-api healthcheck"""
