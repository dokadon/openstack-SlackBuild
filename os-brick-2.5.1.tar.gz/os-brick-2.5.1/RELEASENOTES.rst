========
os-brick
========

.. _os-brick_2.4.0:

2.4.0
=====

.. _os-brick_2.4.0_New Features:

New Features
------------

.. releasenotes/notes/scaleio-extend-attached-ec44d3a72395882c.yaml @ b'e500fd8873422d4ee033a8702a2b3241c40c6e9d'

- Added ability to extend attached ScaleIO volumes

