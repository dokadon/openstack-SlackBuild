================================================
Sample [DATAPLANE_DRIVER_EVPN] with driver=linux
================================================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/dataplane-evpn-linux-vxlan.conf.sample>`_.

.. literalinclude::
   ../../_static/config_samples/dataplane-evpn-linux-vxlan.conf.sample
