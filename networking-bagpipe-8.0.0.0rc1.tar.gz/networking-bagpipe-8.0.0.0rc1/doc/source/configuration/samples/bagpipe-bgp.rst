=======================
Sample bagpipe-bgp.conf
=======================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/bagpipe-bgp.conf.sample>`_.

.. literalinclude::
   ../../_static/config_samples/bagpipe-bgp.conf.sample

More dataplane configuration parameters exist depending on the driver:

.. toctree::
   :glob:
   :maxdepth: 1

   dataplane*
