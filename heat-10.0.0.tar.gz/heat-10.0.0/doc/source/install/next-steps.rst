.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the heat service.

To add more services, see the
`additional documentation on installing OpenStack <http://docs.openstack.org/#install-guides>`_ .

To learn more about the heat service, read the `Heat developer documentation
<http://docs.openstack.org/developer/heat/index.html>`__.
