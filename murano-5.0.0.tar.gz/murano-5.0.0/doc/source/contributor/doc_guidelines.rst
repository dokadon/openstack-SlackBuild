.. _doc-guidelines:

========================
Documentation guidelines
========================
