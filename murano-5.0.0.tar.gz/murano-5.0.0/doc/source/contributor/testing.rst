.. _testing:

=======
Testing
=======

Testing guidelines
~~~~~~~~~~~~~~~~~~

Continuous Integration service
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

UI testing
~~~~~~~~~~

Tempest tests
~~~~~~~~~~~~~

Automated testing machinery
~~~~~~~~~~~~~~~~~~~~~~~~~~~

CI design
---------
CI jobs
-------
