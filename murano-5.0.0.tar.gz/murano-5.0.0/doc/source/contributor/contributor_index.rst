.. index:: Murano Contributor Guide

.. _contributor-guide:

Contributor Guide
~~~~~~~~~~~~~~~~~

.. toctree::
   :maxdepth: 2

   how_to_contribute
   dev_guidelines
   plugins
   dev_env
   testing
   doc_guidelines
   stable_branches