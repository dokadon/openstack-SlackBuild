# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

"""add_mtu_network_allocations

Revision ID: 493eaffd79e1
Revises: e8ea58723178
Create Date: 2016-08-01 14:18:31.899606

"""

# revision identifiers, used by Alembic.
revision = '493eaffd79e1'
down_revision = 'e8ea58723178'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.add_column(
        'network_allocations',
        sa.Column('mtu', sa.Integer, nullable=True))
    op.add_column(
        'share_networks',
        sa.Column('mtu', sa.Integer, nullable=True))


def downgrade():
    op.drop_column('network_allocations', 'mtu')
    op.drop_column('share_networks', 'mtu')
