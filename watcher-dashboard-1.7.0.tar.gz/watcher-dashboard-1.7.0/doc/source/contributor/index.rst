.. toctree::
   :maxdepth: 1

  contributing