===============================================
 oslo.rootwrap -- Escalated Permission Control
===============================================

oslo.rootwrap allows fine-grained filtering of shell commands to run
as `root` from OpenStack services.

.. toctree::
   :maxdepth: 2

   install/index
   user/index
   contributor/index

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
