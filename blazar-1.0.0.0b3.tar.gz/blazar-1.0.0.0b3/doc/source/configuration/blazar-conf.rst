===========
blazar.conf
===========

.. show-options::
   :config-file: etc/blazar/blazar-config-generator.conf
