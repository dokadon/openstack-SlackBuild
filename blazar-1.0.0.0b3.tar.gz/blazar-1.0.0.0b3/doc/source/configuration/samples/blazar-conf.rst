==================
Sample blazar.conf
==================

The following is a sample blazar configuration.

.. literalinclude:: ../../_static/blazar.conf.sample