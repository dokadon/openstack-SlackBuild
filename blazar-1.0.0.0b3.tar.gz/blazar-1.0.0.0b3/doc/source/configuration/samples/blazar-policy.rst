==================
Sample Policy File
==================

The following is a sample policy file.

.. literalinclude:: ../../../../etc/policy.json
