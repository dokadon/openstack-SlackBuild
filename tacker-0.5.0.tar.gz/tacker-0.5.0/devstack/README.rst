.. include:: ../doc/source/install/devstack.rst
