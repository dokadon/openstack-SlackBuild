========================
neutron-vpnaas-dashboard
========================

.. _neutron-vpnaas-dashboard_1.3.0:

1.3.0
=====

.. _neutron-vpnaas-dashboard_1.3.0_Upgrade Notes:

Upgrade Notes
-------------

.. releasenotes/notes/django2-support-ef2f2bd52a8bb63f.yaml @ d9fd377e29d3d59501e28c06ff76c9afb43d76de

- Supported django versions are chagned aligning with the supported versions
  by horizon. Django 1.11 and 2.0 are supported now. Django 1.8 to 1.10 are
  no longer supported.

