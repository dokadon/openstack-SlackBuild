========================
Neutron VPNaaS Dashboard
========================

OpenStack Dashboard panels for Neutron VPNaaS

* Documentation: https://git.openstack.org/cgit/openstack/neutron-vpnaas-dashboard/tree/doc/source
* Source: https://git.openstack.org/cgit/openstack/neutron-vpnaas-dashboard
* Bugs: https://bugs.launchpad.net/neutron-vpnaas-dashboard

Team and repository tags
------------------------

.. image:: https://governance.openstack.org/tc/badges/neutron-vpnaas-dashboard.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html
