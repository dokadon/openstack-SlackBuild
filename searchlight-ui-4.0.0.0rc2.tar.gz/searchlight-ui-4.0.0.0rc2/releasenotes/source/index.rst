==========================
 Searchlight Release Notes
==========================

.. toctree::
   :maxdepth: 1

   mitaka
   unreleased
   pike
   ocata
   newton
