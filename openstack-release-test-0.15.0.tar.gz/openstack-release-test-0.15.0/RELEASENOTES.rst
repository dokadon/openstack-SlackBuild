======================
openstack-release-test
======================

.. _openstack-release-test_0.14.0:

0.14.0
======

.. _openstack-release-test_0.14.0_Prelude:

Prelude
-------

.. releasenotes/notes/test-release-after-pypi-update-97153a13b68abaf7.yaml @ b'86fa0da38cd59cd085ab7fb417832072da7354e9'

This release exists to test the release machinery after the PyPI upgrade on 16 Apr 2018.

