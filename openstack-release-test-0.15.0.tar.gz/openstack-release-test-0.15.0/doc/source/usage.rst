========
Usage
========

To use release-test in a project::

    import release_test
