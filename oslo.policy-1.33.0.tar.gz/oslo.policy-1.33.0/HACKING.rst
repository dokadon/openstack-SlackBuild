Style Commandments
==================

- Step 1: Read the OpenStack Style Commandments
  https://docs.openstack.org/hacking/latest/
- Step 2: Read on

oslo.policy Specific Commandments
---------------------------------

- Avoid using "double quotes" where you can reasonably use 'single quotes'
