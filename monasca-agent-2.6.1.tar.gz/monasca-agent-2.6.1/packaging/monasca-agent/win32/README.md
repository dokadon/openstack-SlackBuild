# Building for Windows

In `cmd.exe` or Powershell, run:

`powershell -File build.ps1`

This will generate a `.msi` file in the `build/` folder.
