# monasca-setup

This script will detect running services and configure monasca-agent to watch them as well as starting the agent and
configuring it to start up on boot.


## Future Considerations
- A config file with metadata to assist in automatic configuration could be quite valuable, for example user/pass for
  logging into mysql.
