=====================
Ironic tempest plugin
=====================

This directory contains Tempest tests to cover the Ironic project,
as well as a plugin to automatically load these tests into tempest.

See the tempest plugin docs for information on using it:
http://docs.openstack.org/developer/tempest/plugin.html#using-plugins

See the Ironic documentation for information about how to run the
tempest tests:
http://docs.openstack.org/developer/ironic/dev/dev-quickstart.html#running-tempest-tests
