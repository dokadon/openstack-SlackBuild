.. _glance-manage.conf:

------------------
glance-manage.conf
------------------

.. show-options::
   :config-file: etc/oslo-config-generator/glance-manage.conf
