============================
Glance Configuration Options
============================

This section provides a list of all possible options for each
configuration file.  Refer to :doc:`Basic Configuration <../configuring>`
for a detailed guide in getting started with various option settings.

Glance uses the following configuration files for its various services.

.. toctree::
   :glob:
   :maxdepth: 1

   *
