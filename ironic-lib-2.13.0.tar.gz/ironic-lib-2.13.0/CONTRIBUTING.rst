If you would like to contribute to the development of OpenStack,
you must follow the steps documented at:

   https://docs.openstack.org/infra/manual/developers.html#development-workflow

Pull requests submitted through GitHub will be ignored.

Bugs should be filed in StoryBoard, not GitHub:

   https://storyboard.openstack.org/#!/project/946
