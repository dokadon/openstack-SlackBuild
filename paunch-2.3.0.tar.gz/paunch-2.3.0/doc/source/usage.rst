========
Usage
========

To use paunch in a project::

    import paunch
