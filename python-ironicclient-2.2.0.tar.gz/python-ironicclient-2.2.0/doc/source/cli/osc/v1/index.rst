Command Reference
=================

List of released CLI commands available in openstack client. These commands
can be referenced by doing ``openstack help baremetal``.

=================
baremetal chassis
=================

.. autoprogram-cliff:: openstack.baremetal.v1
    :command: baremetal chassis *

================
baremetal driver
================

.. autoprogram-cliff:: openstack.baremetal.v1
    :command: baremetal driver *

==============
baremetal node
==============

.. autoprogram-cliff:: openstack.baremetal.v1
    :command: baremetal node *

==============
baremetal port
==============

.. autoprogram-cliff:: openstack.baremetal.v1
    :command: baremetal port *

================
baremetal volume
================

.. autoprogram-cliff:: openstack.baremetal.v1
    :command: baremetal volume *
