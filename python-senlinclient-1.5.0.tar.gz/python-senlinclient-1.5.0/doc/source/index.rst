===============================================
Welcome to python-senlinclient's documentation!
===============================================

Contents:

.. toctree::
   :maxdepth: 2

   install/index
   cli/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

