===================================
 Newton Series Release Notes
===================================

.. release-notes::
   :branch: origin/stable/newton
   :earliest-version: 3.0.0
