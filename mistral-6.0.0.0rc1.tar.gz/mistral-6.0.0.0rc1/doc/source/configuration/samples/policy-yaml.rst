===========
policy.yaml
===========

Use the ``policy.yaml`` file to define additional access controls that apply to
the Mistral services:

.. literalinclude:: ../../_static/mistral.policy.yaml.sample

