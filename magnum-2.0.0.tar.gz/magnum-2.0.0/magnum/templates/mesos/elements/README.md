Mesos elements
==============

See [Building an image](http://docs.openstack.org/developer/magnum/dev/dev-mesos.html) for instructions.
