A Mesos cluster with Heat
=========================

See [Mesos cluster with Heat](http://docs.openstack.org/developer/magnum/dev/dev-mesos.html) for instructions.
