Welcome to futurist's documentation!
========================================================

Code from the future, delivered to you in the **now**.

.. toctree::
   :maxdepth: 2

   features
   api
   installation
   examples
   contributing

History
=======

.. toctree::
   :maxdepth: 2

   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

