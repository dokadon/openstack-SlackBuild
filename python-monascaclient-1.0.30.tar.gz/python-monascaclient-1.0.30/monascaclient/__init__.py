import pbr.version

__version__ = pbr.version.VersionInfo('python-monascaclient').version_string()
