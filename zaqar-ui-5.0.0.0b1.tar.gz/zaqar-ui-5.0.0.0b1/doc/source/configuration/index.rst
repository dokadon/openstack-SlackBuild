=============
Configuration
=============

Zaqar UI has no configuration option.

For more configurations, see
`Configuration Guide
<https://docs.openstack.org/horizon/latest/configuration/index.html>`__
in the Horizon documentation.

