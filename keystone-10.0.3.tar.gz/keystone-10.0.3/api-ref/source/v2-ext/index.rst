:tocdepth: 2

==========================================
 Identity API v2.0 extensions (DEPRECATED)
==========================================

.. rest_expand_all::

.. include:: ksadm-admin.inc
.. include:: ksec2-admin.inc
.. include:: kscrud.inc
