Install instructions
====================

Please check README.rst for further installation instructions.

Install from sources::
----------------------

You have now the freezerc tool installed in /usr/local/bin/freezerc

Please execute the following command to all the available options:

$ freezerc --help [...]

Please read README.txt or HACKING.txt to see the requirement and more
technical details about how to run freezer

Thanks, The Freezer Team.
