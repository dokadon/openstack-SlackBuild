=======
 Usage
=======

To use oslo.utils in a project, import the individual module you
need. For example::

    from oslo_utils import strutils

    slug = strutils.to_slug('input value')
