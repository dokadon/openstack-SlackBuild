========================
 Command Line Interface
========================

At the moment, monasca-log-api cannot be operated
from the CLI.
