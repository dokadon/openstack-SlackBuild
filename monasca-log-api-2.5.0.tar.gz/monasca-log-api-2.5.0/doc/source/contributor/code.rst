.. _codedocs:

======================
Codebase documentation
======================

Following section contains codebase documenation generated with, a little
bit of assistance, `sphinx.ext.autodoc`_.

.. _`sphinx.ext.autodoc`: http://www.sphinx-doc.org/en/stable/ext/autodoc.html

Modules
=======

.. toctree::
   :maxdepth: 2

   api/autoindex.rst
