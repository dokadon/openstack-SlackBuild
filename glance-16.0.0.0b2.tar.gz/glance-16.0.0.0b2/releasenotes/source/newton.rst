===================================
 Newton Series Release Notes
===================================

.. release-notes::
   :branch: origin/stable/newton
   :earliest-version: 13.0.0
