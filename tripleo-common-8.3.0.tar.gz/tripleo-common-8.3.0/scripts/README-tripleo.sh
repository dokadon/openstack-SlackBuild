The tripleo.sh script is now maintained in the tripleo-ci repo:

https://github.com/openstack-infra/tripleo-ci
