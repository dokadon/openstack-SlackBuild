==================================
 python-designateclient Reference
==================================

.. toctree::

   api/autoindex
