Welcome to |project| documentation
====================================

The instack-undercloud project has code and diskimage-builder
elements for deploying a TripleO undercloud to an existing system.

See the `TripleO documentation`_ for the full end-to-end workflow.

.. _`TripleO documentation`: https://docs.openstack.org/developer/tripleo-docs/

API Documentation
=================

.. toctree::
   :maxdepth: 1

   api/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
