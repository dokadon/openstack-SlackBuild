OpenStack Nova Documentation README
===================================

Both contributor developer documentation and
REST API documentation are sourced here.

Contributor developer docs are built to:
https://docs.openstack.org/nova/latest/

API guide docs are built to:
https://developer.openstack.org/api-guide/compute/

For more details, see the "Building the Documentation" section of
doc/source/contributor/development.environment.rst.
