All files from this directory will be copied to gates, so you will be able
to use absolute path in rally tasks. Files will be in ~/.rally/extra/*
