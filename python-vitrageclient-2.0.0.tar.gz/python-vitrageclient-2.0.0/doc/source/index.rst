.. python-vitrageclient documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to python-vitrageclient's documentation!
================================================

Developer Guide
---------------

.. toctree::
   :maxdepth: 1

   contributor/readme
   contributor/installation
   contributor/usage
   contributor/contributing
   contributor/cli

.. # NOTE(ifat-afek): Hide files we don't want to see in the table of contents.
   # sphinx build fails if a file is not included in the toctree.
.. toctree::
   :hidden:

   contributor/index

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
