==============================
 keystoneclient Release Notes
==============================

.. toctree::
   :maxdepth: 1

   unreleased
   pike
   ocata
   newton
   mitaka
