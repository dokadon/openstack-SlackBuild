============
Installation
============

At the command line::

    $ pip install oslo.log

To use ``oslo_log.fixture``, some additional dependencies
are needed. They can be installed using the ``fixtures`` extra::

    $ pip install 'oslo.log[fixtures]'
