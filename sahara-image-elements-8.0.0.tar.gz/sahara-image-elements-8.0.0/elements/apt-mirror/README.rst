==========
apt-mirror
==========

This element sets up the mirror for updating the Ubuntu cloud image.
Using a mirror improves the speed of the image building.

Environment Variables
---------------------

UBUNTU_MIRROR
  :Required: Yes
  :Description: URL to the Ubuntu mirror.
