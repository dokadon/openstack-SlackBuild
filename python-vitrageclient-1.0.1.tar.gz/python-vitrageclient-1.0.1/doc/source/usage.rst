========
Usage
========

To use python-vitrageclient in a project::

    import vitrageclient
