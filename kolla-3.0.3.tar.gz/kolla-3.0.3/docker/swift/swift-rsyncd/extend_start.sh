#!/bin/bash

sudo chown -R swift:swift /srv/node
