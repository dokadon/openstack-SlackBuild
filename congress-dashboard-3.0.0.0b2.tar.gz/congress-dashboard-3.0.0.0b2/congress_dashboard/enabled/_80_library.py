PANEL = 'library'
PANEL_DASHBOARD = 'admin'
PANEL_GROUP = 'policy'
ADD_PANEL = 'congress_dashboard.library.panel.PolicyLibrary'
AUTO_DISCOVER_STATIC_FILES = True
