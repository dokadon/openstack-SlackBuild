.. toctree::
   :maxdepth: 1

  installation