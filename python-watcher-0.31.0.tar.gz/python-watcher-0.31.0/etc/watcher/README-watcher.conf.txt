To generate the sample watcher.conf file, run the following
command from the top level of the watcher directory:

tox -econfig