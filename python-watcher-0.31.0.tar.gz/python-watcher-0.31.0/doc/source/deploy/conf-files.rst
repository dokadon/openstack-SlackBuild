.. _watcher_sample_configuration_files:

==================================
Watcher sample configuration files
==================================

watcher.conf
~~~~~~~~~~~~

The ``watcher.conf`` file contains most of the options to configure the
Watcher services.

.. literalinclude:: ../watcher.conf.sample
   :language: ini
