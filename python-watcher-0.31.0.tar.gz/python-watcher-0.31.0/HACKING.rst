..
      Except where otherwise noted, this document is licensed under Creative
      Commons Attribution 3.0 License.  You can view the license at:

          https://creativecommons.org/licenses/by/3.0/

==========================
watcher Style Commandments
==========================

Read the OpenStack Style Commandments http://docs.openstack.org/developer/hacking/
