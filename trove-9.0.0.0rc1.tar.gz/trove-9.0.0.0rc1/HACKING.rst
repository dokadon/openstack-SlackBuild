Trove Library Specific Commandments
-------------------------------------

- [T103] Exception messages should be translated
- [T104] Python 3 is not support basestring,replace basestring with
  six.string_types
- [T105] Validate no LOG translations
