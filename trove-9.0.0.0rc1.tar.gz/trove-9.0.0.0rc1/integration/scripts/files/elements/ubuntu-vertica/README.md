Sets up a Vertica CE 7.1 debian package and other dependencies install in the image.
