Sets up a MariaDB server install in the image.

TODO: auto-tune settings based on host resources or metadata service.
