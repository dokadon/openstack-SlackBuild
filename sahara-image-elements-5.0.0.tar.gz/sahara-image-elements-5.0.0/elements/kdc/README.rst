===
kdc
===

Installs all needed artifacts for KDC server and Kerberos authentication

Environment Variables
---------------------

DIB_UNLIMITED_SECURITY_LOCATION
  :Required: No
  :Default: http://sahara-files.mirantis.com/kerberos-artifacts/
  :Description: Place where UnlimitedSecurity polices are located
