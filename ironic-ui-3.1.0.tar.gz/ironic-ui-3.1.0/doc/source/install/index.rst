============================
ironic-ui installation guide
============================

.. toctree::
   :maxdepth: 1

   installation
   uninstallation
