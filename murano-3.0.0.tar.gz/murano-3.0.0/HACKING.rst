Style Commandments
==================

Read the OpenStack Style Commandments http://docs.openstack.org/developer/hacking/

Murano Specific Commandments
---------------------------

- [M322] Method's default argument shouldn't be mutable.
- [M323] Python 3: do not use dict.iteritems.
- [M324] Python 3: do not use dict.iterkeys.
- [M325] Python 3: do not use dict.itervalues.
- [M326] Python 3: do not use basestring.
