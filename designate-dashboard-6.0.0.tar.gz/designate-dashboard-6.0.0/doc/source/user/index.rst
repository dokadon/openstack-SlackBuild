========
Usage
========

To use designate_dashboard in a project::

	import designate_dashboard