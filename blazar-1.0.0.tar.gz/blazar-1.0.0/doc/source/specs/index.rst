============
Blazar Specs
============

Queens
------

This section has a list of specs for Queens release.


.. toctree::
   :maxdepth: 1
   :glob:

   queens/*

Pike
----

This section has a list of specs for Pike release.


.. toctree::
   :maxdepth: 1
   :glob:

   pike/*
