Blazar Style Commandments
=========================

- Step 1: Read the OpenStack Style Commandments
  https://docs.openstack.org/hacking/latest/
- Step 2: Read on

Blazar Specific Commandments
----------------------------

- [C312] Validate that logs are not translated.
- [H904] Delay string interpolations at logging calls.
