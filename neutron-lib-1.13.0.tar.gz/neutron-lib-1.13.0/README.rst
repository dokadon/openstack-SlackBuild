========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/neutron-lib.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

===============================
neutron-lib
===============================

Neutron shared routines and utilities

* Free software: Apache license
* Documentation: https://docs.openstack.org/neutron-lib/latest/
* Source: http://git.openstack.org/cgit/openstack/neutron-lib
* Bugs: http://bugs.launchpad.net/neutron

Features
--------

* TODO
