============
Installation
============

At the command line::

    $ pip install vitrage-dashboard

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv vitrage-dashboard
    $ pip install vitrage-dashboard

`Devstack installation <https://github.com/openstack/vitrage-dashboard/blob/master/README.rst>`_
