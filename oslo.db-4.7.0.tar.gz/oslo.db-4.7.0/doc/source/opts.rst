=====================
Configuration Options
=====================

oslo.db uses oslo.config to define and manage configuration
options to allow the deployer to control how an application uses the
underlying database.

.. show-options:: oslo.db
