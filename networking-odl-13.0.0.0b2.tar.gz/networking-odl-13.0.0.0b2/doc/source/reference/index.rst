====================
Reference Deployment
====================

This document is intended to guide for versions of OpenStack and
OpenDaylight components to use when OpenStack is deployed with
OpenDaylight.

OpenStack Version Reference
---------------------------
.. toctree::
   :maxdepth: 2

   pike.rst
   ocata.rst
   newton.rst
