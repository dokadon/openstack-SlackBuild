============
Development
============

Contributing
------------

This guide is to tell someone who would like to contribute to
Kolla project. Following this guide to propose your first patch for Kolla.
And we are welcome everyone to join our project!

.. toctree::
   :maxdepth: 2

   CONTRIBUTING.rst
   running-tests
   bug-triage
