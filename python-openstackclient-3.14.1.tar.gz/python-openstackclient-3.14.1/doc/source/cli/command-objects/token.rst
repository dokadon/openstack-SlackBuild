=====
token
=====

Identity v2, v3

token issue
-----------

Issue new token

.. program:: token issue
.. code:: bash

    openstack token issue

token revoke
------------

Revoke existing token

.. program:: token revoke
.. code:: bash

    openstack token revoke
        <token>

.. describe:: <token>

    Token to be deleted
