========================
network service provider
========================

A **network service provider** is a particular driver that implements a
networking service

Network v2

.. _network_service_provider_list:

network service provider list
-----------------------------

List service providers

.. program:: network service provider list
.. code:: bash

    openstack network service provider list
