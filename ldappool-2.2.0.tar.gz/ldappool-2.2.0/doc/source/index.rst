ldappool
========

Contents:

.. toctree::
   :maxdepth: 1

   api/modules

Release Notes
=============

.. toctree::
   :maxdepth: 1

   history

Contributing
============

Code is hosted `on GitHub`_. Submit bugs to the Keystone project on
`Launchpad`_. Submit code to the ``openstack/ldappool`` project
using `Gerrit`_.

.. _on GitHub: https://github.com/openstack/ldappool
.. _Launchpad: https://launchpad.net/ldappool
.. _Gerrit: http://docs.openstack.org/infra/manual/developers.html#development-workflow

Run tests with ``tox``.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

