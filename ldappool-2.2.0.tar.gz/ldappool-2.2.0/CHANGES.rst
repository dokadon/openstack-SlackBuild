Releases
::::::::

1.1 - ?
-------

???

1.0 - 2012-02-27
----------------

- Fix ``use_tls`` flag to ConnectionManager; it previously was always set
  ``False`` no matter what was passed.


0.9 - 2011-10-28
----------------

- initial release.
