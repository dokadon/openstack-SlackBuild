# Copyright (c) 2015 Mirantis, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import testtools

from muranodashboard.dynamic_ui import version


class TestVersions(testtools.TestCase):
    def setUp(self):
        super(TestVersions, self).setUp()
        self.original = version.LATEST_FORMAT_VERSION
        version.LATEST_FORMAT_VERSION = '2.4'

    def tearDown(self):
        version.LATEST_FORMAT_VERSION = self.original
        super(TestVersions, self).tearDown()

    def test_get_latest_as_semver(self):
        latest = version.get_latest_version()
        self.assertEqual(2, latest.major)
        self.assertEqual(4, latest.minor)
        self.assertEqual(0, latest.patch)

    def test_exact_match(self):
        version.check_version('2.4')

    def test_older_in_family(self):
        version.check_version('2.1')

    def test_oldest_in_family(self):
        version.check_version('2')

    def test_newer(self):
        self.assertRaises(ValueError, version.check_version, '2.5')

    def test_uncompatible_old(self):
        self.assertRaises(ValueError, version.check_version, '1.6')

    def test_uncompatible_new(self):
        self.assertRaises(ValueError, version.check_version, '3.0')
