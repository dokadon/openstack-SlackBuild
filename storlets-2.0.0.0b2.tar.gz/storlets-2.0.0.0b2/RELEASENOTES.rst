========
storlets
========

.. _storlets_1.0.0:

1.0.0
=====

.. _storlets_1.0.0_Upgrade Notes:

Upgrade Notes
-------------

.. releasenotes/notes/1_0_0_release-fa5dd1bedecd412c.yaml @ b'84651628ea3e031f017d094322505a6c4e860d90'

- Moving storlets installation code to be as devstack plugin and also moves
  several non-python storlets code out from the docker image.


.. _storlets_1.0.0_Bug Fixes:

Bug Fixes
---------

.. releasenotes/notes/1_0_0_release-fa5dd1bedecd412c.yaml @ b'84651628ea3e031f017d094322505a6c4e860d90'

- Migrate zuul job into Stolets repo.

.. releasenotes/notes/1_0_0_release-fa5dd1bedecd412c.yaml @ b'84651628ea3e031f017d094322505a6c4e860d90'

- Various other minor bug fixes.

