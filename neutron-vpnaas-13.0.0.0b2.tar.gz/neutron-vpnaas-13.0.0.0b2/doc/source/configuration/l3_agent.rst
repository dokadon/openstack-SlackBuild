=============
vpn_agent.ini
=============

This is a configuration file for the VPNaaS L3 agent
extension of the neutron l3-agent.

.. show-options::
   :config-file: etc/oslo-config-generator/vpn_agent.ini
