========================================
[DATAPLANE_DRIVER_IPVPN] with driver=ovs
========================================

.. show-options::
   :config-file: etc/oslo-config-generator/dataplane-ipvpn-mpls-ovs.conf
