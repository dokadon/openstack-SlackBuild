===============================================
Sample [DATAPLANE_DRIVER_IPVPN] with driver=ovs
===============================================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/dataplane-ipvpn-mpls-ovs.conf.sample>`_.

.. literalinclude::
   ../../_static/config_samples/dataplane-ipvpn-mpls-ovs.conf.sample
