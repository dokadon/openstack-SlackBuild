=================================
bagpipe ML2 neutron server config
=================================

.. show-options::
   :config-file: etc/oslo-config-generator/ml2-bagpipe.conf
