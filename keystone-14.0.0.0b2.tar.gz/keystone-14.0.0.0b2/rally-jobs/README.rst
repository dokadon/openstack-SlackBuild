This directory contains rally benchmark scenarios to be run by OpenStack CI.


* more about rally: https://rally.readthedocs.io/en/latest/
* how to add rally-gates: https://rally.readthedocs.io/en/latest/quick_start/gates.html
