==============================
blazar_dashboard Release Notes
==============================

.. toctree::
   :maxdepth: 1

   unreleased
   queens
