#!/bin/bash

sudo chown -R swift:swift /srv/node
mkdir -p /var/lib/swift/lock
