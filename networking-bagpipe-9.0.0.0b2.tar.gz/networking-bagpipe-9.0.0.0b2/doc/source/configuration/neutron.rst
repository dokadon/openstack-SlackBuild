==============
Neutron config
==============

.. _neutron-sfc-config:

SFC
---

The following section can be added to Neutron server configuration to
parameters related to the sfc driver.

.. show-options::
   :config-file: etc/oslo-config-generator/neutron-sfc.conf
