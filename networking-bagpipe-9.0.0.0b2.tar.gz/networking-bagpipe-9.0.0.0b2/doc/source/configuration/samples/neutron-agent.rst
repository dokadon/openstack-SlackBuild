===========================
Sample Neutron agent config
===========================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/neutron-agent.conf.sample>`_.

.. literalinclude::
   ../../_static/config_samples/neutron-agent.conf.sample
