=========================================
[DATAPLANE_DRIVER_EVPN] with driver=linux
=========================================

.. show-options::
   :config-file: etc/oslo-config-generator/dataplane-evpn-linux-vxlan.conf
