================
bagpipe-bgp.conf
================

.. show-options::
   :config-file: etc/oslo-config-generator/bagpipe-bgp.conf


More dataplane configuration parameters exist depending on the driver:

.. toctree::
   :glob:
   :maxdepth: 1

   dataplane*
