==========
User Guide
==========

.. toctree::
    :maxdepth: 2

    introduction.rst
    architecture.rst
    state-machines.rst
    resource-monitoring.rst
    ../cli/index
    ../restapi/index
