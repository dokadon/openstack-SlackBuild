:tocdepth: 2

==================
Reservation API V1
==================

This is a reference for the OpenStack Reservation API which is provided by the
Blazar project.

.. include:: leases.inc
.. include:: hosts.inc
