To generate the sample blazar.conf file, run the following command from the top
level of the blazar directory:

    $ tox -egenconfig
