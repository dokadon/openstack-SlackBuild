
Welcome to Mistral Dashboard's documentation!
============================================

Contents:

.. toctree::
   :maxdepth: 1

   readme
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
