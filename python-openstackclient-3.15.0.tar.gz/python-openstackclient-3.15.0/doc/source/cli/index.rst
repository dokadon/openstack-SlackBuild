====================
 User Documentation
====================

.. toctree::
   :maxdepth: 2

   Manual Page <man/openstack>
   command-list
   commands
   plugin-commands
   authentication
   interactive
   decoder
   backwards-incompatible
