============
server image
============

A server image is a disk image created from a running server instance.  The
image is created in the Image store.

Compute v2

.. autoprogram-cliff:: openstack.compute.v2
   :command: server image create
