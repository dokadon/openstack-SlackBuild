=====
trust
=====

A **trust** provide project-specific role delegation between users, with
optional impersonation. Requires the OS-TRUST extension. Applies to Identity v3.

.. autoprogram-cliff:: openstack.identity.v3
   :command: trust create

.. autoprogram-cliff:: openstack.identity.v3
   :command: trust delete

.. autoprogram-cliff:: openstack.identity.v3
   :command: trust list

.. autoprogram-cliff:: openstack.identity.v3
   :command: trust show
