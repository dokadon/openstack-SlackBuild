======
module
======

Internal

Installed Python modules in the OSC process.

module list
-----------

List module versions

.. program:: module list
.. code:: bash

    openstack module list
        [--all]

.. option:: --all

    Show all modules that have version information
