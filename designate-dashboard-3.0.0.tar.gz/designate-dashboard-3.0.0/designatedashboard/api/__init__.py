from designatedashboard.api import designate  # noqa
