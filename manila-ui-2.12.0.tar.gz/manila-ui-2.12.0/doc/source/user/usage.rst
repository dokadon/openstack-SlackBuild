=====
Usage
=====

To use manila-ui in a project::

    import manila_ui
