==============================
Installing Congress Dashboard
==============================
.. include:: ../../../README.rst
