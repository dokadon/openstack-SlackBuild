=================
Block Storage API
=================

Contents:

.. toctree::
    :maxdepth: 1

    v1/index
    v2/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
