==============================
 Cinder Database Architecture
==============================

Cinder Database Backends
~~~~~~~~~~~~~~~~~~~~~~~~

.. list-plugins:: cinder.database.migration_backend
    :detailed:
