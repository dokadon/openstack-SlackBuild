OpenStack Nova Documentation README
===================================

Both contributor developer documentation and
REST API documentation are sourced here.

Contributor developer docs are built to:
http://docs.openstack.org/developer/nova/

API guide docs are built to:
http://developer.openstack.org/api-guide/compute/

For more details, see the "Building the Documentation" section of
doc/source/development.environment.rst.
