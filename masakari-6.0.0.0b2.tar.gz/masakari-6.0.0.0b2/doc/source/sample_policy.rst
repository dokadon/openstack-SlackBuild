===============
Masakari Policy
===============

The following is a sample masakari policy file. Operator can configure policies
as per his requirement. It is recommended that all api's of masakari should
be allowed to admin user only.

.. literalinclude:: _static/masakari.policy.json.sample
