:tocdepth: 2

==============
 Masakari API
==============

This is a reference for the OpenStack Masakari API which is provided by the
Masakari project.

.. rest_expand_all::

.. include:: versions.inc
.. include:: failover-segments.inc
.. include:: hosts.inc
.. include:: notifications.inc
