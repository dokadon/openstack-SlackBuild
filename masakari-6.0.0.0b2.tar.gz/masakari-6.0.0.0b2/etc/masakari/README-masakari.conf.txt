To generate the sample masakari.conf file, run the following command from the top
level of the masakari directory:

    tox -egenconfig
