===================================
 networking_baremetal Release Notes
===================================

.. toctree::
   :maxdepth: 1

   unreleased
   pike
