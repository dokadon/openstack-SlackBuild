.. networking-baremetal documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to networking-baremetal's documentation!
================================================

.. include:: ../../README.rst

.. toctree::
   :maxdepth: 2

Installation Guide
==================

.. toctree::
  :maxdepth: 2

  install/index

Configuration Guide
===================

.. toctree::
  :maxdepth: 2

  configuration/index

Contributor Guide
=================

.. toctree::
   :maxdepth: 3

   contributor/index

Release Notes
=============

`Release Notes <https://docs.openstack.org/releasenotes/networking-baremetal/>`_

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
