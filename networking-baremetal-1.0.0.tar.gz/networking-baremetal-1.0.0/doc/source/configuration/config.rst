=====================
Configuration Options
=====================

The following is an overview of all available configuration options in
networking-baremetal. For a sample configuration file, refer to
:doc:`sample-config`.

.. show-options::
   :config-file: tools/config/networking-baremetal-config-generator.conf