==================================================
Cinder Administration Documentation (source/admin)
==================================================

Introduction:
-------------

This directory is intended to hold any documentation that relates to
how to run or operate Cinder.  Previously, this content was in the
admin-guide section of openstack-manuals.

The full spec for organization of documentation may be seen in the
`OS Manuals Migration Spec
<https://specs.openstack.org/openstack/docs-specs/specs/pike/os-manuals-migration.html>`.


