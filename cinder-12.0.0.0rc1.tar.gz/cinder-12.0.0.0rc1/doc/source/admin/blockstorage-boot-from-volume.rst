================
Boot from volume
================

In some cases, you can store and run instances from inside volumes.
For information, see `Launch an instance from a volume`_.

.. _`Launch an instance from a volume`: https://docs.openstack.org/nova/latest/user/create-instance-from-volume.html
