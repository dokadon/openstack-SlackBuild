==========================
 Cinder Scheduler Weights
==========================

.. list-plugins:: cinder.scheduler.weights
    :detailed:
