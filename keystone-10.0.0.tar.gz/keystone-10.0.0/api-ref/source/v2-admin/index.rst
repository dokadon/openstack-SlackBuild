:tocdepth: 2

=====================================
 Identity Admin API v2.0 (DEPRECATED)
=====================================

.. rest_expand_all::

.. include:: admin-tenants.inc
.. include:: admin-tokens.inc
.. include:: admin-users.inc
.. include:: admin-endpoints.inc
.. include:: admin-versions.inc
