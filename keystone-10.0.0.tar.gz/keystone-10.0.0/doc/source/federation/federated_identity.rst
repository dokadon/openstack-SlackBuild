==================
Federated Identity
==================

Keystone's one-stop-shop for all federated identity documentation.

.. include:: configure_federation.rst
.. include:: mapping_combinations.rst
.. include:: openidc.rst
.. include:: mellon.rst
.. include:: shibboleth.rst
.. include:: websso.rst
