==============================
Keystone Configuration Options
==============================

The following is a sample keystone configuration for adaptation and use. It is
auto-generated from keystone when this documentation is built, so if you are
having issues with an option, please compare your version of keystone with the
version of this documentation.

The sample configuration can also be viewed in `file form <_static/keystone.conf.sample>`_.

.. literalinclude:: _static/keystone.conf.sample
