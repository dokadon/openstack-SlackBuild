=======================================
Networking-hyperv Configuration Options
=======================================

The following is a sample networking-hyperv configuration for adaptation and
use.

The sample configuration can also be viewed in :download:`file from
</_static/networking-hyperv.conf.sample>`.

.. important::

   The sample configuration file is auto-generated from networking-hyperv when
   this documentation is built. You must ensure your version of
   networking-hyperv matches the version of this documentation.

.. literalinclude:: /_static/networking-hyperv.conf.sample
