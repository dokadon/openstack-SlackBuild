==============
oslo.messaging
==============

The Oslo messaging API supports RPC and notifications over a number of
different messaging transports.


.. toctree::
   :maxdepth: 1

   contributor/index
   configuration/index
   admin/index
   user/index
   reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

