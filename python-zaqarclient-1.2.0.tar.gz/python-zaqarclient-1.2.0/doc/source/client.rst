------
Client
------

.. automodule:: zaqarclient.queues.client

.. currentmodule:: zaqarclient.queues.client


Client Object Reference
-----------------------

This is the reference documentation for the latest, recommended, API version.

.. Link here older API versions, if any.

.. autoclass:: zaqarclient.queues.v1.client.Client
   :members:
