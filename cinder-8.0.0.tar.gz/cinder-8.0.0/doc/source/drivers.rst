===================
 Available Drivers
===================

.. list-plugins:: oslo_messaging.notify.drivers
    :detailed:
