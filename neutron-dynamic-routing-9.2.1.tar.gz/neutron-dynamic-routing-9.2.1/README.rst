This package contains neutron-dynamic-routing code which depends upon neutron
and it's related libraries to run.

External Resources
==================

The homepage for Neutron is: http://launchpad.net/neutron.  Use this
site for asking for help, and filing bugs. We use a single launchpad
page for all Neutron projects.

Code is available on git.openstack.org at:
<http://git.openstack.org/cgit/openstack/neutron-dynamic-routing>

Refer to Neutron documentation for more information:
`Neutron README.rst <http://git.openstack.org/cgit/openstack/neutron/tree/README.rst>`_
