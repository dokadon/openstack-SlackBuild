=======================
 Configuration Options
=======================

oslo.messaging uses oslo.config to define and manage configuration
options to allow the deployer to control how an application uses the
underlying messaging system.

.. show-options:: oslo.messaging

API
===

.. currentmodule:: oslo_messaging.opts

.. autofunction:: list_opts
