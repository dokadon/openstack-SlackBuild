Configuring iSCSI-based drivers
-------------------------------

Ensure that the ``qemu-img`` and ``iscsiadm`` tools are installed on the
**ironic-conductor** host(s).
