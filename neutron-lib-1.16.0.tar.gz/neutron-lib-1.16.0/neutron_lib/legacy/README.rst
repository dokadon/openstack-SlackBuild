===========================
neutron-lib legacy routines
===========================

This is a special namespace with lower deprecation policy standards,
and specific rules for its use. Please refer to the 'Legacy Modules'
section of this library's 'conventions' document for more information.
