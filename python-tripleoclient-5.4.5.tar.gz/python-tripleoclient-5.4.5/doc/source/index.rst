=============
tripleoclient
=============

tripleoclient is an OpenStackClient plugin.

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   command-list
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
