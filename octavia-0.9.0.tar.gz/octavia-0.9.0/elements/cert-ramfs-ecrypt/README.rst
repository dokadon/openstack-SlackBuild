Element to setup a ramfs with ecrypt to store the TLS certificates and keys.

Enabling this element will mean that the amphroa can no longer recover from a
reboot.
