=========
Using CLI
=========

monasca CLI
-----------

.. toctree::
   :maxdepth: 2

   monasca CLI guide <monasca>
   monasca CLI formatting <monasca-formatting>
   monasca CLI debugging <monasca-debug>
