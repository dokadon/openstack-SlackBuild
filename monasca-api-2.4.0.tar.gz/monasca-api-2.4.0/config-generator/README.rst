================
config-generator
================

To generate sample configuration file execute::

  tox -e genconfig
