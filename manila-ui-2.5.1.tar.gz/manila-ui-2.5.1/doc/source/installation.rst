============
Installation
============

At the command line::

    $ pip install manila-ui

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv manila-ui
    $ pip install manila-ui