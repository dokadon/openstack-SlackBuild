=============================
 OpenStack Sphinx Extensions
=============================

.. image:: https://img.shields.io/pypi/v/oslosphinx.svg
    :target: https://pypi.python.org/pypi/oslosphinx/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/oslosphinx.svg
    :target: https://pypi.python.org/pypi/oslosphinx/
    :alt: Downloads

Theme and extension support for Sphinx documentation from the
OpenStack project.

* Free software: Apache License, Version 2.0
* Documentation: http://docs.openstack.org/developer/oslosphinx
* Source: http://git.openstack.org/cgit/openstack/oslosphinx
* Bugs: http://bugs.launchpad.net/oslosphinx
