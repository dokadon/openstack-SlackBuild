==============
Uninstallation
==============

To uninstall this plugin, use ``pip uninstall heat-dashboard``
in your Horizon's virtual environment.

You also need to remove following files::

_1610_project_orchestration_panel.py
_1620_project_stacks_panel.py
_1630_project_resource_types_panel.py
_1640_project_template_versions_panel.py
_1650_project_template_generator_panel.py
