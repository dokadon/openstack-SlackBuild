.. _next-steps:

==========
Next steps
==========

Your OpenStack environment now includes Object Storage.

To add more services, see the
`additional documentation on installing OpenStack <http://docs.openstack.org/#install-guides>`_ .
