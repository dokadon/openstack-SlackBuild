:tocdepth: 2

===================
 Object Storage API
===================

.. rest_expand_all::

.. include:: storage_info.inc
.. include:: storage-account-services.inc
.. include:: storage-container-services.inc
.. include:: storage-object-services.inc
.. include:: storage_endpoints.inc


