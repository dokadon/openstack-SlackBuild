============
Installation
============

At the command line::

    $ pip install python-cloudkittyclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-cloudkittyclient
    $ pip install python-cloudkittyclient
