========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/neutron.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

Welcome!
========

To learn more about neutron:

  * Documentation: https://docs.openstack.org
  * Features: https://specs.openstack.org/openstack/neutron-specs
  * Defects: https://launchpad.net/neutron

Get in touch via `email <mailto:openstack-dev@lists.openstack.org>`_. Use
[Neutron] in your subject.

To learn how to contribute:

  CONTRIBUTING.rst
