=============
Release Notes
=============

See https://docs.openstack.org/releasenotes/networking-midonet/.
