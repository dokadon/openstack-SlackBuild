===============================================
 oslo.rootwrap -- Escalated Permission Control
===============================================

oslo.rootwrap allows fine-grained filtering of shell commands to run
as `root` from OpenStack services.

.. toctree::
   :maxdepth: 2

   installation
   usage
   contributing

Release Notes
=============

.. toctree::
   :maxdepth: 1

   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
