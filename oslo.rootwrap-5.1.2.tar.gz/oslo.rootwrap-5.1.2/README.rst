===============================================
 oslo.rootwrap -- Escalated Permission Control
===============================================

.. image:: https://img.shields.io/pypi/v/oslo.rootwrap.svg
    :target: https://pypi.python.org/pypi/oslo.rootwrap/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/oslo.rootwrap.svg
    :target: https://pypi.python.org/pypi/oslo.rootwrap/
    :alt: Downloads

oslo.rootwrap allows fine-grained filtering of shell commands to run
as `root` from OpenStack services.

* License: Apache License, Version 2.0
* Documentation: http://docs.openstack.org/developer/oslo.rootwrap
* Source: http://git.openstack.org/cgit/openstack/oslo.rootwrap
* Bugs: http://bugs.launchpad.net/oslo.rootwrap
