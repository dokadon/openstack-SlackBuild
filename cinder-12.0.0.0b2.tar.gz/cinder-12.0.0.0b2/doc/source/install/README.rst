==================================================
Cinder Installation Documentation (source/install)
==================================================

Introduction:
-------------

This directory is intended to hold any installation documentation for Cinder.
Documentation that explains how to bring Cinder up to the point that it is
ready to use in an OpenStack or standalone environment should be put
in this directory.

The full spec for organization of documentation may be seen in the
`OS Manuals Migration Spec
<https://specs.openstack.org/openstack/docs-specs/specs/pike/os-manuals-migration.html>`.
