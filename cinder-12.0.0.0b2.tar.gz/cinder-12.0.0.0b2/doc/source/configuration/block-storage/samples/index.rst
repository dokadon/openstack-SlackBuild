.. _block-storage-sample-configuration-file:

================================================
Block Storage service sample configuration files
================================================

All the files in this section can be found in ``/etc/cinder``.

.. toctree::
   :maxdepth: 2

   cinder.conf.rst
   api-paste.ini.rst
   policy.json.rst
   rootwrap.conf.rst
