===========
policy.json
===========

The ``policy.json`` file defines additional access controls that apply
to the Block Storage service.

.. literalinclude:: policy.json.inc
