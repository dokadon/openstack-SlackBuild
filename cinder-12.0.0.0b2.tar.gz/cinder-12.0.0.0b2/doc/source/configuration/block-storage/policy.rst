====================
Policy configuration
====================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Cinder.

.. show-policy::
   :config-file: tools/config/cinder-policy-generator.conf
