=================================================
Cinder Reference Documentation (source/reference)
=================================================

Introduction:
-------------

This directory is intended to hold any reference documentation for Cinder
that doesn't fit into 'install', 'contributor', 'configuration', 'cli',
'admin', or 'user' categories.

The full spec for organization of documentation may be seen in the
`OS Manuals Migration Spec
<https://specs.openstack.org/openstack/docs-specs/specs/pike/os-manuals-migration.html>`.

