======================
Command Line Reference
======================

.. autoprogram-cliff:: openstack.placement.v1