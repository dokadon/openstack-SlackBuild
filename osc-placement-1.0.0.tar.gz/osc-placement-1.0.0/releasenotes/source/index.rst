============================================
 osc_placement Release Notes
============================================

.. toctree::
   :maxdepth: 1

   unreleased
