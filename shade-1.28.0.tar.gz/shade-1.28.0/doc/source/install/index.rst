============
Installation
============

At the command line::

    $ pip install shade

Or, if you have virtualenv wrapper installed::

    $ mkvirtualenv shade
    $ pip install shade
