==================
 Shade User Guide
==================

.. toctree::
   :maxdepth: 2

   usage
   logging
   model
   microversions

Presentations
=============

.. toctree::
   :maxdepth: 1

   multi-cloud-demo
