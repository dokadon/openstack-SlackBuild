Sample Designate Notification Handler Extension
===============================================

This repo provides a sample plugin for a custom notification handler.
