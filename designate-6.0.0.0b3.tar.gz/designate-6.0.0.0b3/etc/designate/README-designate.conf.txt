To generate the sample designate.conf file, run the following command from the top
level of the designate directory:

    tox -e genconfig