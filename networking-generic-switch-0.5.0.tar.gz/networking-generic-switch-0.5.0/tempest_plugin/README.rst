================================================
Tempest Integration of Networking Generic Switch
================================================

This directory contains Tempest tests for networking-generic-switch project.

