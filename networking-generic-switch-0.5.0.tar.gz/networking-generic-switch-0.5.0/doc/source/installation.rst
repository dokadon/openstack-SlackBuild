============
Installation
============

This sections describes how to install and configure networking-generic-switch
plugin.

At the command line::

    $ pip install networking-generic-switch

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-generic-switch
    $ pip install networking-generic-switch

.. include:: include/configure-neutron.rst
