Welcome to networking-generic-switch's documentation!
=====================================================

.. include:: ./readme.rst

.. toctree::
   :maxdepth: 2

   installation
   dev/dev-quickstart
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
