============
Installation
============

At the command line::

    $ pip install designate_dashboard

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv designate_dashboard
    $ pip install designate_dashboard