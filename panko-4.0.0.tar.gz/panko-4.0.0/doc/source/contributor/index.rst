==================
Contribution Guide
==================

In the Contribution Guide, you will find documented policies for
developing with Panko. This includes the processes we use for
bugs, contributor onboarding, core reviewer memberships, and other
procedural items.

.. toctree::
   :maxdepth: 2

   contributing
   testing
   gmr
