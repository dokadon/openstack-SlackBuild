.. include:: ../../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   installation
   usage
   examples
   contributing
   history

Code Documentation
==================

.. toctree::
   :maxdepth: 1

   api/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
