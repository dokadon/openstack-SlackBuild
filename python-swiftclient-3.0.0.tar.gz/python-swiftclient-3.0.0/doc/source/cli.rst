===
CLI
===

Top-level commands
~~~~~~~~~~~~~~~~~~

.. TODO
   
   delete
   download
   list
   post
   stat
   upload
   info/capabilities
   tempurl
   auth

Prescriptive examples
~~~~~~~~~~~~~~~~~~~~~

.. TODO
  
   A "Hello World" example
   uploading an object
   creating a tempurl
   listing the contents of a container
   downloading an object