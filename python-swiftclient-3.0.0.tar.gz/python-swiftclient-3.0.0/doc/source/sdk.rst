===
SDK
===

Where to start?
~~~~~~~~~~~~~~~

.. TODO
  
   when to use SwiftService
   when to use client.py

SwiftService classes and methods
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO
  
   docs for each method (autogen from docstrings?)

Client classes and methods
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO
   
   docs for each method (autogen from docstrings?)

Guidelines for writing an app
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO
   
   auth
   how to use various features
   when to use various features
   pooling connections
   concurrency
   retries

Prescriptive examples
~~~~~~~~~~~~~~~~~~~~~

.. TODO

   A "Hello World" example
   connecting
   uploading an object
   uploading a directory
   