.. _barbican-policy-generator.conf:

====================
Policy configuration
====================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Barbican. For a sample
configuration file.

.. show-policy::
      :config-file: ../../etc/oslo-config-generator/policy.conf
