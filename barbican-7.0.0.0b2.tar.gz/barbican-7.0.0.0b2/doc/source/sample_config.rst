==================================
Barbican Sample Configuration File
==================================

Use the ``barbican.conf`` file to configure most Key Manager service
options:

.. literalinclude:: _static/barbican.conf.sample
