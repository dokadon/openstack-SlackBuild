========
barbican
========

.. _barbican_7.0.0.0b1:

7.0.0.0b1
=========

.. _barbican_7.0.0.0b1_Other Notes:

Other Notes
-----------

.. releasenotes/notes/change_default_control_exchange-c47abc3e3f08aa31.yaml @ aff00f016bf1b2205c4ff20ef94c73cd931eeff4

- default value of 'control_exchange' in 'barbican.conf' has been changed to 'keystone'.

