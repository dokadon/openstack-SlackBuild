.. include:: ../../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   install/index
   contributor/index
   configuration/index
   admin/index
   reference/index
   glossary

Release Notes
=============

.. toctree::
   :maxdepth: 1

   user/history
