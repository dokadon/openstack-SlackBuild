=======================================
manila-ui - Manila Management Dashboard
=======================================

* Free software: Apache license
* Documentation: https://docs.openstack.org/manila-ui/latest/
* Source: https://git.openstack.org/cgit/openstack/manila-ui
* Bugs: https://bugs.launchpad.net/manila-ui

Team and repository tags
------------------------

.. image:: https://governance.openstack.org/badges/manila-ui.svg
    :target: https://governance.openstack.org/reference/tags/index.html
