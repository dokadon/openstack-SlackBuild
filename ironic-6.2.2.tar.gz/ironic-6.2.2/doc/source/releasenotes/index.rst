=============
Release Notes
=============

The official location for release notes is:
http://docs.openstack.org/releasenotes/ironic.

This page is old and not up-to-date but retained to prevent links to this
page from breaking.

4.2.1
=====

Release notes: http://docs.openstack.org/releasenotes/ironic/liberty.html#V4-2-1

4.2.0
=====

Release notes: http://docs.openstack.org/releasenotes/ironic/liberty.html#V4-2-0

4.1.0
=====

Release notes: http://docs.openstack.org/releasenotes/ironic/liberty.html#V4-1-0

4.0.0   First semver release
============================

Release notes: http://docs.openstack.org/releasenotes/ironic/liberty.html#V4.0.0

2015.1.0    OpenStack "Kilo" Release
====================================

Release notes: https://wiki.openstack.org/wiki/ReleaseNotes/Kilo#OpenStack_Bare_Metal_service_.28Ironic.29


2014.2.0    OpenStack "Juno" Release
====================================

Release notes: https://wiki.openstack.org/wiki/Ironic/ReleaseNotes/Juno

2014.1.0    OpenStack "Icehouse" Release
========================================

Release notes: https://wiki.openstack.org/wiki/Ironic/ReleaseNotes/Icehouse

