from shade.openstackcloud import OpenStackCloud as OperatorCloud  # noqa
