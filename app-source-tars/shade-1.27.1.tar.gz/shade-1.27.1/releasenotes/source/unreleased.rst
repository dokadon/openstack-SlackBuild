=====================
 Unreleased Versions
=====================

.. NOTE(dhellmann): The earliest-version field is set to avoid
   duplicating *all* of the history on this page. When we start
   creating stable branches the history should be truncated
   automatically and we can remove the setting.

.. release-notes::
   :earliest-version: 1.17.0
