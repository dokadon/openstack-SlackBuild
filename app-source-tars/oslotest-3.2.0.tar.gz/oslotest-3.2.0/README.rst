========================
Team and repository tags
========================

.. image:: http://governance.openstack.org/badges/oslotest.svg
    :target: http://governance.openstack.org/reference/tags/index.html

.. Change things from this point on

=======================================================
 oslotest -- OpenStack Testing Framework and Utilities
=======================================================

The Oslo Test framework provides common fixtures, support for debugging, and
better support for mocking results.

* Free software: Apache license
* Documentation: https://docs.openstack.org/oslotest/latest/
* Source: https://git.openstack.org/cgit/openstack/oslotest
* Bugs: https://bugs.launchpad.net/oslotest
