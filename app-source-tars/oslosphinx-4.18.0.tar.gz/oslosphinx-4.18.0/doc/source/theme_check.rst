===========
Theme check
===========

This page is used to check the themes provided by oslosphinx.

.. note::

   A comment with additional information that explains a part of the text.

.. important::

   Something you must be aware of before proceeding.

.. tip::

   An extra but helpful piece of practical advice.

.. Caution::

   Helpful information that prevents the user from making mistakes.

.. Warning::

   Critical information about the risk of data loss or security issues.
