=============================
 OpenStack Sphinx Extensions
=============================

oslosphinx is obsolete. The openstackdocstheme package should be used
instead. oslosphinx will be maintained for the pike, ocata, and newton
release series and completely remove after that pike is marked
end-of-life.

The contents of this repository are still available in the Git source
code management system.  To see the contents of this repository before
it reached its end of life, please check out the previous commit with
"git checkout HEAD^1", or check out one of the supported stable
branches.

For any further questions, please email
openstack-dev@lists.openstack.org or join #openstack-oslo on Freenode.
