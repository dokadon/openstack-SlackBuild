========
Usage
========

To use instack in a project::

	import instack