============
Installation
============

At the command line::

    $ pip install instack

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv instack
    $ pip install instack