CREATE TABLE `notification_method_type` (
  `name` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
);
