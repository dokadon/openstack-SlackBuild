.. _configuring:

=============
Configuration
=============

.. toctree::
   :maxdepth: 1

   sample
