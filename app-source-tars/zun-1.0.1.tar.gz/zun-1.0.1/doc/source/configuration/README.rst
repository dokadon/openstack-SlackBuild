======================================================
Zun Configuration Documentation (source/configuration)
======================================================


This directory is intended to hold any documentation that relates
to how to configure Zun. It is intended that some of this content
be automatically generated in the future. At the moment, however,
it is not. Changes to configuration options for Zun or its drivers
needs to be put under this directory.
