=========================
Zun Configuration Options
=========================

The following is a sample Zun configuration for adaptation and use. It is
auto-generated from Zun when this documentation is built, so
if you are having issues with an option, please compare your version of
Zun with the version of this documentation.

The sample configuration can also be viewed in :download:`file form
</_static/zun.conf.sample>`.

.. literalinclude:: /_static/zun.conf.sample
