=============================
Externally Installed Services
=============================

The services in this directory and the Ansible hook they use
(`external_deploy_tasks`) are currently considered experimental.
