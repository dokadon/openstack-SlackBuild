3. Populate Magnum database:

   .. code-block:: console

      # su -s /bin/sh -c "magnum-db-manage upgrade" magnum
