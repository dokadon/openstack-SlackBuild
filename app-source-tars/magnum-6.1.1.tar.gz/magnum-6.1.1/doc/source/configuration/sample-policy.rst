====================
Policy configuration
====================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Magnum. For a sample
configuration file, refer to :doc:`samples/policy-yaml`.

.. show-policy::
   :config-file: ../../etc/magnum/magnum-policy-generator.conf
