.. _option-definitions:

=====================
Configuration Options
=====================

oslo.reports uses oslo.config to define and manage configuration options
to allow the deployer to control where the GMR reports should be generated.

.. show-options:: oslo.reports
