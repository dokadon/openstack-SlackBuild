Mistral Admin Guide
=====================

.. toctree::
   :maxdepth: 1

   upgrade_guide
