Mistral Configuration and Policy Guide
--------------------------------------

.. toctree::
    :maxdepth: 2

    config-guide.rst
    policy-guide.rst
    samples/index.rst
