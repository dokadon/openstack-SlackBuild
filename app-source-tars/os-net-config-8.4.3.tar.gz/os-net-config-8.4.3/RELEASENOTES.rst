=============
os-net-config
=============

.. _os-net-config_8.4.0:

8.4.0
=====

.. _os-net-config_8.4.0_New Features:

New Features
------------

.. releasenotes/notes/dpdk-on-mellanox-nics-1d8fdb843a4e2b60.yaml @ 193928916e1d831b4790026efd85c56c611297e8

- Adding dpdk support in meallnox nics.
  Dpdk now fully suuported in mellanox nics.

