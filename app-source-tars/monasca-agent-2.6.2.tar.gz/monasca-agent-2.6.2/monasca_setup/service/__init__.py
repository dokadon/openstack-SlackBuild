# (C) Copyright 2015 Hewlett Packard Enterprise Development Company LP

from service import Service
