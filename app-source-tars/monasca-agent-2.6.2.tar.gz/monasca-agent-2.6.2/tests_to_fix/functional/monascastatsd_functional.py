"""
Functional tests for dogstatsd.
"""
