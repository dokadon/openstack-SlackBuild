default_target = 'DEFAULT'
specified_target = 'SPECIFIED'
