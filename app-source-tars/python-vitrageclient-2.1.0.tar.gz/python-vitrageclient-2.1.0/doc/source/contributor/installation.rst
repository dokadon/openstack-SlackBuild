============
Installation
============

At the command line::

    $ pip install python-vitrageclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-vitrageclient
    $ pip install python-vitrageclient

