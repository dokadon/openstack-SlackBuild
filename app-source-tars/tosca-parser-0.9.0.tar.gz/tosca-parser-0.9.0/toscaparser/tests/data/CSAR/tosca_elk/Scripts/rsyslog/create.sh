#!/bin/bash
# This script installs rsyslog and the library for RELP

apt-get update
apt-get install -y rsyslog rsyslog-relp
