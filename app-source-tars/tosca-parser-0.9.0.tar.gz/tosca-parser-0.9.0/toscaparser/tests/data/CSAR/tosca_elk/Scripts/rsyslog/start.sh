#!/bin/bash
# This script starts rsyslogd as a service in init.d
service rsyslog stop
service rsyslog start
