#!/bin/bash

exit 42
