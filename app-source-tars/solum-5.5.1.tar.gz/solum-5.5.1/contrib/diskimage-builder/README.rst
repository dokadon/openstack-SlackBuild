Setup
-----
These scripts require installation of OpenStack diskimage-builder
https://github.com/openstack/diskimage-builder

The package is available on Ubuntu, Fedora, and Red Hat Enterprise Linux
