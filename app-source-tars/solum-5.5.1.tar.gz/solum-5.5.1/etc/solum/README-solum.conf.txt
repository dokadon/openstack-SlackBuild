To generate the sample solum.conf file, run the following
command from the top level of the solum directory:

tox -egenconfig
