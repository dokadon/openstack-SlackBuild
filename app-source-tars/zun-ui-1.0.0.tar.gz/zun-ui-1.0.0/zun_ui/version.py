import pbr.version

version_info = pbr.version.VersionInfo('zun-ui')
