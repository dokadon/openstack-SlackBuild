# config-generator

To generate sample configuration execute

```sh
tox -e genconfig
```
