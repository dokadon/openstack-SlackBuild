==============================
Blazar Configuration Reference
==============================

Configuration
-------------

Reference
^^^^^^^^^

.. toctree::

   blazar-conf.rst
   nova-conf.rst


Sample Files
^^^^^^^^^^^^

.. toctree::

   samples/blazar-conf.rst

Policy
------

Reference
^^^^^^^^^

.. toctree::

   blazar-policy.rst

Sample Files
^^^^^^^^^^^^

.. toctree::

   samples/blazar-policy.rst
