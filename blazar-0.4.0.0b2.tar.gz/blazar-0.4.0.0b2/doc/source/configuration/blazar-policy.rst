========
Policies
========

Please see a sample policy file: :doc:`/configuration/samples/blazar-policy`.
