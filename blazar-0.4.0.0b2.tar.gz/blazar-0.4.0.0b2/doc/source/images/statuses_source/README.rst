Status graphs
=============

Status graphs are drawn by `draw.io`_ . To edit graphs, open `draw.io`_,
select *Open Existing Diagram* and chose the *\*_statuses.xml* file under this
directory.

.. _draw.io: <https://www.draw.io/>
