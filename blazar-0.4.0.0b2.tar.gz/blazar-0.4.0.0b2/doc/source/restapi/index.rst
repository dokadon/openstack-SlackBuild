====================
Blazar REST API docs
====================

.. toctree::
   :maxdepth: 1

   api-v1
   api-v2
