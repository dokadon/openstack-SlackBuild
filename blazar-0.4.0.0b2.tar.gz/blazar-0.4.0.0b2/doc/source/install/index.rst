=========================
Blazar Installation Guide
=========================

.. toctree::

   install-using-devstack.rst
   install-without-devstack.rst
