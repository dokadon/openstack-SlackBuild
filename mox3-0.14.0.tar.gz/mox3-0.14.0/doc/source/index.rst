mox3
====

A fork of mox with Python 3 support.

Contents
========

.. toctree::
   :maxdepth: 2

   readme
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

