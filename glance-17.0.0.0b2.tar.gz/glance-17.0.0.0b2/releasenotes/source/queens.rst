===================================
 Queens Series Release Notes
===================================

.. release-notes::
   :branch: stable/queens
   :ignore-notes:
      pike-rc-2-acc173005045e16a.yaml
