================
ip floating pool
================

Compute v2

ip floating pool list
---------------------

List pools of floating IP addresses

.. program:: ip floating pool list
.. code:: bash

    os ip floating pool list
