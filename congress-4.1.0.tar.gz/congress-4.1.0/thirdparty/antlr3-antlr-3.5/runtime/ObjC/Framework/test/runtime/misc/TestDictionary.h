//
//  TestDictionary.h
//  ST4
//
//  Created by Alan Condit on 4/20/11.
//  Copyright 2011 Alan Condit. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface TestDictionary : SenTestCase {
@private
    
}

- (void) test01add;
- (void) test02add;
- (void) test03add;
- (void) test04removefromLo;
- (void) test05removefromHi;

@end
