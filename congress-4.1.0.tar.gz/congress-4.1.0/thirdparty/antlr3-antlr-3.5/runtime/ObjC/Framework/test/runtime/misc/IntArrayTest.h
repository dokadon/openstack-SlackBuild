//
//  IntArrayTest.h
//  ANTLR
//
//  Created by Ian Michell on 13/05/2010.
//  Copyright 2010 Ian Michell. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface IntArrayTest : SenTestCase 
{

}

-(void) testAdd;
-(void) testPushPop;
-(void) testClearAndAdd;

@end
