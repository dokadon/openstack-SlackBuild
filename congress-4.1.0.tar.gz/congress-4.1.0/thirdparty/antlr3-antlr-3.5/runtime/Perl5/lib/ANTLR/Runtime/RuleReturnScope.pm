package ANTLR::Runtime::RuleReturnScope;

use Moose;

sub get_start {
    return;
}

sub get_stop {
    return;
}

sub get_tree {
    return;
}

sub get_template {
    return;
}

no Moose;
__PACKAGE__->meta->make_immutable();
1;
