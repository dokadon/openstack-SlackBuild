
.. |ad| replace:: ActiveDirectory

