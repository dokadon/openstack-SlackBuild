===============
software config
===============


.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software config list

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software config create

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software config show

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software config delete
