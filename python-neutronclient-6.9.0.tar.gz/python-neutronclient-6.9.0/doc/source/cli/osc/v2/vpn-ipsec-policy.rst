================
VPN IPsec Policy
================

The **IPsec Policy** specifies the authentication and encryption algorithms
and encapsulation mode to use for the established VPN connection.

Network v2

.. autoprogram-cliff:: openstack.neutronclient.v2
   :command: vpn ipsec policy *
