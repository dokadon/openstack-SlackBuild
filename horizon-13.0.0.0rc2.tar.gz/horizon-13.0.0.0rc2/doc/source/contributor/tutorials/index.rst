=========
Tutorials
=========

Detailed tutorials to help you get started.

.. toctree::
   :maxdepth: 1

   plugin
   dashboard
   table_actions
   workflow_extend
