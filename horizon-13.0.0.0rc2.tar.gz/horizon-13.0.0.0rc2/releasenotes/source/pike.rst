===================================
 Pike Series Release Notes
===================================

.. release-notes::
   :branch: stable/pike
   :ignore-notes:
     admin-neutron-l3-agents-dd6274467572906b.yaml,
     bp-add-server-metadata-a5d5582966ef25c5.yaml,
     bp-admin-views-filter-first-5b0d8a02b1271135.yaml,
     bp-angular-template-overrides-9f05ffd61367245a.yaml,
     bp-cinder-consistency-groups-7cc98fda0ff3bb7a.yaml,
     bp-cinder-consistency-groups-b0aba555b1ed4a6c.yaml,
     bp-configurable-boot-sources-4ba89f3b2a927801.yaml,
     bp-edit-server-metadata-7e6b00946a2e793a.yaml,
     bp-horizon-vendor-split-4451bc1988485957.yaml,
     bp-port-allowed-address-pairs-extension-a05c3a864f494b0c.yaml,
     dynamic-themes-b6b02238e47b99f8.yaml,
     extensible-service-a8689c89a71f8961.yaml,
     gb-to-gib-conversion-8a91839030a2f570.yaml,
     global-class-name-convention-71ff68913c39b800.yaml,
     keystone-federation-idp-d4456dd3b3081a53.yaml,
     workflow-step-policy-1ca99b0249294337.yaml,
     glance-v2-ba86ba34611f95ce.yaml
