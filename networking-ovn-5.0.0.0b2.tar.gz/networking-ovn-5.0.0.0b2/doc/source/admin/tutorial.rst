==========================
OpenStack and OVN Tutorial
==========================

The OVN project documentation includes an in depth tutorial of using OVN with
OpenStack.

`OpenStack and OVN Tutorial <http://docs.openvswitch.org/en/latest/tutorials/ovn-openstack/>`_
