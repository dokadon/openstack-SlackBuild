=====================
Install Documentation
=====================
.. _installation:

The ``networking-ovn`` repository includes integration with DevStack that
enables creation of a simple Open Virtual Network (OVN) development and test
environment.

.. toctree::
   :maxdepth: 2

   manual
   tripleo
