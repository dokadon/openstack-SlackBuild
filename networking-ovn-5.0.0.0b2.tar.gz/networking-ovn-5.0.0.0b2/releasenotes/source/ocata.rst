===================================
 Ocata Series Release Notes
===================================

.. release-notes::
   :branch: stable/ocata
   :earliest-version: 2.0.0
