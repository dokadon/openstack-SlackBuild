==================================
Automatic deployment using Vagrant
==================================

Please reference the files in /doc/source/contributor/vagrant/ for more
information about this.
