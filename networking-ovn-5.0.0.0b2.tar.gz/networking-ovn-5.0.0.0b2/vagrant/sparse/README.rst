===================
Sparse architecture
===================

Please reference the files in /doc/source/contributor/vagrant/sparse.rst for
more information about this architecture.


