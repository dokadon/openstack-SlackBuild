========
Usage
========

To use neutron-lbaas-dashboard in a project::

    import neutron_lbaas_dashboard
