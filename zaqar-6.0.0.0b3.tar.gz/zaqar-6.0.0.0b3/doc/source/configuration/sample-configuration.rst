.. _sample-configuration:

==========================
Zaqar Sample Configuration
==========================

The following are sample configuration files for all Zaqar services and
utilities. These are generated from code and reflect the current state of code
in the Zaqar repository.


Sample configuration for Zaqar API
----------------------------------

This sample configuration can also be viewed in `zaqar.conf.sample
<../_static/zaqar.conf.sample>`_.

.. literalinclude:: ../_static/zaqar.conf.sample
