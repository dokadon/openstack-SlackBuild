=============
 exception
=============

.. automodule:: oslo_versionedobjects.exception
   :members:
