=============
 base
=============

.. automodule:: oslo_versionedobjects.base
   :members:
