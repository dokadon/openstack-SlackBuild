================================
Searchlight Policy Configuration
================================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Searchlight.
For a sample configuration file, refer to :doc:`sample-policy-yaml`.

.. show-policy::
   :config-file: ../../etc/oslo-policy-generator/searchlight.conf
