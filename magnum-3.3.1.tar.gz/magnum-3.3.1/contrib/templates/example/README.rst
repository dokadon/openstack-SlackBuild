========================
Example Cluster Template
========================

See `<http://docs.openstack.org/developer/magnum/dev/cluster-type-definition.html>`_ for instructions.
