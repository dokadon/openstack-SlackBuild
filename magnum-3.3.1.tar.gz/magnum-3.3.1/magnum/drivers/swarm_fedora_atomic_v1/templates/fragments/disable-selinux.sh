#cloud-boothook
#!/bin/sh

setenforce 0
