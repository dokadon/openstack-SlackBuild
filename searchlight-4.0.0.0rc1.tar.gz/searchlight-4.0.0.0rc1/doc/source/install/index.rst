====================
 Installation guide
====================

.. toctree::
   :maxdepth: 2

   dev-environment
   elasticsearch
   uwsgi
