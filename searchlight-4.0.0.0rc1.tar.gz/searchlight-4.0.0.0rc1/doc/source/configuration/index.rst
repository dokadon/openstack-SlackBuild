=====================
 Configuration guide
=====================

.. toctree::
   :maxdepth: 2

   authentication
   plugins
   policy
   sample-policy-yaml
