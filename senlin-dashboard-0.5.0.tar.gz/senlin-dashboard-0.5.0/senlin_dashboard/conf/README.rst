==================
Senlin Policy File
==================

Enable senlin policy::

    $ cp senlin_dashboard/conf/senlin_policy.json horizon/openstack_dashboard/conf
