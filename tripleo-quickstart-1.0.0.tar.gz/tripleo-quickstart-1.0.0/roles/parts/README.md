These roles install and/or configure individual components, and should
not depend on any configuration or roles from outside of the `parts/`
directory.
