#!/bin/bash

git shortlog -se | cut -c8-
