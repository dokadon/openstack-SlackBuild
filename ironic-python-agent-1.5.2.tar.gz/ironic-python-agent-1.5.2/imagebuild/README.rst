ironic-python-agent images
==========================

coreos - Builds a CoreOS Ramdisk and Kernel suitable for running
ironic-python-agent

tinyipa - Builds a TinyCoreLinux Ramdisk and Kernel suitable for running
ironic-python-agent
