======================
 Administration guide
======================

.. toctree::
   :maxdepth: 2
   :glob:

   architecture
   indexingservice
   plugins/*