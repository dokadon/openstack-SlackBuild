============
Installation
============

At the command line::

    $ pip install openstacksdk

Or, if you have virtualenv wrapper installed::

    $ mkvirtualenv openstacksdk
    $ pip install openstacksdk
