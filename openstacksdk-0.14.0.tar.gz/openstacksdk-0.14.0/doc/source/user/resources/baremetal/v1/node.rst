openstack.baremetal.v1.Node
===========================

.. automodule:: openstack.baremetal.v1.node

The Node Class
--------------

The ``Node`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.node.Node
   :members:
