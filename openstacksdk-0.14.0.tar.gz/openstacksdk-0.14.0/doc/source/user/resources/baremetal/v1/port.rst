openstack.baremetal.v1.port
===========================

.. automodule:: openstack.baremetal.v1.port

The Port Class
--------------

The ``Port`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.port.Port
   :members:
