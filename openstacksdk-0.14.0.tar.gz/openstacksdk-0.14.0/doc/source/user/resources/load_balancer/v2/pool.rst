openstack.load_balancer.v2.pool
===============================

.. automodule:: openstack.load_balancer.v2.pool

The Pool Class
--------------

The ``Pool`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.load_balancer.v2.pool.Pool
   :members:
