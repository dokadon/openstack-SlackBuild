openstack.identity.v3.policy
============================

.. automodule:: openstack.identity.v3.policy

The Policy Class
----------------

The ``Policy`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.policy.Policy
   :members:
