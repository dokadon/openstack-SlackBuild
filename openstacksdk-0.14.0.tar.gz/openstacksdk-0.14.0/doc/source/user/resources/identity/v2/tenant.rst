openstack.identity.v2.tenant
============================

.. automodule:: openstack.identity.v2.tenant

The Tenant Class
----------------

The ``Tenant`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v2.tenant.Tenant
   :members:
