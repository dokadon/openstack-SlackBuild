openstack.object_store.v1.obj
=============================

.. automodule:: openstack.object_store.v1.obj

The Object Class
----------------

The ``Object`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.object_store.v1.obj.Object
   :members:
