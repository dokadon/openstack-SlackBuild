openstack.network.v2.auto_allocated_topology
============================================

.. automodule:: openstack.network.v2.auto_allocated_topology

The Auto Allocated Topology Class
---------------------------------

The ``Auto Allocated Toplogy`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.auto_allocated_topology.AutoAllocatedTopology
   :members:
