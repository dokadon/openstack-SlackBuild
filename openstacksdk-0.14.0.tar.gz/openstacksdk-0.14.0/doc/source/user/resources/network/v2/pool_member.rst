openstack.network.v2.pool_member
================================

.. automodule:: openstack.network.v2.pool_member

The PoolMember Class
--------------------

The ``PoolMember`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.pool_member.PoolMember
   :members:
