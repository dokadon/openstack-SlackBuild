openstack.network.v2.qos_policy
===============================

.. automodule:: openstack.network.v2.qos_policy

The QoSPolicy Class
-------------------

The ``QoSPolicy`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.qos_policy.QoSPolicy
   :members:
