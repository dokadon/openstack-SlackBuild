openstack.database.v1.user
==========================

.. automodule:: openstack.database.v1.user

The User Class
--------------

The ``User`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.database.v1.user.User
   :members:
