Mistral Terminology
===================

.. toctree::
   :maxdepth: 3

   workbooks
   workflows
   actions
   executions
   cron_triggers
