.. include:: ../../README.rst

.. toctree::
   :maxdepth: 2

   vendor-support
   contributing
   installation
   api-reference
   releasenotes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
