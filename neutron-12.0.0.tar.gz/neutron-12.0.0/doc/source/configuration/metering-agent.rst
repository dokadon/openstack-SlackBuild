==================
metering_agent.ini
==================

.. show-options::
   :config-file: etc/oslo-config-generator/metering_agent.ini
