.. _networking-obs:

============================================================
Install and configure for openSUSE and SUSE Linux Enterprise
============================================================

.. toctree::
   :maxdepth: 2

   environment-networking-obs.rst
   controller-install-obs.rst
   compute-install-obs.rst
   verify.rst
