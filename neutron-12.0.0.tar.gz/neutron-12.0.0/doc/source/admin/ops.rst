.. _operations:

==========
Operations
==========

.. toctree::
   :maxdepth: 2

   ops-ip-availability
   ops-resource-tags
   ops-resource-purge
