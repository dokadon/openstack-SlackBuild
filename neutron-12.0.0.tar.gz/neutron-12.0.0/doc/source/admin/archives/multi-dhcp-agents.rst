=========================================
Scalable and highly available DHCP agents
=========================================

This section is fully described at the
:doc:`High-availability for DHCP <../config-dhcp-ha>`
in the Networking Guide.
