===
ntp
===

Installs ntp daemon for sync time on VM
