===
kdc
===

Installs all needed artifacts for KDC server and Kerberos authentication

Environment Variables
---------------------

DIB_UNLIMITED_SECURITY_LOCATION
  :Required: No
  :Default: http://tarballs.openstack.org/sahara/dist/common-artifacts/
  :Description: Place where UnlimitedSecurity polices are located
