=========
xfs-tools
=========

This element installs a xfsprogs for formatting volumes to XFS file system.
