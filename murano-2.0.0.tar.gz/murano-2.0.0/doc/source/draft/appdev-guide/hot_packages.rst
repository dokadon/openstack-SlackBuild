.. _hot-packages:

.. toctree::
   :maxdepth: 2

============
HOT packages
============

.. include:: hotpackages/compose.rst

