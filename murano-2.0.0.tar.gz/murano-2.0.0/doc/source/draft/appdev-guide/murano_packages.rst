.. _murano-packages:

.. toctree::
   :maxdepth: 2

===============
Murano packages
===============

.. include:: muranopackages/package_structure.rst
.. include:: muranopackages/dynamic_ui.rst
.. include:: muranopackages/repository.rst
