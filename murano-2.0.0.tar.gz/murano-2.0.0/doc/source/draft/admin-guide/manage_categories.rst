.. _manage-categories:

.. toctree::
   :maxdepth: 2:

===================
Managing categories
===================
