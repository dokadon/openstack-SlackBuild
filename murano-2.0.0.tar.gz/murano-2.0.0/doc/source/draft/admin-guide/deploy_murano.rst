.. _install:

================
Deploying murano
================

.. toctree::
   :maxdepth: 2

   deploy_murano/devstack
   deploy_murano/install_manually
   deploy_murano/configure_ssl