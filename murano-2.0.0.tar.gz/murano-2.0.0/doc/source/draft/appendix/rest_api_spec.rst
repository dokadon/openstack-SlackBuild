.. _rest-api-spec:

.. toctree::
   :maxdepth: 2:

======================
REST API specification
======================
