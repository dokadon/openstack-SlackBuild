.. _testing:

.. toctree::
   :maxdepth: 2

=======
Testing
=======

Testing guidelines
~~~~~~~~~~~~~~~~~~

Continuous Integration service
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

UI testing
~~~~~~~~~~

Tempest tests
~~~~~~~~~~~~~

Automated testing machinery
~~~~~~~~~~~~~~~~~~~~~~~~~~~

CI design
---------
CI jobs
-------
