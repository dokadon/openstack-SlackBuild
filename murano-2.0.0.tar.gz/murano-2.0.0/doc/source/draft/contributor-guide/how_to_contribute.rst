.. _how_to_contribute:

=================
How to contribute
=================

.. TODO add a brief intro:
   - Intended audience.
   - How to start developing?
   - How a new-comer can contribute?
   - Communication channels
   - Useful links for an OpenStack contributor
   - consider the context of http://docs.openstack.org/developer/sahara/devref/how_to_participate.html
