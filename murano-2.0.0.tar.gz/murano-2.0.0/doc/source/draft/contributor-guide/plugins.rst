.. _plugins:

.. toctree::
   :maxdepth: 2

===============
Murano plug-ins
===============

.. include:: plugins/muranopl_extensions.rst

.. include:: plugins/package_type_plugins.rst
