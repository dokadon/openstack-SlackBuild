.. _dev-guidelines:

.. toctree::
   :maxdepth: 2

======================
Development guidelines
======================

Conventions
~~~~~~~~~~~

High-level overview of Murano components
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Coding guidelines
~~~~~~~~~~~~~~~~~

Debug tips
~~~~~~~~~~
