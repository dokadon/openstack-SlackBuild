.. _doc-guidelines:

.. toctree::
   :maxdepth: 2

========================
Documentation guidelines
========================
