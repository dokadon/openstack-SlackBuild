================
hypervisor stats
================

Compute v2

hypervisor stats show
---------------------

Display hypervisor stats details

.. program:: hypervisor stats show
.. code:: bash

    os hypervisor stats show

