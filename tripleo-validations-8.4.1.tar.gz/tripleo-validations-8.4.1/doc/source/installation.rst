============
Installation
============

At the command line::

    $ pip install tripleo-validations

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv tripleo-validations
    $ pip install tripleo-validations
