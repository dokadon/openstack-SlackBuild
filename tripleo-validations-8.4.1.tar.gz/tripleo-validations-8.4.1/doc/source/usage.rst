========
Usage
========

To use tripleo-validations in a project::

    import tripleo-validations
