==========================
Manila API Documentation
==========================

A full specification of the API for interacting with the shared file
systems service may be found in the `API reference
<https://developer.openstack.org/api-ref/shared-file-systems>`_.

