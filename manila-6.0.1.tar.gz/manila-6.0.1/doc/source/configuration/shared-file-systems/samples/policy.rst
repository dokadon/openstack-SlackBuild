====================
Policy configuration
====================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Manila.

.. show-policy::
   :config-file: etc/manila/manila-policy-generator.conf
