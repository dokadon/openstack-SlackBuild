=============
rootwrap.conf
=============

The ``rootwrap.conf`` file defines configuration values used by the
``rootwrap`` script when the Shared File Systems service must escalate
its privileges to those of the root user.

.. literalinclude:: ../../../../../etc/manila/rootwrap.conf
   :language: ini
