To generate the sample vitrage.conf file, run the following
command from the top-level vitrage directory:

tox -egenconfig

this will generate a vitrage.conf file in this directory