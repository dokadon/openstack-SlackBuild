==============
 release-test
==============

Package for testing OpenStack release tools.

This package contains no real useful code and should not need to be
packaged by distributors. It's sole purpose is to test the OpenStack
release automation tools.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/release-test
* Source: http://git.openstack.org/cgit/openstack/release-test
* Bugs: http://bugs.launchpad.net/openstack
