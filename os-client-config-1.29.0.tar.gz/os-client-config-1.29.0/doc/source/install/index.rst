============
Installation
============

At the command line::

    $ pip install os-client-config

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv os-client-config
    $ pip install os-client-config
