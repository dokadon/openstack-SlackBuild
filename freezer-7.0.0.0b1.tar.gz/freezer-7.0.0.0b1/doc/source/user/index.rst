User Guide
==========

.. toctree::
   :maxdepth: 2
   
   installation
   freezer-agent
   freezer-scheduler
   freezer-web-ui
   