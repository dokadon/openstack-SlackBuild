To generate the sample zun.conf file, run gen-config tools
from the top level of the zun directory:

tools/gen-config

Or run the following command from the top level of the
zun directory:

tox -egenconfig

Generated sample configuration file will be put into etc/zun/
directory.
