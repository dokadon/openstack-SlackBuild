====================
Policy configuration
====================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Zun. For a sample
configuration file.

.. show-policy::
   :config-file: ../../etc/zun/zun-policy-generator.conf
