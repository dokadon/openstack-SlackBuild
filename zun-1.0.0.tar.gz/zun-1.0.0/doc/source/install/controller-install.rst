Install and configure controller node
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This section describes how to install and configure the Container service
on the controller node.

.. toctree::

   controller-install-ubuntu.rst
