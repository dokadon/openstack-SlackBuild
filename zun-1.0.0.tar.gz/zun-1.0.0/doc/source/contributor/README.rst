==================================================
Zun Contributor Documentation (source/contributor)
==================================================


This directory is intended to hold any documentation that relates to
how to contribute to Zun or how the project is managed. Some of this
content was previous under 'developer' in openstack-manuals. The content
of the documentation, however, goes beyond just developers to anyone
contributing to the project, thus the change in naming.
