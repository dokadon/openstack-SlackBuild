==========================
 Python Library Reference
==========================

In order to use the python api directly, you must first obtain an auth
token and identify which endpoint you wish to speak to. Once you have
done so, you can use the API like so.


.. toctree::
   :maxdepth: 2

   api/index
   api_v1
