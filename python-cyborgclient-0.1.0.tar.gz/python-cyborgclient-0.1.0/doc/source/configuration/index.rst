=============
Configuration
=============

Configuration of python-cyborgclient.
