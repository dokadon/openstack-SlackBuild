=====
Usage
=====

To use tripleo-common in a project::

    import tripleo_common

