Contributing to os-cloud-config
===================================

.. include:: ../../CONTRIBUTING.rst
