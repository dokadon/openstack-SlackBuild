============
Installation
============

At the command line::

    $ pip install os-cloud-config

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv os-cloud-config
    $ pip install os-cloud-config