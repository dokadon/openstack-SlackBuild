----------
ironic_lib
----------

Overview
--------

A common library to be used by various projects in the Ironic ecosystem.

Running Tests
-------------

To run tests in virtualenvs (preferred)::

  sudo pip install tox
  tox

To run tests in the current environment::

  sudo pip install -r requirements.txt
  nosetests

