===========================
Neutron Release Notes Howto
===========================

Release notes are a new feature for documenting new features in
OpenStack projects. Background on the process, tooling, and
methodology is documented in a `mailing list post by Doug Hellman <http://lists.openstack.org/pipermail/openstack-dev/2015-November/078301.html>`_.

For information on how to create release notes, please consult the
`Release Notes documentation <http://docs.openstack.org/developer/reno/>`_.
