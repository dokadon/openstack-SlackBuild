:tocdepth: 2

##########################
NFV Orchestration API v1.0
##########################

.. rest_expand_all::

.. include:: versions.inc
.. include:: extensions.inc
.. include:: vnfds.inc
.. include:: vnfs.inc
.. include:: vims.inc
.. include:: events.inc
.. include:: vnffgds.inc
.. include:: vnffgs.inc
.. include:: nfps.inc
.. include:: sfcs.inc
.. include:: classifiers.inc
.. include:: nsds.inc
.. include:: nss.inc
