#!/bin/sh
echo "Successfully installed VNFC" > /tacker
