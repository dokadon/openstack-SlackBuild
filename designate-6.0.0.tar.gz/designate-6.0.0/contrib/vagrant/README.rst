See devstack/README.rst or use setup_ubuntu_devstack
