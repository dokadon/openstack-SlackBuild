.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the designate service.

To add additional services, see the `OpenStack install guide
<https://docs.openstack.org/install-guide/>`_.

To learn more about the designate service, read the `Designate developer documentation
<https://docs.openstack.org/designate/latest/contributor/index.html>`_.
