====================
Policy Documentation
====================

The following is an overview of all available policies in Designate. For a
sample configuration file, refer to :doc:`samples/policy-yaml`.

.. show-policy::
   :config-file: ../../etc/designate/designate-policy-generator.conf
