==============
designate.conf
==============

.. literalinclude:: ../../_static/designate.conf.sample
    :language: ini
