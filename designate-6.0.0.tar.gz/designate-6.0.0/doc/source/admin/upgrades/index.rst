========
Upgrades
========

In this section, you will find documentation relevant for upgrading Designate.

Contents:

.. toctree::
   :maxdepth: 2

   kilo
   mitaka
   newton
   ocata
