#!/bin/bash
# Replace 2.0.2-sp2 with your respective plexxicore version
# This can be checked at http://PlexxiCoreURL:8080/PlexxiCore/
pip install -v --index-url http://pypi.plexxi.com plexxi==2.0.2-sp2
