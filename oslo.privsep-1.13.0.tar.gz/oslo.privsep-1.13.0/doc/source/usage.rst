=======
 Usage
=======

To use oslo.privsep in a project::

    import oslo_privsep
