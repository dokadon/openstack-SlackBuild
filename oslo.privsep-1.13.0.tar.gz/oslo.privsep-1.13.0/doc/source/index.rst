==============
 oslo.privsep
==============

OpenStack library for privilege separation

Contents
========

.. toctree::
   :maxdepth: 2

   installation
   api
   usage
   contributing
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

