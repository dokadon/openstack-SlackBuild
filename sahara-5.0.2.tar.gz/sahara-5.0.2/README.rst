OpenStack Data Processing ("Sahara") project
============================================

Sahara at wiki.openstack.org: https://wiki.openstack.org/wiki/Sahara

Launchpad project: https://launchpad.net/sahara

Sahara docs site: http://docs.openstack.org/developer/sahara

Roadmap: https://wiki.openstack.org/wiki/Sahara/Roadmap

Quickstart guide: http://docs.openstack.org/developer/sahara/devref/quickstart.html

How to participate: http://docs.openstack.org/developer/sahara/devref/how_to_participate.html

Source: http://git.openstack.org/cgit/openstack/sahara


License
-------

Apache License Version 2.0 http://www.apache.org/licenses/LICENSE-2.0
