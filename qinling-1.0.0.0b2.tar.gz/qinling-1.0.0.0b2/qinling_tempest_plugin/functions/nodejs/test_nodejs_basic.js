exports.main = function (context, input) {
    return "Hello, NodeJS"
}
