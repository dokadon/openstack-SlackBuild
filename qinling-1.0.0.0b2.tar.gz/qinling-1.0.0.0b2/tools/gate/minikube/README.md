# Minikube installation script for Qinling devstack gate

Those sciprts locate here just for backlog purpose. A known issue is the
application in the pod can not talk to Qinling service, failed with "No route
to host" error.
