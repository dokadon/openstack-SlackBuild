# kubeadm-dind-cluster script for Qinling gate

This script is just for backlog purpose, it is not used for current devstack
gate job. The known problem is Qinling service can not talk to the service
created in k8s.
