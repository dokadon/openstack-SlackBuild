============
Installation
============

At the command line::

    $ pip install os-net-config

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv os-net-config
    $ pip install os-net-config