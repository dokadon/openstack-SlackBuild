========
Usage
========

To use os-net-config in a project::

	import os_net_config