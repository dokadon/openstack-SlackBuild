Undercloud Install via instack
==============================

instack-undercloud is tooling for installing a TripleO undercloud.

It is part of the TripleO project:
http://docs.openstack.org/developer/tripleo-docs/index.html

* Free software: Apache license
* Source: http://git.openstack.org/cgit/openstack/instack-undercloud
* Bugs: http://bugs.launchpad.net/tripleo
