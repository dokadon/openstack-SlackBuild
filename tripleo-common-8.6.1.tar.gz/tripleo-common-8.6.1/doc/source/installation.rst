============
Installation
============

At the command line::

    $ pip install tripleo-common

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv tripleo-common
    $ pip install tripleo-common

