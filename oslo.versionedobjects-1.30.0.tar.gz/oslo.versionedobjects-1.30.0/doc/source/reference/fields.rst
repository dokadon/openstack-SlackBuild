=============
 fields
=============

.. automodule:: oslo_versionedobjects.fields
   :members:
