ceilometer
==========

Release notes can be read online at:
  http://docs.openstack.org/developer/ceilometer/releasenotes/index.html

Documentation for the project can be found at:
  http://docs.openstack.org/developer/ceilometer/

The project home is at:
  http://launchpad.net/ceilometer
