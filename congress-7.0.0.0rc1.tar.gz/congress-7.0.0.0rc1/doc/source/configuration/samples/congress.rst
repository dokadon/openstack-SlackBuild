====================
Sample congress.conf
====================

This sample configuration can also be viewed in `the raw format
<../../_static/congress.conf.sample>`_.

.. literalinclude:: ../../_static/congress.conf.sample
