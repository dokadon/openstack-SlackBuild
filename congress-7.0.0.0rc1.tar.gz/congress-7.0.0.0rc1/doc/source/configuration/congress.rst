=============
congress.conf
=============

.. show-options::
   :config-file: etc/congress-config-generator.conf
