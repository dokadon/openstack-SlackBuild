The :mod:`zaqar.common.configs` module
=======================================

.. automodule:: zaqar.common.configs
  :members:
  :undoc-members:
  :show-inheritance:
