The :mod:`zaqar.transport.auth` module
=======================================

.. automodule:: zaqar.transport.auth
  :members:
  :undoc-members:
  :show-inheritance:
