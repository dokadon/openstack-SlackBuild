The :mod:`zaqar.api.v2.response` module
========================================

.. automodule:: zaqar.api.v2.response
  :members:
  :undoc-members:
  :show-inheritance:
