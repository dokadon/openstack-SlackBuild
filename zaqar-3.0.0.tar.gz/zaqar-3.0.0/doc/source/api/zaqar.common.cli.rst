The :mod:`zaqar.common.cli` module
===================================

.. automodule:: zaqar.common.cli
  :members:
  :undoc-members:
  :show-inheritance:
