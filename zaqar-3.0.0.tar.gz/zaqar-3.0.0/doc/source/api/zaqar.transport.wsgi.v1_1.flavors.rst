The :mod:`zaqar.transport.wsgi.v1_1.flavors` module
====================================================

.. automodule:: zaqar.transport.wsgi.v1_1.flavors
  :members:
  :undoc-members:
  :show-inheritance:
