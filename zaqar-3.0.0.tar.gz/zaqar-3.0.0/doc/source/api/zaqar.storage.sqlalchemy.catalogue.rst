The :mod:`zaqar.storage.sqlalchemy.catalogue` module
=====================================================

.. automodule:: zaqar.storage.sqlalchemy.catalogue
  :members:
  :undoc-members:
  :show-inheritance:
