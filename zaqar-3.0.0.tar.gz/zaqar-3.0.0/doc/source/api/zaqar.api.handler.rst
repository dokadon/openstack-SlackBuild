The :mod:`zaqar.api.handler` module
====================================

.. automodule:: zaqar.api.handler
  :members:
  :undoc-members:
  :show-inheritance:
