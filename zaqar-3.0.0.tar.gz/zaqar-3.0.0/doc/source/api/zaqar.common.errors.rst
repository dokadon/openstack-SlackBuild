The :mod:`zaqar.common.errors` module
======================================

.. automodule:: zaqar.common.errors
  :members:
  :undoc-members:
  :show-inheritance:
