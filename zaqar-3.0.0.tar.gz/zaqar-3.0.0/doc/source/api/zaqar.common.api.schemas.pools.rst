The :mod:`zaqar.common.api.schemas.pools` module
=================================================

.. automodule:: zaqar.common.api.schemas.pools
  :members:
  :undoc-members:
  :show-inheritance:
