The :mod:`zaqar.common.api.schemas.flavors` module
===================================================

.. automodule:: zaqar.common.api.schemas.flavors
  :members:
  :undoc-members:
  :show-inheritance:
