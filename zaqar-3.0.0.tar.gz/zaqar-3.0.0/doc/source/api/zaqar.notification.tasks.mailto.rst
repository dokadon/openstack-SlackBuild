The :mod:`zaqar.notification.tasks.mailto` module
==================================================

.. automodule:: zaqar.notification.tasks.mailto
  :members:
  :undoc-members:
  :show-inheritance: