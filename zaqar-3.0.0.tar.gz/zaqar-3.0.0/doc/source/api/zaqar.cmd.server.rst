The :mod:`zaqar.cmd.server` module
===================================

.. automodule:: zaqar.cmd.server
  :members:
  :undoc-members:
  :show-inheritance:
