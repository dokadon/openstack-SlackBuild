.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the Messaging service.

To add additional services, see the
`additional documentation on installing OpenStack <http://docs.openstack.org/#install-guides>`_ .
