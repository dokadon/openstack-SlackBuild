
Configuration options
=====================

Networking-midonet uses the following configuration options
in the Neutron server configuration, which is typically
`/etc/neutron/neutron.conf`.

.. show-options::

    midonet_v2
