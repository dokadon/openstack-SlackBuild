Tests
-----

You can run the unit tests with the following command::

    $ tox -e py27

It installs its requirements to ``.tox/py27`` on the initial run.
