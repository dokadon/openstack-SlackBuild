==================================
Welcome to Ironic Inspector Client
==================================

.. include:: ../../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   cli/index
   reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
