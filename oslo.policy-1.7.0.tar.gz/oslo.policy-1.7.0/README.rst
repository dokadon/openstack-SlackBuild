=============
 oslo.policy
=============

.. image:: https://img.shields.io/pypi/v/oslo.policy.svg
    :target: https://pypi.python.org/pypi/oslo.policy/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/oslo.policy.svg
    :target: https://pypi.python.org/pypi/oslo.policy/
    :alt: Downloads

The Oslo Policy library provides support for RBAC policy enforcement across
all OpenStack services.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.policy
* Source: http://git.openstack.org/cgit/openstack/oslo.policy
* Bugs: http://bugs.launchpad.net/oslo.policy

