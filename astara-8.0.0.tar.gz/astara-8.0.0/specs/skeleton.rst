..
 This work is licensed under a Creative Commons Attribution 3.0 Unported
 License.

 http://creativecommons.org/licenses/by/3.0/legalcode


Title of your blueprint
=======================


Problem Description
===================


Proposed Change
===============


Data Model Impact
-----------------


REST API Impact
---------------


Security Impact
---------------


Notifications Impact
--------------------


Other End User Impact
---------------------


Performance Impact
------------------


Other Deployer Impact
---------------------


Developer Impact
----------------


Community Impact
----------------


Alternatives
------------


Implementation
==============

Assignee(s)
-----------


Work Items
----------


Dependencies
============


Testing
=======

Tempest Tests
-------------


Functional Tests
----------------


API Tests
---------


Documentation Impact
====================

User Documentation
------------------


Developer Documentation
-----------------------


References
==========

