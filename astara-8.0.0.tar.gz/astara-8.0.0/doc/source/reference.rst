Configuration Options
=====================

``astara-orchestrator`` uses ``oslo.config`` for configuration, so it's
configuration file format should be very familiar to OpenStack deployers
