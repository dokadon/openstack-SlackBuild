Contributing
============

Submitting Code Upstream
------------------------

All of Astara's code is 100% open-source and is hosted on `git.openstack.org
<https://git.openstack.org/cgit/openstack/astara/>`_  Patches are welcome!
