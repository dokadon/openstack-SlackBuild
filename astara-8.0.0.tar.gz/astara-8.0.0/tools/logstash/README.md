These files are used for logstash to read the astara-orchestrator log and send
metrics to a graphite server.  Logstash has many output options, so these files
serve as a template for parsing the astara-orchestrator log file.
