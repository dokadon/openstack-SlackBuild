==================
Additional options
==================

These options can also be set in the ``manila.conf`` file.

.. include:: ../tables/manila-ca.inc
.. include:: ../tables/manila-common.inc
.. include:: ../tables/manila-compute.inc
.. include:: ../tables/manila-ganesha.inc
.. include:: ../tables/manila-hnas.inc
.. include:: ../tables/manila-quota.inc
.. include:: ../tables/manila-redis.inc
.. include:: ../tables/manila-san.inc
.. include:: ../tables/manila-scheduler.inc
.. include:: ../tables/manila-share.inc
.. include:: ../tables/manila-tegile.inc
.. include:: ../tables/manila-winrm.inc
