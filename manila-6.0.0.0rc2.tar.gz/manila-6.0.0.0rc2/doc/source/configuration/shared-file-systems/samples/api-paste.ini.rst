=============
api-paste.ini
=============

The shared file systems service stores its API configuration settings in the
``api-paste.ini`` file.

.. literalinclude:: ../../../../../etc/manila/api-paste.ini
   :language: ini
