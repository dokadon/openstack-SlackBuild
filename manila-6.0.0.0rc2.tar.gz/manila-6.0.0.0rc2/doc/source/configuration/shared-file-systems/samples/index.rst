======================================================
Shared File Systems service sample configuration files
======================================================

All the files in this section can be found in ``/etc/manila``.

.. toctree::
   :maxdepth: 1

   manila.conf.rst
   api-paste.ini.rst
   rootwrap.conf.rst
   policy.rst
   sample_policy.rst
