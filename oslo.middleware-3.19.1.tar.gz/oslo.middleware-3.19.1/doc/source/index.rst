.. include:: ../../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   installation
   api
   healthcheck_plugins
   cors
   oslo_config
   contributing

Release Notes
=============

.. toctree::
   :maxdepth: 1

   history
