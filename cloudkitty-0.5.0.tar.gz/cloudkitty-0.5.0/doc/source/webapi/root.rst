==========================
CloudKitty REST API (root)
==========================

.. rest-controller:: cloudkitty.api.root:RootController
   :webprefix: / /
.. Dirty hack till the bug is fixed so we can specify root path

.. autotype:: cloudkitty.api.root.APILink
   :members:

.. autotype:: cloudkitty.api.root.APIMediaType
   :members:

.. autotype:: cloudkitty.api.root.APIVersion
   :members:
