==========================================
Welcome to Freezer's client documentation!
==========================================

Contents
--------

.. toctree::
   :maxdepth: 2

   cli/index


Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`


