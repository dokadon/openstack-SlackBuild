========
Usage
========

To use kuryr-kubernetes in a project::

    import kuryr_kubernetes
