# Importing non-modules that are not used explicitly

from .update import UpdateApplicationClass  # noqa
