Will overwrite the pipeline.yaml taken from the Ceilometer repository
defined in ceilometer element install.d.
