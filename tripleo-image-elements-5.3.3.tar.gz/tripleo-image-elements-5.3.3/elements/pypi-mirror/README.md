Creates and hosts a local pypi mirror suitable for use with the pypi
element from diskimage-builder.
