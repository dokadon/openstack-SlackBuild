Pip install OpenStack python- client tools.

The element will install OpenStack python-*clients.
This element is intended to to allow other elements who require client tools
access to installing them in a uniform way.

Installed clients are:
    python-glanceclient
    python-heatclient
    python-keystone
    python-neutronclient
    python-novaclient
