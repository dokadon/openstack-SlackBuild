Installs MariaDB with galera

Mysql and mariadb elements are very similar so both depend on mysql-common
element which contains shared logic. See mysql-common for more details about
mysql setup.
