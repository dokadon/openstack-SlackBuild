Creates an image prepped to make a devstack baremetal cloud. See
incubator/scripts/demo within the built image.

Forces a 16GB image to allow room for Swift, Cinder and instance
disk images.
