Install and configure Ceilometer.

Configuration
-------------

    ceilometer:
      metering_secret: "unset"
        - secret value for signing metering messages
      service-password: "unset"
        - password for the metering service in Keystone
