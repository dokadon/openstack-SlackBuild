Provides compatibility with the mysql element for distributions that have
switched to mariadb and don't provide the necessary aliases.