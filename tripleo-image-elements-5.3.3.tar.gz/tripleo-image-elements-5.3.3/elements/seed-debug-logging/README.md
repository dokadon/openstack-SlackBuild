Enable debug logging on the seed

Adding this element will turn on debug for the openstack services.
