Install openvswitch from packages.

Enables the openvswitch service for systemd systems and
and adds an upstart script service to override the default
sysv one on systems with upstart.
