Installs MariaDB with galera from default repository

This element is similar to mariadb repository but installs packages
from default distribution repositories.
