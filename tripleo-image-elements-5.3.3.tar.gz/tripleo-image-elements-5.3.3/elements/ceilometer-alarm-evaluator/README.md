Enable the Ceilometer Alarm Evaluator service
