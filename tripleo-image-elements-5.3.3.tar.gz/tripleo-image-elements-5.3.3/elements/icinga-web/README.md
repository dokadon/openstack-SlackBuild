Install Icinga's web interface from the distribution repository.

