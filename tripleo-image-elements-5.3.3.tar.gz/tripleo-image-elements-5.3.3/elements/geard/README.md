Element to install gear and run geard

geard is a python implementation of the gearman protocol server
https://pypi.python.org/pypi/gear
