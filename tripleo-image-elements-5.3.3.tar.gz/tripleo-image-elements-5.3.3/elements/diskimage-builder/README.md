Install diskimage-builder from git.

diskimage-builder has the core functionality for building disk images, file
system images and ramdisk images for use with OpenStack (both virtual and bare
metal).
