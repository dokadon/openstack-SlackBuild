Install nova API and control services. See /var/log/upstart/nova-\*
for logs.
