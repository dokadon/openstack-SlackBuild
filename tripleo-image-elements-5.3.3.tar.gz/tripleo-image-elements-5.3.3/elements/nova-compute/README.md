Install nova compute and baremetal components.
