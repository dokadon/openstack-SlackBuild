Adds salt-minion, a config-management tool, to the image.
