Enable Ironic API service.
