Install heat software on the machine.

Configuration
-------------

    heat:
      verbose: False
        # Print more verbose output (set logging level to INFO instead
        # of default WARNING level).
      debug: False
        # Print debugging output (set logging level to DEBUG instead of
        # default WARNING level).


Configuration of heat services is done in the heat-api and heat-engine
elements, which enable those services.
