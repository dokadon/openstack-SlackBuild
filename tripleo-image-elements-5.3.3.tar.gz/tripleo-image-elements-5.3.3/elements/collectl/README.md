Installs the collectl package for gathering performance data when needed.

The default configuration file /etc/collectl.conf has been changed to examine
cpu, disk, memory, network and process stats only and record eth and bond
stats for the networks. Both raw and plottable files will be produced.
