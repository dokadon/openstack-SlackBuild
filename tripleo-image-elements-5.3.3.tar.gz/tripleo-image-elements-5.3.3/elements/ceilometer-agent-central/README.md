Enable the Ceilometer Agent Central service
