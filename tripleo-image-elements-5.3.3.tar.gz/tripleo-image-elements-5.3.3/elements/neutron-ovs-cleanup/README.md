Install and configure OpenStack Networking cleanup utility.

Currently supports systemd distributions only.
