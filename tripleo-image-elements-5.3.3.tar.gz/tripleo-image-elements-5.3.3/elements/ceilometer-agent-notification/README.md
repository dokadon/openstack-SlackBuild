Enable the Ceilometer Agent Notification service
