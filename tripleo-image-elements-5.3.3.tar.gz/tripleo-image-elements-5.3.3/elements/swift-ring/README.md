Element that provides a node with the tools to build a swift ring
