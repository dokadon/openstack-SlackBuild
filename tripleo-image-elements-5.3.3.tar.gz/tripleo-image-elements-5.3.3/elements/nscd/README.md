Add nscd to built images
========================

This element adds nscd to the image. The nscd daemon caches name service
lookups (including NIS+ and DNS).
