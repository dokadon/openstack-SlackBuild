Adds the tripleo demo staging repository.

This is used when testing builds of new plumbing (such as qemu-kvm). Most folk
should not need it.
