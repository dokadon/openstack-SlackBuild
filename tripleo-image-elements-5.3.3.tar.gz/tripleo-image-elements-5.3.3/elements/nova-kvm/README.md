Nova Compute KVM
----------------

Software install and configuration hooks for Nova with KVM.
