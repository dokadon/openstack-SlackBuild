Element to install and configure squid.

The Squid accepts connections on all local (internal) networks.

Remote requests for local destinations (127.0.0.1) are denied.
