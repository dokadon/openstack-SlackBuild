Install Ansible.

Configuration
-------------

At Present there is no configuration for this element.

Ansible Version
---------------

By default this installs ansible 1.8.1, but the environment variable
ANSIBLE_VERSION can be set to override the installed version of Ansible.
