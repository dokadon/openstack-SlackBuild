=============
fedora-mirror
=============

This element sets up the mirror for updating the Fedora cloud image.
Using a mirror improves the speed of the image building.

Environment Variables
---------------------

FEDORA_MIRROR
  :Required: Yes
  :Description: URL to the Fedora mirror.
