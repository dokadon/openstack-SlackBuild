===========================
puppet-ec2api Release Notes
===========================

.. toctree::
   :maxdepth: 1

   unreleased
   pike
   ocata
