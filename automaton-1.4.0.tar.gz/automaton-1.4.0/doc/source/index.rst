Welcome to automaton's documentation!
========================================================

Friendly state machines for python.

.. toctree::
   :maxdepth: 2

   features
   api
   installation
   examples
   contributing

History
=======

.. toctree::
   :maxdepth: 2

   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

