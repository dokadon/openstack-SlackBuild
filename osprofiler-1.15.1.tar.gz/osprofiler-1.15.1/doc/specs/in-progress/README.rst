OSprofiler In-Progress Specs
============================

Specs are detailed description of proposed changes in project. Usually they
answer on what, why, how to change in project and who is going to work on
change.

This directory contains files with accepted by not implemented specs,
1 file is 1 spec.
