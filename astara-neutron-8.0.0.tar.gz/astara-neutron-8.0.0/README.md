# Astara Neutron

*Part of the [Astara Project](https://github.com/openstack/astara).*

Addon API extensions for OpenStack Neutron which enable functionality and integration
with the Astara project, notably Astara router appliance interaction, and
services for the Astara RUG orchestration service.
