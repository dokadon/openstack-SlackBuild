.. monasca-log-api documentation master file, created by
   sphinx-quickstart on Wed Nov 18 12:02:03 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to monasca-log-api's documentation!
===========================================

Contents:

.. toctree::
   :maxdepth: 2

   monasca_log_api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

