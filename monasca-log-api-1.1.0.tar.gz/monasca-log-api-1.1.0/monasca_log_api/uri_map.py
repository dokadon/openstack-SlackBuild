V2_LOGS_URI = '/v2.0/log/single'
V3_LOGS_URI = '/v3.0/logs'
HEALTHCHECK_URI = '/healthcheck'
