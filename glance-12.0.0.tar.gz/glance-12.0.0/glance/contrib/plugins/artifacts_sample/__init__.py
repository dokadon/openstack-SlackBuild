from glance.contrib.plugins.artifacts_sample.v1 import artifact as art1
from glance.contrib.plugins.artifacts_sample.v2 import artifact as art2


MY_ARTIFACT = [art1.MyArtifact, art2.MyArtifact]
