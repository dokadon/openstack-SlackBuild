  **-os-auth-token=OS_AUTH_TOKEN**
        Defaults to env[OS_AUTH_TOKEN]

  **--os-username=OS_USERNAME**
        Defaults to env[OS_USERNAME]

  **--os-password=OS_PASSWORD**
        Defaults to env[OS_PASSWORD]

  **--os-region-name=OS_REGION_NAME**
        Defaults to env[OS_REGION_NAME]

  **--os-tenant-id=OS_TENANT_ID**
        Defaults to env[OS_TENANT_ID]

  **--os-tenant-name=OS_TENANT_NAME**
        Defaults to env[OS_TENANT_NAME]

  **--os-auth-url=OS_AUTH_URL**
        Defaults to env[OS_AUTH_URL]


