.. _glance-registry.conf:

--------------------
glance-registry.conf
--------------------

This configuration file controls how the register server operates. More
information can be found in :ref:`configuring-the-glance-registry`.

.. show-options::
   :config-file: etc/oslo-config-generator/glance-registry.conf
