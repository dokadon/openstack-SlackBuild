===================
Sample ml2_conf.ini
===================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/ml2_conf.conf.sample>`_.

.. literalinclude::
   ../../_static/config_samples/ml2_conf.conf.sample
