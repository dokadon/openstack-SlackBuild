===================================
 Ocata Series Release Notes
===================================

.. release-notes::
   :branch: origin/stable/ocata
   :earliest-version: 2.0.0
