===========
root-passwd
===========

Assign a password to root.

This is useful when booting outside of a cloud environment (e.g. manually via
kvm).

Environment Variables
---------------------

DIB_PASSWORD
  :Required: Yes
  :Description: The password for the root user.
