.. _user-guide:

User Guide
~~~~~~~~~~

.. toctree::
   :maxdepth: 2

   userguide/manage_environments
   userguide/manage_applications
   userguide/log_in_to_murano_instance
   userguide/use_cli
   userguide/deploying_using_cli
   ../reference/appendix/articles/multi_region
