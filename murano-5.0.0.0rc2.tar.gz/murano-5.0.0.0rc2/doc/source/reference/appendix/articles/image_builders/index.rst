.. _building_images:

=====================
Building Murano Image
=====================

.. toctree::
   :maxdepth: 2

   windows
   linux
   upload
