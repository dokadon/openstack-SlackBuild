.. _murano-concepts:

=========================================
High-level definitions of Murano concepts
=========================================
