.. _rest-api-spec:

======================
REST API specification
======================
