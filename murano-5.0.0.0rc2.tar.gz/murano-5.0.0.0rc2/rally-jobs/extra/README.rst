Extra files
===========

All files from this directory will be copy-pasted to gates, which makes it
possible to use absolute paths in rally tasks. Files will be in ~/.rally/extra/*
