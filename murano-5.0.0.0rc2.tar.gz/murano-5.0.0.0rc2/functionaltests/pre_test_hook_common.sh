#!/bin/bash

DEVSTACK_BASE=/opt/stack/new/devstack
