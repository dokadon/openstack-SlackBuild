Nodecellar Example Application
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Nodecellar is a example application with a Node front end and Mongo
database backend.

To test this application with the Murano Cloudify plugin it:

`git clone https://github.com/cloudify-cosmo/cloudify-nodecellar-example.git Resources`
`cd Resources`
`git checkout tags/3.2.1`

After that the package need to be ziped and uploaded to Murano catalog as
normally done for Murano applications.

You can follow instructions from `here <http://getcloudify.org/guide/3.2/quickstart.html>`_
to quickly bring up the environment for the application.
