=====
MOVED
=====

The murano tempest plugin has moved to http://git.openstack.org/cgit/openstack/murano-tempest-plugin
