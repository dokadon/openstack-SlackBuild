============
Installation
============

At the command line::

    $ pip install python-masakariclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-masakariclient
    $ pip install python-masakariclient
