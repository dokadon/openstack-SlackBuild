========
Usage
========

To use python-masakariclient in a project::

    import masakariclient
