===============================
python-masakariclient
===============================

masakariclient module and a CLI tool for masakari

Please fill here a long description which must be at least 3 lines wrapped on
80 cols, so that distribution package maintainers can use it in their packages.
Note that this is a hard requirement.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/python-masakariclient
* Source: http://git.openstack.org/cgit/openstack/python-masakariclient
* Bugs: http://bugs.launchpad.net/python-masakariclient

Features
--------

* TODO
