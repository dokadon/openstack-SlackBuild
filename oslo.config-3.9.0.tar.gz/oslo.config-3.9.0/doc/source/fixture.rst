------------
Test Fixture
------------

.. currentmodule:: oslo_config.fixture

.. autoclass:: Config
   :members:
