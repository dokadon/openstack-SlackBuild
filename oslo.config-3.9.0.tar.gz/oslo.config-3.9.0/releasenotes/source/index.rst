===========================
 oslo.config Release Notes
===========================

 .. toctree::
    :maxdepth: 1

    unreleased
    liberty
