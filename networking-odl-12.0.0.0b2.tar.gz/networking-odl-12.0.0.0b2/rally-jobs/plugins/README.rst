Rally plugins
=============

All \*.py modules from this directory will be auto-loaded by Rally and all
plugins will be discoverable. There is no need of any extra configuration
and there is no difference between writing them here and in rally code base.

Note that it is better to push all interesting and useful benchmarks to Rally
code base, this simplifies administration for Operators.
