========
oslotest
========

.. _oslotest_3.4.0:

3.4.0
=====

.. _oslotest_3.4.0_New Features:

New Features
------------

.. releasenotes/notes/controlling-output-capture-e47c66bbca4a694a.yaml @ b'039b03aa7575efc7e62f59b1410e85b3a7d7b4d3'

- Change the API for the CaptureOutput fixture so that tests may
  enable it explicitly instead of purely relying on the environment
  variables to control it.

