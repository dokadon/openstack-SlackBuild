============
Design Notes
============

.. toctree::
   :maxdepth: 1

   data_model
   native_dhcp
   ovn_worker
   metadata_api
   database_consistency
