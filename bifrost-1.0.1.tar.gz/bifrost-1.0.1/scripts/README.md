Scripts
=======

This directory contains several scripts used in the OpenStack CI environment
for CI testing of Bifrost, or CI testing that uses Bifrost to test other projects.

These are generally not intended for use outside of the OpenStack CI environment (or similar).
However env-setup.sh script is often used to install initial dependencies.