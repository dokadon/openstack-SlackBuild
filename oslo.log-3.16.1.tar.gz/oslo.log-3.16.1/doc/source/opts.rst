=======================
 Configuration Options
=======================

oslo.log uses oslo.config to define and manage configuration options
to allow the deployer to control how an application's logs are
handled.

.. show-options:: oslo.log
