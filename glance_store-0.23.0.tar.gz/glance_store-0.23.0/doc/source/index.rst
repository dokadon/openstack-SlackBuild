==============
 glance_store
==============

The glance_store library supports the creation, deletion and gather of data
assets from/to a set of several, different, storage technologies.

.. toctree::
   :maxdepth: 1

   user/index
   reference/index

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

