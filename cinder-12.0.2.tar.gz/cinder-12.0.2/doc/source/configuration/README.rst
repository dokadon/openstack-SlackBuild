=========================================================
Cinder Configuration Documentation (source/configuration)
=========================================================

Introduction:
-------------

This directory is intended to hold any documentation that relates to
how to configure Cinder.  It is intended that some of this content
be automatically generated in the future.  At the moment, however, it
is not.  Changes to configuration options for Cinder or its drivers
needs to be put under this directory.

The full spec for organization of documentation may be seen in the
`OS Manuals Migration Spec
<https://specs.openstack.org/openstack/docs-specs/specs/pike/os-manuals-migration.html>`.

