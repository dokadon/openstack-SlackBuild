=============
api-paste.ini
=============

Use the ``api-paste.ini`` file to configure the Block Storage API
service.

.. literalinclude:: api-paste.ini.inc
