=============
rootwrap.conf
=============

The ``rootwrap.conf`` file defines configuration values used by the
``rootwrap`` script when the Block Storage service must escalate its
privileges to those of the root user.

.. literalinclude:: rootwrap.conf.inc
