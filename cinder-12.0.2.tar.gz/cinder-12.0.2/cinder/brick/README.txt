Brick has been migrated to a new standalone
pypi library called os-brick.

We are leaving the local_dev directory here for the time
being until we can migrate it to a new home.
