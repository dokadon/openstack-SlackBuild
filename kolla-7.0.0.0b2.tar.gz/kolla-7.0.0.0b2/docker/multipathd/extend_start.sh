#!/bin/bash
modprobe dm-multipath
