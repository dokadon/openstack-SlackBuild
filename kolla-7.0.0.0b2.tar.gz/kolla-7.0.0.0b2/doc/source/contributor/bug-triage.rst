==========
Bug triage
==========

The triage of Kolla bugs follows the OpenStack-wide process documented
on `BugTriage <https://wiki.openstack.org/wiki/BugTriage>`_ in the wiki.
Please reference `Bugs <https://docs.openstack.org/project-team-guide/bugs.html>`_
for further details.
