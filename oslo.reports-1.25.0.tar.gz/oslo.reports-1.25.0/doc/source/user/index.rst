===================
 Using oslo.reports
===================

.. toctree::
   :maxdepth: 2

   usage
   history
