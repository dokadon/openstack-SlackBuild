============
Installation
============

At the command line::

    $ pip install oslo.reports
