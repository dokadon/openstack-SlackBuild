DASHBOARD = 'nfv'
DISABLED = False
ADD_INSTALLED_APPS = [
    'tacker_horizon.openstack_dashboard.dashboards.nfv',
]
