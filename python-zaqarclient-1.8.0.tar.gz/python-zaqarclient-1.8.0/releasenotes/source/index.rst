.. Zaqar-Client documentation master file, created by
   sphinx-quickstart on Tue Dec 20 11:53:00 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Zaqar-Client's documentation!
========================================

Contents
--------

.. toctree::
   :maxdepth: 1

   unreleased
   pike
   ocata

OpenStack Releases
------------------

The ZaqarClient release that was current when the corresponding
OpenStack release was made is shown below:

=================   ===================
OpenStack Release   ZaqarClient Release
=================   ===================
Ocata               1.4.0
Newton              1.2.0
=================   ===================

Further details for historical OpenStack releases are found at the
`OpenStack Releases`_ page.

.. _`OpenStack Releases`: http://releases.openstack.org/

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

