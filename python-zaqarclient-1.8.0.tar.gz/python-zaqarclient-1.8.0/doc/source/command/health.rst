Health
======

For help on a specific :command:`openstack messaging health` command, enter:

.. code-block:: console

   $ openstack messaging health COMMAND -h/--help

The one command:

.. code-block:: console

      messaging health

.. _openstack_messaging_health:

openstack messaging health
--------------------------

.. code-block:: console

   usage: openstack messaging health [-h]

Display detailed health status of Zaqar server.
