#!/bin/bash
# This script starts the nodejs application
start nodeapp
