#!/bin/bash

pip install -q -U -e "git+https://git.openstack.org/openstack/tosca-parser.git#egg=tosca_parser"
