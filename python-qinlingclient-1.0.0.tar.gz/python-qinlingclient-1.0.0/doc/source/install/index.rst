============
Installation
============

This is an OpenStack Client plugin for the FaaS (Qinling) project.

Install the plugin::

    $ pip install python-qinlingclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-qinlingclient
    $ pip install python-qinlingclient

.. note:: If python-openstackclient is not already installed it will be
          installed as part of the requirements for the Qinling client plugin.
