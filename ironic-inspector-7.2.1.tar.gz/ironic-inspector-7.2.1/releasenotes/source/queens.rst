============================================
 Queens Series (6.1.0 - 7.1.x) Release Notes
============================================

.. release-notes::
   :branch: stable/queens
