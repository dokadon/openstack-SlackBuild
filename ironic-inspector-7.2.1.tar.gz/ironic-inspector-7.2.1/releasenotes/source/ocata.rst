==========================================
Ocata Series (5.0.0 - 5.0.x) Release Notes
==========================================

.. release-notes::
   :branch: origin/stable/ocata
