===========
Searchlight
===========

The Searchlight project provides indexing and search capabilities across
OpenStack resources. Its goal is to achieve high performance and flexible
querying combined with near real-time indexing.

Use the following resources to learn more:

* `Official Searchlight documentation <http://docs.openstack.org/developer/searchlight/>`_
