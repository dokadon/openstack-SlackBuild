============================
Magnum Configuration Options
============================

The following is a sample Magnum configuration for adaptation and use. It is
auto-generated from Magnum when this documentation is built, so
if you are having issues with an option, please compare your version of
Magnum with the version of this documentation.

The sample configuration can also be viewed in :download:`file form
</_static/magnum.conf.sample>`.

.. literalinclude:: /_static/magnum.conf.sample
