==========================
Sample configuration files
==========================

Configuration files can alter how Magnum behaves at runtime and by default
are located in ``/etc/magnum/``. Links to sample configuration files can be
found below:

.. toctree::

   policy-yaml.rst
