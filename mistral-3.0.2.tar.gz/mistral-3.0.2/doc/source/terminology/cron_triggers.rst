Cron-triggers
=============

Cron trigger is an object allowing to run workflow on a schedule. User specifies what workflow with what input needs to be run and also specifies how often it should be run.

.. image:: /img/Mistral_cron_trigger.png
    :align: center

Cron-pattern is used to describe the frequency of execution in Mistral.
To see more about cron-patterns, refer to `Cron expression <https://en.wikipedia.org/wiki/Cron#CRON_expression>`_
