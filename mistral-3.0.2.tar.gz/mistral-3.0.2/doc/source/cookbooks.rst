Mistral Cookbooks
=================

- `Mistral for Administration (aka Cloud Cron) <http://wiki.openstack.org/wiki/Mistral/Cookbooks/AdministrationCloudCron>`_
