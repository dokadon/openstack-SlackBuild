
Welcome to Senlin Dashboard's documentation!
============================================

User Documentation
------------------

.. toctree::
   :maxdepth: 2

   install/index
   configuration/index
   Release Notes <https://docs.openstack.org/releasenotes/senlin-dashboard>

Contributor Guide
-----------------

.. toctree::
   :glob:
   :maxdepth: 2

   contributor/index
