Install all packages required for opstools (logging and monitoring)
