Installs the the Puppet package.

Configuration
-------------
None.
