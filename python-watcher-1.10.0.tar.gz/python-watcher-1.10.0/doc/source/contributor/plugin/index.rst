.. toctree::
   :maxdepth: 1

   base-setup
   action-plugin
   cdmc-plugin
   goal-plugin
   planner-plugin
   scoring-engine-plugin
   strategy-plugin
   plugins
