===================
Configuration Guide
===================

.. toctree::
   :maxdepth: 2

   configuring
   watcher
