See :ref:`pxe-boot`.
