#comment
maintainer       "Telefonica I+D"
maintainer_email "henar@tid.es"
name             "test"
license          "All rights reserved"
description      "Default cookbook for testing"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.rdoc'))
version          "0.1.0"