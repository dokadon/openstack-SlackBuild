========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/python-tackerclient.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

This is the client API library for Tacker.
