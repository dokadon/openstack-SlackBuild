 Style Commandments
===============================================

Read the OpenStack Style Commandments in the following link

http://docs.openstack.org/developer/hacking/

