==========
Bug triage
==========

The triage of Kolla bugs follows the OpenStack-wide process documented
on `BugTriage <https://wiki.openstack.org/wiki/BugTriage>`_ in the wiki.
Please reference `Bugs <https://wiki.openstack.org/wiki/Bugs>`_ in the
wiki for further details.
