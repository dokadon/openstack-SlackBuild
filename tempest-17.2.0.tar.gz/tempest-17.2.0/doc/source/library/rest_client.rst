.. _rest_client:

Rest Client Usage
=================

----------------------
The rest_client module
----------------------

.. automodule:: tempest.lib.common.rest_client
   :members:
