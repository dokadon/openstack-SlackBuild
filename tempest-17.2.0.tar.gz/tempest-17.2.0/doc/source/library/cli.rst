.. _cli:

CLI Testing Framework Usage
===========================

-------------------
The cli.base module
-------------------

.. automodule:: tempest.lib.cli.base
   :members:

----------------------------
The cli.output_parser module
----------------------------

.. automodule:: tempest.lib.cli.output_parser
   :members:
