.. _tempest-sampleconf:

Sample Configuration File
==========================

The following is a sample Tempest configuration for adaptation and use. It is
auto-generated from Tempest when this documentation is built, so
if you are having issues with an option, please compare your version of
Tempest with the version of this documentation.

The sample configuration can also be viewed in `file form <_static/tempest.conf.sample>`_.

.. literalinclude:: _static/tempest.conf.sample
