Team and repository tags
========================

.. image:: http://governance.openstack.org/badges/neutron-dynamic-routing.svg
    :target: http://governance.openstack.org/reference/tags/index.html

.. Change things from this point on

This package contains neutron-dynamic-routing code which depends upon neutron
and it's related libraries to run.

Project Resources
=================

The homepage for Neutron is: https://launchpad.net/neutron.  Use this
site for asking for help, and filing bugs. We use a single launchpad
page for all Neutron projects.

Code is available on git.openstack.org at:
https://git.openstack.org/cgit/openstack/neutron-dynamic-routing

Refer to Neutron documentation for more information:
`Neutron README.rst <https://git.openstack.org/cgit/openstack/neutron/tree/README.rst>`_
