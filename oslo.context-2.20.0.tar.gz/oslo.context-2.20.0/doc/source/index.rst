.. include:: ../../README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   install/index
   user/index
   contributor/index

Code Documentation
==================

.. toctree::
   :maxdepth: 1

   reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
