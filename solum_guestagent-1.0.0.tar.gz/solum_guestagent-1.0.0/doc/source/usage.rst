========
Usage
========

To use solum_guestagent in a project::

	import solum_guestagent