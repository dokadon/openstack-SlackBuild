============
Installation
============

At the command line::

    $ pip install solum_guestagent

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv solum_guestagent
    $ pip install solum_guestagent