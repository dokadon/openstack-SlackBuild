===============================
solum-infra-guestagent
===============================

Guest Agent for Solum

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/solum-infra-guestagent
* Source: http://git.openstack.org/cgit/stackforge/solum-infra-guestagent
* Bugs: http://bugs.launchpad.net/solum-infra-guestagent

Features
--------

* TODO