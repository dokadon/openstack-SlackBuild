===============================================
 oslo.db -- OpenStack Database Pattern Library
===============================================

.. image:: https://img.shields.io/pypi/v/oslo.db.svg
    :target: https://pypi.python.org/pypi/oslo.db/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/oslo.db.svg
    :target: https://pypi.python.org/pypi/oslo.db/
    :alt: Downloads

The oslo db (database) handling library, provides database
connectivity to different database backends and various other helper
utils.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslo.db
* Source: http://git.openstack.org/cgit/openstack/oslo.db
* Bugs: http://bugs.launchpad.net/oslo.db
