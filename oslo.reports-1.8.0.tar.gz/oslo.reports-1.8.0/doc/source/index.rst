==============
 oslo.reports
==============

oslo.reports library

Contents
========

.. toctree::
   :maxdepth: 2

   installation
   usage
   opts
   contributing

API
===

.. toctree::
   :maxdepth: 2

   api/autoindex

Release Notes
=============

.. toctree::
   :maxdepth: 1

   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

