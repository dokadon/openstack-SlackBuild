=======================
glance-cache-prefetcher
=======================

------------------------------
Glance Image Cache Pre-fetcher
------------------------------

.. include:: header.txt

SYNOPSIS
========

  glance-cache-prefetcher [options]

DESCRIPTION
===========

This is meant to be run from the command line after queueing
images to be pretched.

OPTIONS
=======

  **General options**

  .. include:: general_options.txt

FILES
=====

    **/etc/glance/glance-cache.conf**
        Default configuration file for the Glance Cache

.. include:: footer.txt
