----------
Exceptions
----------

.. inheritance-diagram::
    taskflow.exceptions
    :parts: 1

.. automodule:: taskflow.exceptions
