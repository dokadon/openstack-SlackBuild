.. include:: current-series.rst
