======================
 Bifrost Release Notes
======================

.. toctree::
   :maxdepth: 1

   Current Series <current-series>
   Newton (unreleased) <newton>
   Mitaka (0.0.1 - 1.0.x) <mitaka>

.. toctree::
   :hidden:

   unreleased
