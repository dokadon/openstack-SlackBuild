.. include:: osc/v2/load-balancer.rst
