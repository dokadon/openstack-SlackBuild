:mod:`initiator` -- Initiator
=============================

.. automodule:: os_brick.initiator
   :synopsis: Initiator module


Sub-modules:

.. toctree::
   :maxdepth: 2

   connector
