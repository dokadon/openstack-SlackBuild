============
Installation
============

At the command line::

    $ pip install python-solumclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-solumclient
    $ pip install python-solumclient