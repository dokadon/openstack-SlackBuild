Python bindings to the Solum API
================================

This is a client library for Solum built on the Solum API.

* Free software: Apache license
* Documentation: http://wiki.openstack.org/wiki/Solum
