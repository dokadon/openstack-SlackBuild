============
Installation
============

At the command line::

    $ pip install ironic-ui

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv ironic-ui
    $ pip install ironic-ui
