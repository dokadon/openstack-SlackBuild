===============
bgp_dragent.ini
===============

.. show-options::
   :config-file: etc/oslo-config-generator/bgp_dragent.ini
