======================
Sample bgp_dragent.ini
======================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/bgp_dragent.conf.sample>`_.

.. literalinclude:: ../../_static/config_samples/bgp_dragent.conf.sample
