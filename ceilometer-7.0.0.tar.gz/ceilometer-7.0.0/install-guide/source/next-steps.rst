.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the ceilometer service.

To add additional services, see
docs.openstack.org/draft/install-guides/index.html .
