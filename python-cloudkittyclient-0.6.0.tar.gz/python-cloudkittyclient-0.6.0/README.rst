Python bindings to the CloudKitty API
=====================================

:version: 0.2
:Wiki: `CloudKitty Wiki`_
:IRC: #cloudkitty @ freenode


.. _CloudKitty Wiki: https://wiki.openstack.org/wiki/CloudKitty


python-cloudkittyclient
=======================

This is a client library for CloudKitty built on the CloudKitty API. It
provides a Python API (the ``cloudkittyclient`` module).


Status
======

This project is **highly** work in progress.

