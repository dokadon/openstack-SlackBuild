==========
glance-api
==========

---------------------------------------
Server for the Glance Image Service API
---------------------------------------

.. include:: header.txt

SYNOPSIS
========

glance-api [options]

DESCRIPTION
===========

glance-api is a server daemon that serves the Glance API

OPTIONS
=======

  **General options**

  .. include:: general_options.txt

FILES
=====

  **/etc/glance/glance-api.conf**
        Default configuration file for Glance API

.. include:: footer.txt
