===============================================
Tempest Integration of Freezer API
===============================================

This directory contains Tempest tests to cover the freezer-api project.

