========
Usage
========

To use vitrage-dashboard in a project::

    import vitragedashboard
