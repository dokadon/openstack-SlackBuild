===============================
Sample opencontrail-driver.conf
===============================

This sample configuration can also be viewed in `the raw format
<../../_static/config-samples/opencontrail-driver.conf.sample>`_.

.. literalinclude::
   ../../_static/config-samples/opencontrail-driver.conf.sample
