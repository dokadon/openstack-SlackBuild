..
 This work is licensed under a Creative Commons Attribution 3.0 Unported
 License.

 http://creativecommons.org/licenses/by/3.0/legalcode

===
API
===

This API is documented in the `Neutron API Reference <https://developer.openstack.org/api-ref/networking/v2/#bgp-mpls-vpn-interconnection>`_.
