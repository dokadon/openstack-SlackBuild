Mistral User Guide
==================

.. toctree::
   :maxdepth: 1

   installation_guide
   dashboard_guide
   mistralclient_guide
