============================
Mistral Policy Configuration
============================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Mistral. For a sample
configuration file, refer to :doc:`samples/policy-yaml`.

.. show-policy::
   :config-file: ../../tools/config/policy-generator.mistral.conf
