========================================
Welcome to puppet-vitrage Release Notes!
========================================

Contents
========

.. toctree::
   :maxdepth: 2

   unreleased
   pike


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
