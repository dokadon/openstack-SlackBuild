============
Installation
============

At the command line::

    $ pip install octavia-dashboard

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv octavia-dashboard
    $ pip install octavia-dashboard
