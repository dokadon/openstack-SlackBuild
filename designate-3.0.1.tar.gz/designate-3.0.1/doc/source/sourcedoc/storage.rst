.. _storage:

*******
Storage
*******

.. _storage-base:

Storage Base
=============

.. automodule:: designate.storage.base
    :members:
    :undoc-members:
    :show-inheritance:


