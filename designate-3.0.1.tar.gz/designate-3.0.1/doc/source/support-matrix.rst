
DNS Server Driver Support Matrix
================================

This info should be maintained along with the list of current driver maintainers responsible for the “Non Integrated” backends.
The upkeep of this list will fall on the PTL or his/her delegate.

Should a backend’s grade be in dispute, it falls on the current project PTL to make the final decision after listening to all sides concerns.

.. support_matrix::
