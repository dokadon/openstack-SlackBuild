=====
MOVED
=====

The senlin tempest plugin has moved to http://git.openstack.org/cgit/openstack/senlin-tempest-plugin
