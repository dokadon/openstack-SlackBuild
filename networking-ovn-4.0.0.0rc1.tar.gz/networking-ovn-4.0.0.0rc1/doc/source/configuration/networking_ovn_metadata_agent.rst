=================================
networking_ovn_metadata_agent.ini
=================================

.. show-options::
   :config-file: etc/oslo-config-generator/networking_ovn_metadata_agent.ini
