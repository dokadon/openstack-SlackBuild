===========================================
Mitaka Series (1.1.0 - 1.2.x) Release Notes
===========================================

.. release-notes::
   :branch: origin/stable/mitaka
