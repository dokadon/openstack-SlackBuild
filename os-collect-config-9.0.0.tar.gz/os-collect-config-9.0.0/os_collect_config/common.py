import requests

__all__ = ['requests']
