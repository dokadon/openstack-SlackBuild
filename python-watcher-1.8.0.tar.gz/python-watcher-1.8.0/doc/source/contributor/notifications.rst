..
      Except where otherwise noted, this document is licensed under Creative
      Commons Attribution 3.0 License.  You can view the license at:

          https://creativecommons.org/licenses/by/3.0/

.. _watcher_notifications:

========================
Notifications in Watcher
========================

.. versioned_notifications::
