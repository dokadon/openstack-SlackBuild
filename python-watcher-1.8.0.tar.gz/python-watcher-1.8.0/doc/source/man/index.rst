.. toctree::
   :glob:
   :maxdepth: 1

   watcher-api
   watcher-applier
   watcher-db-manage
   watcher-decision-engine