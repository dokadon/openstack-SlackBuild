.. _watcher_sample_configuration_files:

------------
watcher.conf
------------

The ``watcher.conf`` file contains most of the options to configure the
Watcher services.

.. show-options::
   :config-file: etc/watcher/oslo-config-generator/watcher.conf
