========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/badges/mistral-extra.svg
    :target: https://governance.openstack.org/reference/tags/index.html

.. Change things from this point on

==============
Mistral Extras
==============

Contains Mistral examples.

To see more detailed information about particular examples use README files
located in corresponding folders under ``examples/``.
