------
Client
------

.. automodule:: zaqarclient.queues.client

.. currentmodule:: zaqarclient.queues.client


Client Object Reference
-----------------------

This is the reference documentation for all API version.

API v1 and v1.1:

.. autoclass:: zaqarclient.queues.v1.client.Client
   :members:

API v2.0:

.. autoclass:: zaqarclient.queues.v2.client.Client
   :members:
