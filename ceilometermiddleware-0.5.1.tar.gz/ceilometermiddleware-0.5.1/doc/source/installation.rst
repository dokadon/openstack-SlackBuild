============
Installation
============

At the command line::

    $ pip install ceilometermiddleware

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv ceilometermiddleware
    $ pip install ceilometermiddleware
