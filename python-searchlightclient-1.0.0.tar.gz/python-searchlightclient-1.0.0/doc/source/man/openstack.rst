=========
openstack
=========

Please refer to OpenStack command-line interface `OpenStackClient`_.

.. _OpenStackClient: http://docs.openstack.org/cli-reference/openstack.html
