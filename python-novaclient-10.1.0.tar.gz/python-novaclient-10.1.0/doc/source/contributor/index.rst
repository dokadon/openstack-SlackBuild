===================
 Contributor Guide
===================

Code is hosted at `git.openstack.org`__. Submit bugs to the Nova project on
`Launchpad`__. Submit code to the `openstack/python-novaclient` project using
`Gerrit`__.

__ https://git.openstack.org/cgit/openstack/python-novaclient
__ https://launchpad.net/nova
__ https://docs.openstack.org/infra/manual/developers.html#development-workflow

.. toctree::
   :maxdepth: 2

   testing
