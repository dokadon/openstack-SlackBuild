Installs the Puppet package.

Configuration
-------------
None.
