.. TripleO Puppet Elements documentation master file, created by
   sphinx-quickstart on Fri Apr 18 09:19:09 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to TripleO Puppet Elements's documentation!
==================================================

Contents:

.. toctree::
   :maxdepth: 2



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

