.. cloudkitty documentation master file, created by
   sphinx-quickstart on Wed May 14 23:05:42 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

======================================
Welcome to CloudKitty's documentation!
======================================

CloudKitty is a Rating As A Service project aimed at translating metrics
to prices.

.. toctree::
   :maxdepth: 2

   install/index
   configuration/index
   admin/index
   devstack
   arch
   api
