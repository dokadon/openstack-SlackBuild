==========================
Sample configuration files
==========================

Configuration files can alter how cloudkitty behaves at runtime and by default
are located in ``/etc/cloudkitty/``. Links to sample configuration files can be
found below:

.. toctree::

   policy-yaml.rst
