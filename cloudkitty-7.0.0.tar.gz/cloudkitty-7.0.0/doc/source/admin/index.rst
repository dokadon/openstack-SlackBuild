====================
Administration Guide
====================

.. toctree::
   :glob:

   rating/introduction.rst
   rating/hashmap.rst
   rating/pyscripts.rst
