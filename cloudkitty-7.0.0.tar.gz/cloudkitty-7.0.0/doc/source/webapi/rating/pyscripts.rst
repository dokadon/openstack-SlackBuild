=========================
PyScripts Module REST API
=========================

.. rest-controller:: cloudkitty.rating.pyscripts.controllers.root:PyScriptsConfigController
   :webprefix: /v1/rating/module_config/pyscripts

.. rest-controller:: cloudkitty.rating.pyscripts.controllers.script:PyScriptsScriptsController
   :webprefix: /v1/rating/module_config/pyscripts/scripts

.. autotype:: cloudkitty.rating.pyscripts.datamodels.script.Script
   :members:

.. autotype:: cloudkitty.rating.pyscripts.datamodels.script.ScriptCollection
   :members:
