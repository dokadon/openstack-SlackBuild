==============================
 Using python-designateclient
==============================

.. toctree::

   bindings
   shell-v2
   shell
   shell-examples
