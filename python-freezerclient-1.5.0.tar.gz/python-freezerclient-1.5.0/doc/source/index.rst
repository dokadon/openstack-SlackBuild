==========================================
Welcome to Freezer's client documentation!
==========================================

Contents:

.. toctree::
   :maxdepth: 2

   cli/index


.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


