The :mod:`zaqar.storage.redis.claims` module
=============================================

.. automodule:: zaqar.storage.redis.claims
  :members:
  :undoc-members:
  :show-inheritance:
