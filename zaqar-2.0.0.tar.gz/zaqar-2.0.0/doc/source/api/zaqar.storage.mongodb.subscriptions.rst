The :mod:`zaqar.storage.mongodb.subscriptions` module
======================================================

.. automodule:: zaqar.storage.mongodb.subscriptions
  :members:
  :undoc-members:
  :show-inheritance:
