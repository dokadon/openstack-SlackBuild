The :mod:`zaqar.transport.wsgi.v2_0.flavors` module
====================================================

.. automodule:: zaqar.transport.wsgi.v2_0.flavors
  :members:
  :undoc-members:
  :show-inheritance:
