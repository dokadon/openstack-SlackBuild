The :mod:`zaqar.i18n` module
=============================

.. automodule:: zaqar.i18n
  :members:
  :undoc-members:
  :show-inheritance:
