The :mod:`zaqar.version` module
================================

.. automodule:: zaqar.version
  :members:
  :undoc-members:
  :show-inheritance:
