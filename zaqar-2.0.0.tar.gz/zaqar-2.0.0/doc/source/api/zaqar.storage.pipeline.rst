The :mod:`zaqar.storage.pipeline` module
=========================================

.. automodule:: zaqar.storage.pipeline
  :members:
  :undoc-members:
  :show-inheritance:
