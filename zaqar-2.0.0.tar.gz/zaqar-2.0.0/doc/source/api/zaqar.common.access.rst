The :mod:`zaqar.common.access` module
======================================

.. automodule:: zaqar.common.access
  :members:
  :undoc-members:
  :show-inheritance:
