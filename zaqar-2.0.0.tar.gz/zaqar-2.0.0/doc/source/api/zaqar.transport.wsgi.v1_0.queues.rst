The :mod:`zaqar.transport.wsgi.v1_0.queues` module
===================================================

.. automodule:: zaqar.transport.wsgi.v1_0.queues
  :members:
  :undoc-members:
  :show-inheritance:
