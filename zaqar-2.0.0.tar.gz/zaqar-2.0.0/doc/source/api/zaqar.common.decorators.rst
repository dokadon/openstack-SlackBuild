The :mod:`zaqar.common.decorators` module
==========================================

.. automodule:: zaqar.common.decorators
  :members:
  :undoc-members:
  :show-inheritance:
