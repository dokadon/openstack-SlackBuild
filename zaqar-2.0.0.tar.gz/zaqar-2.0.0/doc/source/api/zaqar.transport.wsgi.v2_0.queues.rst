The :mod:`zaqar.transport.wsgi.v2_0.queues` module
===================================================

.. automodule:: zaqar.transport.wsgi.v2_0.queues
  :members:
  :undoc-members:
  :show-inheritance:
