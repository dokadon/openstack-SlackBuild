The :mod:`zaqar.transport.wsgi.v1_1.homedoc` module
====================================================

.. automodule:: zaqar.transport.wsgi.v1_1.homedoc
  :members:
  :undoc-members:
  :show-inheritance:
