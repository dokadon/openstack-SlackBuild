The :mod:`zaqar.storage.base` module
=====================================

.. automodule:: zaqar.storage.base
  :members:
  :undoc-members:
  :show-inheritance:
