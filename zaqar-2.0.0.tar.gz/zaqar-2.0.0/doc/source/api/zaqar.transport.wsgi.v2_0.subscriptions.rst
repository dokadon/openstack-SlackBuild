The :mod:`zaqar.transport.wsgi.v2_0.subscriptions` module
==========================================================

.. automodule:: zaqar.transport.wsgi.v2_0.subscriptions
  :members:
  :undoc-members:
  :show-inheritance:
