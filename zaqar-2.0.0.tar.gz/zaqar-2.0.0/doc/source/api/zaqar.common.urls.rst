The :mod:`zaqar.common.urls` module
====================================

.. automodule:: zaqar.common.urls
  :members:
  :undoc-members:
  :show-inheritance:
