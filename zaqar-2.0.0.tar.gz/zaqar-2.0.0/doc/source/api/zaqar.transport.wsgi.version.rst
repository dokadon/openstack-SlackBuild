The :mod:`zaqar.transport.wsgi.version` module
===============================================

.. automodule:: zaqar.transport.wsgi.version
  :members:
  :undoc-members:
  :show-inheritance:
