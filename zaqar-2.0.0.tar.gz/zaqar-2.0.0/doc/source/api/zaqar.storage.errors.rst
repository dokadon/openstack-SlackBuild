The :mod:`zaqar.storage.errors` module
=======================================

.. automodule:: zaqar.storage.errors
  :members:
  :undoc-members:
  :show-inheritance:
