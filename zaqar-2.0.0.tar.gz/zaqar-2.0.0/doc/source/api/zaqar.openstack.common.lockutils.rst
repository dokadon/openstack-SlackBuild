The :mod:`zaqar.openstack.common.lockutils` module
===================================================

.. automodule:: zaqar.openstack.common.lockutils
  :members:
  :undoc-members:
  :show-inheritance:
