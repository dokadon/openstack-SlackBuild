The :mod:`zaqar.openstack.common.cache._backends.memory` module
================================================================

.. automodule:: zaqar.openstack.common.cache._backends.memory
  :members:
  :undoc-members:
  :show-inheritance:
