The :mod:`zaqar.transport.wsgi.v2_0.homedoc` module
====================================================

.. automodule:: zaqar.transport.wsgi.v2_0.homedoc
  :members:
  :undoc-members:
  :show-inheritance:
