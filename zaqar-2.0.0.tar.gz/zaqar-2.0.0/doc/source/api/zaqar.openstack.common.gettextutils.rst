The :mod:`zaqar.openstack.common.gettextutils` module
======================================================

.. automodule:: zaqar.openstack.common.gettextutils
  :members:
  :undoc-members:
  :show-inheritance:
