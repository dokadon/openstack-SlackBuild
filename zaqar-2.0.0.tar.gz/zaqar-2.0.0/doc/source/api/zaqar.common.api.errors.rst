The :mod:`zaqar.common.api.errors` module
==========================================

.. automodule:: zaqar.common.api.errors
  :members:
  :undoc-members:
  :show-inheritance:
