The :mod:`zaqar.api.v2.endpoints` module
=========================================

.. automodule:: zaqar.api.v2.endpoints
  :members:
  :undoc-members:
  :show-inheritance:
