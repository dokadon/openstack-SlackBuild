The :mod:`zaqar.openstack.common.cache.backends` module
========================================================

.. automodule:: zaqar.openstack.common.cache.backends
  :members:
  :undoc-members:
  :show-inheritance:
