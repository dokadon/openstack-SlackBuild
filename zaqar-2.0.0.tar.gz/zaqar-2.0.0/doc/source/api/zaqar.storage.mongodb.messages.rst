The :mod:`zaqar.storage.mongodb.messages` module
=================================================

.. automodule:: zaqar.storage.mongodb.messages
  :members:
  :undoc-members:
  :show-inheritance:
