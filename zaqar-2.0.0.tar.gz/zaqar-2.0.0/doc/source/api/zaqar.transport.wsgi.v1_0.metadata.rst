The :mod:`zaqar.transport.wsgi.v1_0.metadata` module
=====================================================

.. automodule:: zaqar.transport.wsgi.v1_0.metadata
  :members:
  :undoc-members:
  :show-inheritance:
