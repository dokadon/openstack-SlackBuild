The :mod:`zaqar.common.pipeline` module
========================================

.. automodule:: zaqar.common.pipeline
  :members:
  :undoc-members:
  :show-inheritance:
