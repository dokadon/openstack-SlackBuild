The :mod:`zaqar.common.api.response` module
============================================

.. automodule:: zaqar.common.api.response
  :members:
  :undoc-members:
  :show-inheritance:
