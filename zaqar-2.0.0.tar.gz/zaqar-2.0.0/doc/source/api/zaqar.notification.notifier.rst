The :mod:`zaqar.notification.notifier` module
==============================================

.. automodule:: zaqar.notification.notifier
  :members:
  :undoc-members:
  :show-inheritance:
