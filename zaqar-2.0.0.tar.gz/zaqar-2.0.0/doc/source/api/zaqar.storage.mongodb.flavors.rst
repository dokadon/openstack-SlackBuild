The :mod:`zaqar.storage.mongodb.flavors` module
================================================

.. automodule:: zaqar.storage.mongodb.flavors
  :members:
  :undoc-members:
  :show-inheritance:
