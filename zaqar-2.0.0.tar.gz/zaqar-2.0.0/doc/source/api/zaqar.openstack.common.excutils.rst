The :mod:`zaqar.openstack.common.excutils` module
==================================================

.. automodule:: zaqar.openstack.common.excutils
  :members:
  :undoc-members:
  :show-inheritance:
