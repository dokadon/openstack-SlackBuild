The :mod:`zaqar.storage.mongodb.catalogue` module
==================================================

.. automodule:: zaqar.storage.mongodb.catalogue
  :members:
  :undoc-members:
  :show-inheritance:
