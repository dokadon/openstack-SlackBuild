The :mod:`zaqar.transport.wsgi.errors` module
==============================================

.. automodule:: zaqar.transport.wsgi.errors
  :members:
  :undoc-members:
  :show-inheritance:
