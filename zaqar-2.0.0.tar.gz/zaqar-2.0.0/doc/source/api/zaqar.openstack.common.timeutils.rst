The :mod:`zaqar.openstack.common.timeutils` module
===================================================

.. automodule:: zaqar.openstack.common.timeutils
  :members:
  :undoc-members:
  :show-inheritance:
