-------------
Storage Layer
-------------

The **storage drivers** are responsible for interacting with the storage backends
and, that way, store or retrieve the data coming from the transport layer.

.. toctree::
   :maxdepth: 1

   api
   mongodb
