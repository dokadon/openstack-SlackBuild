.. _verify:

Verify operation
~~~~~~~~~~~~~~~~

Verify operation of the Root Cause Analysis service.

.. note::

   Perform these commands on the controller node.

#. Show the topology to verify successful launch:

   .. code-block:: console

      $ vitrage topology show
