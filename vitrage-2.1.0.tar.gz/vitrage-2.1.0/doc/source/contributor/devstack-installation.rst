=====================
Devstack Installation
=====================

Vitrage Devstack Installation
=============================

* `Enabling Vitrage in devstack <https://github.com/openstack/vitrage/blob/master/devstack/README.rst>`_

* `Enabling Vitrage in horizon <https://github.com/openstack/vitrage-dashboard/blob/master/README.rst>`_

External Monitor Installation
=============================

To install Nagios or Zabbix external monitors:

.. toctree::
   :maxdepth: 1

   nagios-devstack-installation
   zabbix_vitrage
