============
Installation
============

At the command line::

    $ pip install oslo.middleware

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv oslo.middleware
    $ pip install oslo.middleware