PANEL_DASHBOARD = 'admin'
PANEL_GROUP = 'admin'
PANEL = 'shares'
ADD_PANEL = 'manila_ui.dashboards.admin.shares.panel.Shares'
