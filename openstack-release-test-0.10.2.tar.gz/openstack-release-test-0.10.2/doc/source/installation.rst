============
Installation
============

At the command line::

    $ pip install release-test

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv release-test
    $ pip install release-test
