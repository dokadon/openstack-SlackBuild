python-senlinclient
===================

Client library for OpenStack Clustering Service API
