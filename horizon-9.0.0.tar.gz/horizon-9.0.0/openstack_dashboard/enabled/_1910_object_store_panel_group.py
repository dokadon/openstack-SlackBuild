from django.utils.translation import ugettext_lazy as _

PANEL_GROUP = 'object_store'
PANEL_GROUP_NAME = _('Object Store')
PANEL_GROUP_DASHBOARD = 'project'
