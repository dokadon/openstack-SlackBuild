=======================
 Configuration Options
=======================

senlin uses `oslo.config` to define and manage configuration options to
allow the deployer to control many aspects of the service API and the service
engine.

.. show-options:: senlin.config

Options
=======

.. currentmodule:: senlin.common.config

.. autofunction:: list_opts
