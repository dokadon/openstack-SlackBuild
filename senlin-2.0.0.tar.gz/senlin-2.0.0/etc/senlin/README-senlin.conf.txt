To generate the sample senlin.conf file, run the following
command from the top level of the senlin directory:

tox -egenconfig
