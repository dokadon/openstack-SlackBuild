====================
Neutron agent config
====================

The following section can be added to Neutron agent configuration.

.. show-options::
   :config-file: etc/oslo-config-generator/neutron-agent.conf
