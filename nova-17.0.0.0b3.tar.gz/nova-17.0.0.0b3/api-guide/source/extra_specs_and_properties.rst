=======================================
Flavor Extra Specs and Image Properties
=======================================

TODO: Generic description about Flavor Extra Specs and Image Properties.

Flavor Extra Specs
==================

TODO: List the extra specs which we supported at here. The best is the extra
specs can auto-gen from the nova code.

Image Properties
================

TODO: List the properties which affect the server creation. The best is the
properties can auto-gen from the image properties object.
