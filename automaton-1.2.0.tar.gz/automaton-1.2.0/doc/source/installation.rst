============
Installation
============

At the command line::

    $ pip install automaton

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv automaton
    $ pip install automaton
