==========
ceilometer
==========

.. _ceilometer_10.0.1:

10.0.1
======

.. _ceilometer_10.0.1_New Features:

New Features
------------

.. releasenotes/notes/add-disk-latency-metrics-9e5c05108a78c3d9.yaml @ f4b58ae01e8ddfc515e6f14a0d19d726370f4870

- Add `disk.device.read.latency` and `disk.device.write.latency` meters to
  capture total time used by read or write operations.

