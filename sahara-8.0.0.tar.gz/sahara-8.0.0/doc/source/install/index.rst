==================
Installation Guide
==================

.. toctree::
   :maxdepth: 2

   installation-guide
   dashboard-guide
