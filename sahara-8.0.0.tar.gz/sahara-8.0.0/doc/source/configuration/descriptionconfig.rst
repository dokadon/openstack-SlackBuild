Configuration options
=====================

This section provides a list of the configuration options that can
be set in the sahara configuration file.

.. show-options::
   :config-file: tools/config/config-generator.sahara.conf
