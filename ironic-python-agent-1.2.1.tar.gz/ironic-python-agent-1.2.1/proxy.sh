#!/bin/sh

# Have things work for users who didn't run with the
# imagebuild/coreos/docker_build.bash script

$*
