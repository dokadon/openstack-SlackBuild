========================
Team and repository tags
========================

.. image:: http://governance.openstack.org/badges/os-vif.svg
    :target: http://governance.openstack.org/reference/tags/index.html

.. Change things from this point on

======
os-vif
======

.. image:: https://img.shields.io/pypi/v/os-vif.svg
    :target: https://pypi.python.org/pypi/os-vif/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/dm/os-vif.svg
    :target: https://pypi.python.org/pypi/os-vif/
    :alt: Downloads

A library for plugging and unplugging virtual interfaces in OpenStack.

* License: Apache License, Version 2.0
* Documentation: https://docs.openstack.org/os-vif/latest/
* Source: https://git.openstack.org/cgit/openstack/os-vif
* Bugs: https://bugs.launchpad.net/os-vif
