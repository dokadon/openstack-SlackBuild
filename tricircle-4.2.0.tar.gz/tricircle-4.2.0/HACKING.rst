================================
The Tricircle Style Commandments
================================

Please read the OpenStack Style Commandments
    https://docs.openstack.org/hacking/latest/
