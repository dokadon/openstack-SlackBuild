=====
Usage
=====

To use tricircle in a project::

    import tricircle
