====================
Tricircle User Guide
====================

.. toctree::
   :maxdepth: 3

   readme
   usage
