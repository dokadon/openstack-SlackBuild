===================
Networking Scenario
===================

.. toctree::
    :maxdepth: 4

    networking-guide-direct-provider-networks.rst
    networking-guide-multiple-external-networks.rst
    networking-guide-multiple-ns-with-ew-enabled.rst
    networking-guide-single-external-network.rst
    networking-guide-local-networking.rst
