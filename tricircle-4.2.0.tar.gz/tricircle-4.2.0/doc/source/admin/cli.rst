================================
Command-Line Interface Reference
================================

Synopsis
========

Follow OpenStack CLI format ::

  openstack [<global-options>] <command> [<command-arguments>]

The CLI for Tricircle can be executed as follows ::

  openstack multiregion networking <command> [<command-arguments>]

All commands will issue request to Tricircle Admin API.
