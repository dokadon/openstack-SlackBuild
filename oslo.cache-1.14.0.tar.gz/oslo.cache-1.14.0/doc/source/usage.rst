=======
 Usage
=======

To use oslo.cache in a project::

    import oslo_cache
