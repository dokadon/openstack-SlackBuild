----------
RPC Client
----------

.. currentmodule:: oslo_messaging

.. autoclass:: RPCClient
   :members:

.. autoexception:: RemoteError
