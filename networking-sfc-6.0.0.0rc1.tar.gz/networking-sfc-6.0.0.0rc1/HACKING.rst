Networking SFC Style Commandments
=================================

Please see the Neutron HACKING.rst file for style commandments for
networking-sfc:

`Neutron HACKING.rst <http://git.openstack.org/cgit/openstack/neutron/tree/HACKING.rst>`_
