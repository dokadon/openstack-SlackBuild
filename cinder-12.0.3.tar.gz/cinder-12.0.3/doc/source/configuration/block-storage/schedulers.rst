========================
Block Storage schedulers
========================

Block Storage service uses the ``cinder-scheduler`` service
to determine how to dispatch block storage requests.

For more information, see:

.. toctree::
   :maxdepth: 1

   Cinder Scheduler Filters <scheduler-filters>
   Cinder Scheduler Weights <scheduler-weights>
