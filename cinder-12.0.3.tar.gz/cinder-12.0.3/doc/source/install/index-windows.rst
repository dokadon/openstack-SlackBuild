=====================================
Cinder Installation Guide for Windows
=====================================

This section describes how to install and configure storage nodes
for the Block Storage service.

For the moment, Cinder Volume is the only Cinder service supported on
Windows.

.. toctree::
   :maxdepth: 2

   cinder-storage-install-windows.rst
   cinder-verify.rst
