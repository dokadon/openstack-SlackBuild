==========================
Sample networking-sfc.conf
==========================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/networking-sfc.conf.sample>`_.

.. literalinclude::
   ../../_static/config_samples/networking-sfc.conf.sample
