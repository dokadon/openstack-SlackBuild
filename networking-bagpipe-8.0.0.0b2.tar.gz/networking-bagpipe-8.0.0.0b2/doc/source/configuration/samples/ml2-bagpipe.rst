========================================
Sample bagpipe ML2 neutron server config
========================================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/ml2-bagpipe.conf.sample>`_.

.. literalinclude::
   ../../_static/config_samples/ml2-bagpipe.conf.sample
