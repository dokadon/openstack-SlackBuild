Dashboards
==========

Gerrit Dashboards
~~~~~~~~~~~~~~~~~

`Networking-MidoNet Review Inbox <https://review.openstack.org/#/dashboard/?foreach=%28project%3Aopenstack%2Fnetworking%2Dmidonet%29+status%3Aopen+NOT+owner%3Aself+NOT+label%3AWorkflow%3C%3D%2D1+label%3AVerified%3E%3D1%2Czuul+NOT+reviewedby%3Aself&title=Networking%2DMidoNet+Review+Inbox&Needs+Feedback+%28Changes+older+than+5+days+that+have+not+been+reviewed+by+anyone%29=NOT+label%3ACode%2DReview%3C%3D%2D1+NOT+label%3ACode%2DReview%3E%3D1+age%3A5d+branch%3Amaster&You+are+a+reviewer%2C+but+haven%27t+voted+in+the+current+revision=NOT+label%3ACode%2DReview%3C%3D%2D1%2Cself+NOT+label%3ACode%2DReview%3E%3D1%2Cself+reviewer%3Aself+branch%3Amaster&Needs+final+%2B2=label%3ACode%2DReview%3E%3D2+NOT%28reviewerin%3Anetworking%2Dmidonet%2Dcore+label%3ACode%2DReview%3C%3D%2D1%29+limit%3A50+branch%3Amaster&Passed+Zuul%2C+No+Negative+Core+Feedback=NOT+label%3ACode%2DReview%3E%3D2+NOT%28reviewerin%3Anetworking%2Dmidonet%2Dcore+label%3ACode%2DReview%3C%3D%2D1%29+limit%3A50+branch%3Amaster&Wayward+Changes+%28Changes+with+no+code+review+in+the+last+2days%29=NOT+label%3ACode%2DReview%3C%3D%2D1+NOT+label%3ACode%2DReview%3E%3D1+age%3A2d+branch%3Amaster&stable%2Focata=branch%3Astable%2Focata&stable%2Fnewton=branch%3Astable%2Fnewton&other+branches=NOT+branch%3Amaster+AND+NOT+branch%3Astable%2Focata+AND+NOT+branch%3Astable%2Fnewton>`_

Grafana Dashboards
~~~~~~~~~~~~~~~~~~

`Networking-MidoNet Failure Rate <http://grafana.openstack.org/dashboard/db/networking-midonet-failure-rate>`_
