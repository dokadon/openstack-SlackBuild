=========================
Sample neutron_fwaas.conf
=========================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/neutron_fwaas.conf.sample>`_.

.. literalinclude:: ../../_static/config_samples/neutron_fwaas.conf.sample
