FireWall as a Service V2
========================

The `FireWall as a Service API V2
<https://specs.openstack.org/openstack/neutron-specs/specs/newton/fwaas-api-2.0.html>`_
specification lists the changes that together compose FWaaS V2.  These changes
are not fully implemented.
