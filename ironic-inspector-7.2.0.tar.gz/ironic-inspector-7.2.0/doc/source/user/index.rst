User Guide
==========

How Ironic Inspector Works
--------------------------

.. toctree::
  :maxdepth: 2

  workflow

How to use Ironic Inspector
---------------------------

.. toctree::
  :maxdepth: 2

  usage

HTTP API Reference
------------------

.. toctree::
  :maxdepth: 2

  http-api

Troubleshooting
---------------

.. toctree::
  :maxdepth: 2

  troubleshooting
