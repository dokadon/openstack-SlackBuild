.. _contributing_link:

.. include:: ../../../CONTRIBUTING.rst

Python API
~~~~~~~~~~

.. toctree::
  :maxdepth: 1

  api/autoindex
