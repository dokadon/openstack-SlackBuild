This is a work in progress to implement the specs currently discussed at:
https://review.openstack.org/#/c/177740/

