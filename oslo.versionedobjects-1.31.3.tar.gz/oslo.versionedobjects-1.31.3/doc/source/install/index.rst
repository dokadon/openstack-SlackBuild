==============
 Installation
==============

At the command line::

    $ pip install oslo.versionedobjects

To use ``oslo_versionedobjects.fixture``, some additional dependencies
are needed. They can be installed using the ``fixtures`` extra::

    $ pip install 'oslo.versionedobjects[fixtures]'
