==========
 excutils
==========

.. automodule:: oslo_utils.excutils
   :members:
