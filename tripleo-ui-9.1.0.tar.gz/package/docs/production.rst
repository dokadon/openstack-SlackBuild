Production
==========

Building for production
-----------------------

::

   $ npm run build

This will produce a minified and mangled file in ``dist/tripleo_ui.js``.  It
also enables React production mode.
