from designatedashboard.api import rest  # noqa
