=======================
 Configuration Options
=======================

oslo.policy uses oslo.config to define and manage configuration options
to allow the deployer to control where the policy files are located and
the default rule to apply when policy etc.

.. show-options:: oslo.policy
