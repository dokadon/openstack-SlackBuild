==========================
Telemetry Alarming service
==========================

.. toctree::

   get_started.rst
   install-obs.rst
   install-rdo.rst
   install-ubuntu.rst
   verify.rst
   next-steps.rst

This chapter assumes a working setup of OpenStack following the base
Installation Guide.
