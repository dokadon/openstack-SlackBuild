aodh
====

Release notes can be read online at:
  http://docs.openstack.org/developer/aodh/releasenotes/index.html

Documentation for the project can be found at:
  http://docs.openstack.org/developer/aodh/

The project home is at:
  http://launchpad.net/aodh
