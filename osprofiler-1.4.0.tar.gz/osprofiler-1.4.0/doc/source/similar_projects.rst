================
Similar projects
================

Other projects (some alive, some abandoned, some research prototypes)
that are similar (in idea and ideal to OSprofiler).

* `Zipkin`_
* `Dapper`_
* `Tomograph`_
* `HTrace`_
* `OpenTracing`_

.. _Zipkin: https://twitter.github.io/zipkin/
.. _Dapper: http://research.google.com/pubs/pub36356.html
.. _Tomograph: https://github.com/stackforge/tomograph
.. _HTrace: https://htrace.incubator.apache.org/
.. _OpenTracing: http://opentracing.io/
