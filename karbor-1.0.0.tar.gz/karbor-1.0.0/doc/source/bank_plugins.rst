Bank Plugins
------------

Swift
"""""

.. autoclass:: karbor.services.protection.bank_plugins.swift_bank_plugin.SwiftBankPlugin
  :noindex:
  :members:
  :show-inheritance:


Local Filesystem
""""""""""""""""

.. autoclass:: karbor.services.protection.bank_plugins.file_system_bank_plugin.FileSystemBankPlugin
  :noindex:
  :members:
  :show-inheritance:
