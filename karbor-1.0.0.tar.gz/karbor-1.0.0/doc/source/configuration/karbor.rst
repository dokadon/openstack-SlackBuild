.. _karbor.conf:

-----------
karbor.conf
-----------

.. show-options::
   :config-file: etc/oslo-config-generator/karbor.conf
