.. _karbor-policy-generator.conf:

====================
Policy configuration
====================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Karbor. For a sample
configuration file.

.. show-policy::
   :config-file: ../../etc/karbor-policy-generator.conf
