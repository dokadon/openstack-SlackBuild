Protection Plugins
------------------

Project
^^^^^^^


Server
^^^^^^

Server to Bank
""""""""""""""

.. autoclass:: karbor.services.protection.protection_plugins.server.nova_protection_plugin.NovaProtectionPlugin()
  :noindex:
  :members:
  :show-inheritance:

Volume
^^^^^^

Cinder Backup
"""""""""""""

.. autoclass:: karbor.services.protection.protection_plugins.volume.cinder_protection_plugin.CinderBackupProtectionPlugin()
  :noindex:
  :members:
  :show-inheritance:

Image
^^^^^

Image to Bank
"""""""""""""

.. autoclass:: karbor.services.protection.protection_plugins.image.image_protection_plugin.GlanceProtectionPlugin()
  :noindex:
  :members:
  :show-inheritance:


