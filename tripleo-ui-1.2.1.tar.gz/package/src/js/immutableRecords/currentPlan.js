import { Record } from 'immutable';

export const CurrentPlanState = Record({
  conflict: undefined,
  currentPlanName: undefined
});
