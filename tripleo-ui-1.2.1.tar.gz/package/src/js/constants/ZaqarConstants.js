let appConfig = window.tripleOUiConfig || {};

let zaqarDefaultQueue = appConfig.zaqar_default_queue || 'tripleo';

export const ZAQAR_DEFAULT_QUEUE = zaqarDefaultQueue;
