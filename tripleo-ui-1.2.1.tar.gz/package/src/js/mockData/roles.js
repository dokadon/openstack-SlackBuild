export default [
  {
    name: 'control',
    title: 'Controller'
  },
  {
    name: 'compute',
    title: 'Compute'
  },
  {
    name: 'blockStorage',
    title: 'Block Storage'
  },
  {
    name: 'objectStorage',
    title: 'Object Storage'
  },
  {
    name: 'cephStorage',
    title: 'Ceph Storage'
  }
];
