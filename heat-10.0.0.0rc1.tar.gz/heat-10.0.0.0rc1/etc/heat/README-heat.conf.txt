To generate the sample heat.conf file, run the following
command from the top level of the heat directory:

tox -egenconfig
