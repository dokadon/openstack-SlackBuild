Administrator Guide
===================

How to upgrade Ironic Inspector
-------------------------------

.. toctree::
  :maxdepth: 2

  upgrade
