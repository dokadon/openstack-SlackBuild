========
Policies
========

The following is an overview of all available policies in **ironic inspector**.
For a sample configuration file, refer to :doc:`sample-policy`.

.. show-policy::
   :config-file: policy-generator.conf
