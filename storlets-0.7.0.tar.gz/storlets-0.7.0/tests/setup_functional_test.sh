#!/bin/bash
./s2aio.sh install
