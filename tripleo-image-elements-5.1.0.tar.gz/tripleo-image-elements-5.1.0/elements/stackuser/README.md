Creates a user 'stack' with password 'stack'.

This user can be customised with an SSH key and proxy details if the
local-config element is also used.
