Installs Rally OpenStack benchmarking and profiling tool.

Overview
--------

[Rally] (https://wiki.openstack.org/wiki/Rally) is a CLI tool (and optional API
service) that allows you to test how your OpenStack installation performs at
scale and find bottlenecks using the integrated profiler.

Wiki [HowTo page] (https://wiki.openstack.org/wiki/Rally/HowTo) provides examples
how to use Rally.
