Use lio as the cinder iscsi helper.

The cinder.iscsi-target configuration option must be set to "lioadm".  See the cinder
element readme for details.