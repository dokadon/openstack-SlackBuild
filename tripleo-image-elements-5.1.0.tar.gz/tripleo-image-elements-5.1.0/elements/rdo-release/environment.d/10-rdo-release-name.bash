export RDO_RELEASE=${RDO_RELEASE:-kilo}
