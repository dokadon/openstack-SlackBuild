Enables the RDO yum repository for a released version of OpenStack on Red Hat
based operating systems. $RDO_RELEASE is set by default to the latest openstack
release. It can be overriden to select the version of RDO to install.
Set the environment variable to 'juno' to set the default version to
install to 'juno'.
