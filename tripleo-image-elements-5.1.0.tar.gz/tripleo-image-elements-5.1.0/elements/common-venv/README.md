Install everything in a common virtualenv.
