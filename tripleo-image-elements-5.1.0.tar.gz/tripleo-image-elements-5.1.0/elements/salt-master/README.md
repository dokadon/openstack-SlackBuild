Adds salt-master, a config-management tool, to the image.
