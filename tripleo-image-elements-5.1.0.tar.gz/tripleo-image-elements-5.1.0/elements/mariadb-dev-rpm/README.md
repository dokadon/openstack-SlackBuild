Installs mariadb devel package from default repositories

This is a separate element because different devel packages are installed for
mysql and for mariadb.
