Installs and configures pacemaker.

Configuration is optional.

Configuration
--------------

    pacemaker:
        stonith_enabled : false
        recheck_interval : 5
        quorum_policy : ignore
