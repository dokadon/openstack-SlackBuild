Install OpenStack Trove.
