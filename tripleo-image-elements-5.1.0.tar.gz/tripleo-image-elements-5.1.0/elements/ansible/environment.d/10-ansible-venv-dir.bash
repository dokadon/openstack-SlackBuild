#!/bin/bash
set -ue

export ANSIBLE_VENV_DIR=${ANSIBLE_VENV_DIR:-"/opt/stack/venvs/ansible"}
