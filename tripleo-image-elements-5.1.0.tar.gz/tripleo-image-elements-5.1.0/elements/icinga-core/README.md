Install Icinga's core from the distribution repository.

