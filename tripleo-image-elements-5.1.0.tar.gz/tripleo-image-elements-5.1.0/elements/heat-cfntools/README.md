Install the Heat cfntools (for CloudFormation) to enable HEAT
templates to make use of advanced features of HEAT such as watches and
AWS::CloudFormation::Init
