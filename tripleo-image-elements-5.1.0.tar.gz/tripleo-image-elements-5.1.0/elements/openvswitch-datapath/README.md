Install openvswitch datapath from packages.

Note: For kernels >= 3.12 there is no need to install
the dkms datapath to get GRE and VXLAN support.
