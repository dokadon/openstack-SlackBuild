Enable the Ceilometer Alarm Notification service
