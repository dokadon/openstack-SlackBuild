Installs all openstack sql databases on a single server,
for the purpose of building a bootstrap image.
