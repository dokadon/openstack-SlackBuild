Enable the Ceilometer Collector service
