Install and configure Neutron.

Configuration
-------------

    neutron:
      verbose: False
        - Print more verbose output (set logging level to INFO
          instead of default WARNING level).
      debug: False
        - Print debugging output (set logging level to DEBUG
          instead of default WARNING level).
      flat-networks: "tripleo-bm-test"
