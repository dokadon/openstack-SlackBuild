Enable the Ceilometer API service
