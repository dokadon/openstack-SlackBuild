This element contains code common for mariadb installations, make sure
you include one of mariadb or mariadb-rpm when including this element.
