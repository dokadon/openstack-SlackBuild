Install os-cloud-config
=======================

os-cloud-config contains useful utilities such as init-keystone, register-nodes
