Installs cinder volume service.
