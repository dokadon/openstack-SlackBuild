Enables the Contrail repository.

This element requires the $CONTRAIL_URL variable set to specify a path to a
contrail-install-packages package to be installed.

This elements currently only works on a RHEL based system.
