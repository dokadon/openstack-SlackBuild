Swift element for installing a swift storage server
