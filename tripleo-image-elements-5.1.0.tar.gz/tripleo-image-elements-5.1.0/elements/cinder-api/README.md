Installs cinder api and scheduler services.
