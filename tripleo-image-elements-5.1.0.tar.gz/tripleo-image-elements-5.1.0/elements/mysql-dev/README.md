Installs mysql devel package

This is a separate element because different devel packages are installed for
mysql and for mariadb.
