Install tripleo-heat-templates.
