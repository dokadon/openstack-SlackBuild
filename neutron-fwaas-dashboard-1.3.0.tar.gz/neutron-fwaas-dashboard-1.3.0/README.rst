========================
Neutron FWaaS Dashboard
========================

OpenStack Dashboard panels for Neutron FWaaS

* Documentation: https://docs.openstack.org/neutron-fwaas-dashboard/latest/
* Source: http://git.openstack.org/cgit/openstack/neutron-fwaas-dashboard
* Bugs: http://bugs.launchpad.net/neutron-fwaas-dashboard
