:tocdepth: 2

===================
 Database API
===================

.. rest_expand_all::

.. include:: api-versions.inc
.. include:: database-instances.inc
.. include:: database-instance-actions.inc
.. include:: databases.inc
.. include:: user-management.inc
.. include:: flavors.inc
.. include:: datastores.inc
.. include:: configurations.inc
