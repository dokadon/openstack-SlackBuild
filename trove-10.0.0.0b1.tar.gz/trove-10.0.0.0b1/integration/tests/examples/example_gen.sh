#!/bin/bash

python ./examples/example_generation.py ./examples/local.conf

