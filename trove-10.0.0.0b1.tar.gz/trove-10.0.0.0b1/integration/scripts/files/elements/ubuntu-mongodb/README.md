Sets up a MongoDB install in the image.
