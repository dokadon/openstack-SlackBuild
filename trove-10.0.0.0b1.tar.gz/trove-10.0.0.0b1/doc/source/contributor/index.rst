=======================
 Contributor Resources
=======================

For those wishing to develop Trove itself, or to extend Trove's
functionality, the following resources are provided.


.. toctree::
   :maxdepth: 1

   design
   testing
   how_to_create_a_trove_instance.rst
