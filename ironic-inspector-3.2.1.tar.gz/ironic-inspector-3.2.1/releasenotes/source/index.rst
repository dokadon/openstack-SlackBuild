===============================
 Ironic Inspector Release Notes
===============================

.. toctree::
   :maxdepth: 1

   Current (2.3.0 - unreleased) <current-series>
   Mitaka (2.3.0 - unreleased) <mitaka>
   Liberty (2.0.0 - 2.2.x) <liberty>


.. toctree::
   :hidden:

   unreleased
