.. _contributing_link:

.. include:: ../../CONTRIBUTING.rst
