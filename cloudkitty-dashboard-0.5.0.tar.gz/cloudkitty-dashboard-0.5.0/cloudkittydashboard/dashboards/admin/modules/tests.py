from horizon.test import helpers as test


class CkprojectTests(test.TestCase):
    # Unit tests for ckproject.
    def test_me(self):
        self.assertTrue(1 + 1 == 2)
