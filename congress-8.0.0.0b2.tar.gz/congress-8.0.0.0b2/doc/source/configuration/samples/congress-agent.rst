==========================
Sample congress-agent.conf
==========================

This sample configuration can also be viewed in `the raw format
<../../_static/congress-agent.conf.sample>`_.

.. literalinclude:: ../../_static/congress-agent.conf.sample
