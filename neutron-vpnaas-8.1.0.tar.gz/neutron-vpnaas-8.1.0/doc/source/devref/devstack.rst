===============================
Configuring VPNaaS for DevStack
===============================

-----------------------
Multinode vs All-In-One
-----------------------

Devstack typically runs in single or "All-In-One" (AIO) mode.  However, it
can also be deployed to run on multiple nodes. For VPNaaS, running on an
AIO setup is simple, as everything happens on the same node. However, to
deploy to a multinode setup requires the following things to happen:

#. Each controller node requires database migrations in support of running
   VPNaaS.
#. Each network node that would run the L3 agent needs to run the Neutron
   VPNaaS agent in its place.

Therefore, the devstack plugin script needs some extra logic.

----------------
How to Configure
----------------

To configure VPNaaS, it is only necessary to enable the neutron-vpnaas
devstack plugin by adding the following line to the [[local|localrc]]
section of devstack's local.conf file::

   enable_plugin neutron-vpnaas <GITURL> [BRANCH]

   <GITURL> is the URL of a neutron-vpnaas repository
   [BRANCH] is an optional git ref (branch/ref/tag).  The default is master.

   For example::

       enable_plugin neutron-vpnaas https://git.openstack.org/openstack/neutron-vpnaas stable/kilo

This VPNaaS devstack plugin code will then

#. Install the common VPNaaS configuration and code,

#. Apply database migrations on nodes that are running the controller (as
   determined by enabling the q-svc service),

#. Run the VPNaaS agent on nodes that would normally be running the L3 agent
   (as determined by enabling the q-l3 service).
