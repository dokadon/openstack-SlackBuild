===========================
Root Cause Analysis service
===========================

.. toctree::
   :maxdepth: 2

   get_started.rst
   install.rst
   verify.rst
   next-steps.rst

The Root Cause Analysis service (vitrage) provides...

This chapter assumes a working setup of OpenStack following the
`OpenStack Installation Guide <https://docs.openstack.org/install-guide/>`_.
