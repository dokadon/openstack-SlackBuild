=============
Install Solum
=============

Distro specific installation
----------------------------

TODO add docs here on how to install on different distros like:

 - debian
 - redhat
 - suse
 - ubuntu

For a development installation use devstack
-------------------------------------------
.. include:: ../../../contrib/devstack/README.rst
