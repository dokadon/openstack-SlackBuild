# This directory contains common reusable code for lp-cedarish and lp-dockerfile.

# TODO(ravips): Reorganize language pack directory structure
#   solum/contrib--> language-pack
#                       |
#                       --> common (code common to all lp formats)
#                       |
#                       --> formats (supported formats)
#                             |
#                             --> cedarish
#                             |     |
#                             |     --> common (code common to cedarish formats)
#                             |     |
#                             |     --> docker
#                             |     |
#                             |     --> vm
#                             |
#                             --> dockerfile
