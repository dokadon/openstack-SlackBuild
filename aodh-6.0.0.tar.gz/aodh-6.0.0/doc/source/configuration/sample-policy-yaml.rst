===========
policy.yaml
===========

Use the ``policy.yaml`` file to define additional access controls that will be
applied to Aodh:

.. literalinclude:: ../_static/aodh.policy.yaml.sample
