=====================================
Aodh Sample Policy Configuration File
=====================================

The following is an overview of all available policies in Aodh.
For a sample configuration file, refer to :doc:`sample-policy-yaml`.

.. show-policy::
   :config-file: ../../aodh/cmd/aodh-policy-generator.conf
