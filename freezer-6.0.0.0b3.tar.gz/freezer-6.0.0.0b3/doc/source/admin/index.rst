Admin Guide
===========

Table of Contents:

.. toctree::
   :maxdepth: 2
   
   installation
   operation
   