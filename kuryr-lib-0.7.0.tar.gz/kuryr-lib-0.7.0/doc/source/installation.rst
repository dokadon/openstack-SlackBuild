============
Installation
============

At the command line::

    $ pip install kuryr

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv kuryr
    $ pip install kuryr
