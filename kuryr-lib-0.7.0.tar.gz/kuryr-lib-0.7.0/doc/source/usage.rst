========
Usage
========

To use kuryr in a project::

    import kuryr
