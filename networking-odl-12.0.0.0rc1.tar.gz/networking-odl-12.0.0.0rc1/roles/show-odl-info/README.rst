Prints ODL information that is useful for debugging

**Role Variables**

.. zuul:rolevar:: devstack_base_dir
   :default: /opt/stack

      The devstack base directory.
