Ocata ODL Reference
===================

.. contents::

OpenDaylight Components
-----------------------

With ocata legacy netvirt is recommended to use with boron snapshot.
However legacy netvirt may not work properly with carbon snapshot
onwards.

+-------------------------------------------------------+
| OpenDaylight Componetns                               |
+===============================+=======================+
| Boron Snapshot                |            Yes        |
+-------------------------------+-----------------------+
| Carbon Snapshot               |            Yes        |
+-------------------------------+-----------------------+
| Nitrogen Snapshot             |            No         |
+-------------------------------+-----------------------+
| Netvirt                       | odl-openstack-netvirt |
+-------------------------------+-----------------------+
