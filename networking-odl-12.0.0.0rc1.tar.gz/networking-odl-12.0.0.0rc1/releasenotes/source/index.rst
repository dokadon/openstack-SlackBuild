.. Networking OpenDaylight Release Notes documentation master file, created by
   sphinx-quickstart on Fri Jul 22 14:54:21 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Networking OpenDaylight Release Notes's documentation!
=================================================================

Contents:

.. toctree::
   :maxdepth: 2

   unreleased
   pike
   ocata
   newton
