Glance Store Library
=====================

Glance's stores library

* License: Apache License, Version 2.0
* Documentation: http://docs.openstack.org/developer/glance_store
* Source: http://git.openstack.org/cgit/openstack/glance_store
* Bugs: http://bugs.launchpad.net/glance-store
