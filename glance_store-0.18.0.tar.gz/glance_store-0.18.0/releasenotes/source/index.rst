============================
 Glance_store Release Notes
============================

.. toctree::
   :maxdepth: 1

   liberty
   unreleased
   mitaka
