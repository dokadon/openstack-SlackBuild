=====
Usage
=====

To use python-vitrageclient in a project::

    >>> from vitrageclient.v1 import client
    >>> vitrage = client.Client(...)
    >>> vitrage.topology.show()

