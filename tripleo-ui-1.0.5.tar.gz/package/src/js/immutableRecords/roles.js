import { Record } from 'immutable';

export const Role = Record({
  name: undefined,
  title: undefined,
  identifier: undefined
});
