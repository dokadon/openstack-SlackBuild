import keyMirror from 'keymirror';

export default keyMirror({
  NOTIFY: null,
  REMOVE_NOTIFICATION: null,
  NOTIFICATION_VIEWED: null
});
