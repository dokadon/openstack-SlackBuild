import keyMirror from 'keymirror';

export default keyMirror({
  FETCH_ROLES_PENDING: null,
  FETCH_ROLES_SUCCESS: null,
  FETCH_ROLES_FAILED: null
});
