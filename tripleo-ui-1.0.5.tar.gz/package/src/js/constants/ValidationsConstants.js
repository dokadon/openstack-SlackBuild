import keyMirror from 'keymirror';

export default keyMirror({
  FETCH_VALIDATIONS_PENDING: null,
  FETCH_VALIDATIONS_SUCCESS: null,
  FETCH_VALIDATIONS_FAILED: null
});
