import React from 'react';

import { PageHeader } from './ui/PageHeader';

export default class Overview extends React.Component {
  render() {
    return (
      <PageHeader>Overview</PageHeader>
    );
  }
}
