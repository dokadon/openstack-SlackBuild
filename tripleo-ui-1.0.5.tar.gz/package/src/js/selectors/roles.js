export const getRole = (state, roleIdentifier) => state.roles.get('roles').get(roleIdentifier);
