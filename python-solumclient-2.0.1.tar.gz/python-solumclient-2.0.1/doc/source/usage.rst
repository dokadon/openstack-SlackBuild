========
Usage
========

To use python-solumclient in a project::

	import solumclient