=======================
 Horizon Release Notes
=======================

.. toctree::
   :maxdepth: 1

   unreleased
   pike
   ocata
   newton
   mitaka
   liberty
   kilo
   juno
   icehouse
   havana
   grizzly
   folsom
   essex

.. toctree::
   :maxdepth: 1

   Release Notes Howto <https://docs.openstack.org/horizon/latest/contributor/contributing.html#release-notes>
