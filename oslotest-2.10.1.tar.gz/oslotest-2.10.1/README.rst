=======================================================
 oslotest -- OpenStack Testing Framework and Utilities
=======================================================

The Oslo Test framework provides common fixtures, support for debugging, and
better support for mocking results.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/oslotest
* Source: http://git.openstack.org/cgit/openstack/oslotest
* Bugs: http://bugs.launchpad.net/oslotest
