Welcome to futurist's documentation!
========================================================

Code from the future, delivered to you in the **now**.

.. toctree::
   :maxdepth: 2

   user/index
   reference/index
   install/index
   contributor/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

