CLI Guide
=========

.. toctree::
   :maxdepth: 2

   freezer-agent
   freezer-scheduler


This chapter assumes a working setup of OpenStack following the
`OpenStack Installation Tutorial
<https://docs.openstack.org/queens/install/>`_.
