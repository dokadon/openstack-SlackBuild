===============================
 Ironic Inspector Release Notes
===============================

.. toctree::
   :maxdepth: 1

   Current (3.3.0 - unreleased) <current-series>
   Mitaka (2.3.0 - 3.2.x) <mitaka>
   Liberty (2.0.0 - 2.2.x) <liberty>


.. toctree::
   :hidden:

   unreleased
