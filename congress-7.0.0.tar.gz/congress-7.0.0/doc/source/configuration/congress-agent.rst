===================
congress-agent.conf
===================

.. show-options::
   :config-file: etc/congress-agent-config-generator.conf