==================
VPN Endpoint Group
==================

The **Endpoint Group** is used to configure multiple local and remote subnets
in vpnservice object.

Network v2

.. autoprogram-cliff:: openstack.neutronclient.v2
   :command: vpn endpoint group *
