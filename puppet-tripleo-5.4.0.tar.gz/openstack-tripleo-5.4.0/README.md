# puppet-tripleo

Lightweight composition layer for Puppet TripleO.
