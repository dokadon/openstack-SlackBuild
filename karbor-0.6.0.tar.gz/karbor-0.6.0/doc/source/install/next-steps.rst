.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the Karbor service.

To add more services, see the
`additional documentation on installing OpenStack <https://docs.openstack.org/#install-guides>`_ .

To learn more about the Karbor service, read the `Karbor developer documentation
<https://docs.openstack.org/karbor/latest/>`__.
