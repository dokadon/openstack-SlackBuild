To generate the sample policy.yaml file, run the following command from the top
level of the karbor directory:

    tox -egenpolicy
