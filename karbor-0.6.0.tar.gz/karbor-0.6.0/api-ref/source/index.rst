===================
Data Protection API
===================

Contents:

.. toctree::
    :maxdepth: 1

    v1/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
