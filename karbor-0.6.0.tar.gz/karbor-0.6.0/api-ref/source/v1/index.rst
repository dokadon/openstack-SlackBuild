:tocdepth: 2

======================
Data Protection API V1
======================

.. rest_expand_all::

.. include:: karbor-v1-protectables.inc
.. include:: karbor-v1-providers.inc
.. include:: karbor-v1-plans.inc
.. include:: karbor-v1-triggers.inc
.. include:: karbor-v1-scheduled-operations.inc
.. include:: karbor-v1-checkpoints.inc
.. include:: karbor-v1-restores.inc
.. include:: karbor-v1-operation-logs.inc
