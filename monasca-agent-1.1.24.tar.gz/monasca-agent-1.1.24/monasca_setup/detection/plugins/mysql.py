# (C) Copyright 2015,2016 Hewlett Packard Enterprise Development Company LP

import logging

import monasca_setup.agent_config
import monasca_setup.detection
from monasca_setup.detection.utils import find_process_name

log = logging.getLogger(__name__)

mysql_conf = '/root/.my.cnf'


class MySQL(monasca_setup.detection.Plugin):

    """Detect MySQL daemons and setup configuration to monitor them.

        This plugin needs user/pass infor for mysql setup, this is
        best placed in /root/.my.cnf in a format such as
        [client]
            user = root
            password = yourpassword
    """

    def _detect(self):
        """Run detection, set self.available True if the service is detected.

        """
        if find_process_name('mysqld') is not None:
            self.available = True

    def build_config(self):
        """Build the config as a Plugins object and return.

        """
        config = monasca_setup.agent_config.Plugins()
        # First watch the process
        config.merge(monasca_setup.detection.watch_process(['mysqld'], 'mysql'))
        log.info("\tWatching the mysqld process.")

        configured_mysql = False
        # Attempt login, requires either an empty root password from localhost
        # or relying on a configured /root/.my.cnf
        if self.dependencies_installed():  # ensures MySQLdb is available
            import _mysql_exceptions
            import MySQLdb
            try:
                MySQLdb.connect(read_default_file=mysql_conf)
                log.info(
                    "\tUsing client credentials from {:s}".format(mysql_conf))
                # Read the mysql config file to extract the needed variables.
                # While the agent mysql.conf file has the ability to read the
                # /root/.my.cnf file directly as 'defaults_file,' the agent
                # user would likely not have permission to do so.
                client_section = False
                my_user = None
                my_pass = None
                try:
                    with open(mysql_conf, "r") as confFile:
                        for row in confFile:
                            # If there are any spaces in confFile, remove them
                            row = row.replace(" ", "")
                            if client_section:
                                if "[" in row:
                                    break
                                if "user=" in row:
                                    my_user = row.split("=")[1].rstrip()
                                if "password=" in row:
                                    my_pass = row.split("=")[1].rstrip().strip("'")
                            if "[client]" in row:
                                client_section = True
                    config['mysql'] = {'init_config': None, 'instances':
                                       [{'name': 'localhost', 'server': 'localhost', 'port': 3306,
                                         'user': my_user, 'pass': my_pass}]}
                    configured_mysql = True
                except IOError:
                    log.error("\tI/O error reading {:s}".format(mysql_conf))
                    pass
            except _mysql_exceptions.MySQLError:
                log.warn("\tCould not connect to mysql using credentials from {:s}".format(mysql_conf))
                pass

            # Try logging in as 'root' with an empty password
            if not configured_mysql:
                try:
                    MySQLdb.connect(host='localhost', port=3306, user='root')
                    log.info("\tConfiguring plugin to connect with user root.")
                    config['mysql'] = {'init_config': None, 'instances':
                                       [{'name': 'localhost', 'server': 'localhost', 'user': 'root',
                                         'port': 3306}]}
                    configured_mysql = True
                except _mysql_exceptions.MySQLError:
                    log.warn("\tCould not connect to mysql using root user")
                    pass
        else:
            exception_msg = 'The mysql dependency MySQLdb is not installed;' \
                            ' the mysql plugin is not configured'
            log.error(exception_msg)
            raise Exception(exception_msg)

        if not configured_mysql:
            exception_msg = 'Unable to log into the mysql database;' \
                            ' the mysql plugin is not configured.'
            log.error(exception_msg)
            raise Exception(exception_msg)

        return config

    def dependencies_installed(self):
        try:
            import MySQLdb
        except ImportError:
            return False

        return True
