#!/bin/bash

echo "this is a test script file"
