=====
 API
=====

.. Use autodoc directives to describe the *public* modules and classes
   in the library.

   If the modules are completely unrelated, create an api subdirectory
   and use a separate file for each (see oslo.utils).

   If there is only one submodule, a single api.rst file like this
   sufficient (see oslo.i18n).
