============
Installation
============

At the command line::

    $ pip install brick-python-cinderclient-ext

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv brick-python-cinderclient-ext
    $ pip install brick-python-cinderclient-ext
