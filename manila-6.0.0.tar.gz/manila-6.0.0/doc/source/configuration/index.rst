=============
Configuration
=============

.. toctree::
   :maxdepth: 1

   shared-file-systems/overview
   shared-file-systems/api.rst
   shared-file-systems/drivers.rst
   shared-file-systems/log-files.rst
   shared-file-systems/config-options.rst
   shared-file-systems/samples/index.rst

The Shared File Systems service works with many different drivers that
you can configure by using these instructions.
