==========================================
Ocata Series (7.0.0 - 7.0.x) Release Notes
==========================================

.. release-notes::
   :branch: origin/stable/ocata
