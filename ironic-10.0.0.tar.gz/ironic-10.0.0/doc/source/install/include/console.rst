Configuring node web console
----------------------------

See :ref:`console`.

.. TODO(dtantsur): move the installation documentation here
