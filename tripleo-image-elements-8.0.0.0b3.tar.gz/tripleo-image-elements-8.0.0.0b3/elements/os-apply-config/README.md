Install os-apply-config.

The contents of os-apply-config subdirectory in templates will be installed
into the default template directory automatically.

An os-refresh-config hook is created to invoke os-apply-config automatically.
