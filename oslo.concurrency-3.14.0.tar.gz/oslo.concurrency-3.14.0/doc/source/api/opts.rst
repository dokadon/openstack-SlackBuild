==============================
 :mod:`oslo_concurrency.opts`
==============================

.. automodule:: oslo_concurrency.opts
  :members:
  :undoc-members:
  :show-inheritance:
