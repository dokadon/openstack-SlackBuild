===========
policy.yaml
===========

The ``policy.yaml`` file defines additional access controls
that apply to the Compute service.

.. literalinclude:: /_static/nova.policy.yaml.sample
   :language: yaml
