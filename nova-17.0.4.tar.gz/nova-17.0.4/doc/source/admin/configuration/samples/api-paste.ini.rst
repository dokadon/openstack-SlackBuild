=============
api-paste.ini
=============

The Compute service stores its API configuration settings in the
``api-paste.ini`` file.

.. literalinclude:: /../../etc/nova/api-paste.ini
