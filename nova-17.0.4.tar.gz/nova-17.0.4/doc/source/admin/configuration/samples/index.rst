==========================================
Compute service sample configuration files
==========================================

Files in this section can be found in ``/etc/nova``.

.. toctree::
   :maxdepth: 2

   api-paste.ini.rst
   policy.yaml.rst
   rootwrap.conf.rst
