=====================
Configuration Options
=====================

The following is an overview of all available configuration options in Nova.
For a sample configuration file, refer to :doc:`/configuration/sample-config`.

.. show-options::
   :config-file: etc/nova/nova-config-generator.conf
