========
Policies
========

The following is an overview of all available policies in Nova.  For a sample
configuration file, refer to :doc:`/configuration/sample-policy`.

.. show-policy::
   :config-file: etc/nova/nova-policy-generator.conf
