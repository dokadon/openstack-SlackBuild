Install and configure controller node
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This section describes how to install and configure the Compute service
on the controller node for Ubuntu, openSUSE and SUSE Linux Enterprise,
and Red Hat Enterprise Linux and CentOS.

.. toctree::

   controller-install-ubuntu.rst
   controller-install-obs.rst
   controller-install-rdo.rst
