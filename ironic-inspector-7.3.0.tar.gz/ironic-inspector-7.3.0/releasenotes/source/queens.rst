============================================
 Queens Series (6.1.0 - 7.2.x) Release Notes
============================================

.. release-notes::
   :branch: stable/queens
