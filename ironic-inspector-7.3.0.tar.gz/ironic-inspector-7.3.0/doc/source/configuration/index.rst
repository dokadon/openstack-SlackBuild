Configuration Guide
===================

The ironic-inspector service operation is defined by a configuration
file. The overview of configuration file options follow.

.. toctree::
  :maxdepth: 1

  Ironic Inspector Configuration Options <ironic-inspector>
  Sample Ironic Inspector Configuration <sample-config>
  Policies <policy>
  Sample policy file <sample-policy>


