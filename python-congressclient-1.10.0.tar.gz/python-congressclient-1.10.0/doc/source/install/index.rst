============
Installation
============

At the command line::

    $ pip install python-congressclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-congressclient
    $ pip install python-congressclient