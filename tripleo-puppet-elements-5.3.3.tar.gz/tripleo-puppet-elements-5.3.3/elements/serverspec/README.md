Install serverspec.

Supports gem based for now. Package mode will be eventually supported later.

To use gem:

 export DIB\_INSTALLTYPE\_serverspec=source

Configuration
-------------
None.
