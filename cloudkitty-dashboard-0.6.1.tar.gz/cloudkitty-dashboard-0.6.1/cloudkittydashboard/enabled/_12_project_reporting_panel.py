PANEL_GROUP = 'rating'
PANEL_DASHBOARD = 'project'
PANEL = 'reporting'

ADD_PANEL = \
    'cloudkittydashboard.dashboards.project.reporting.panel.Project_reporting'
