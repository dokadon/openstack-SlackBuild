(function () {
  'use strict';

  describe('horizon.dashboard.cloudkitty', function () {
    it('should be defined', function () {
      expect(angular.module('horizon.dashboard.cloudkitty')).toBeDefined();
    });
  });

})();
