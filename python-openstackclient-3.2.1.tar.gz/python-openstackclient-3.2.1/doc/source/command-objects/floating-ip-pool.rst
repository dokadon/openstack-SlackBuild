================
floating ip pool
================

Compute v2, Network v2

floating ip pool list
---------------------

List pools of floating IP addresses

.. program:: floating ip pool list
.. code:: bash

    os floating ip pool list
