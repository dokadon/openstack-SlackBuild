(function(){
'use strict';

    angular.module('horizon.dashboard.project.vitrage',['ui.bootstrap']);

})();
