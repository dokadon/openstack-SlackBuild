============
Installation
============

At the command line::

    $ pip install neutron-lib

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv neutron-lib
    $ pip install neutron-lib
