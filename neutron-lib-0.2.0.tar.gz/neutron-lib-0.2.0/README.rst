===============================
neutron-lib
===============================

Neutron shared routines and utilities

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/neutron-lib
* Source: http://git.openstack.org/cgit/openstack/neutron-lib
* Bugs: http://bugs.launchpad.net/neutron

Features
--------

* TODO
