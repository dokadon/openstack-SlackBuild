====================
Policy configuration
====================

Configuration
~~~~~~~~~~~~~

The following is an overview of all available policies in Keystone. For a sample
configuration file, refer to :doc:`samples/policy-yaml`.

.. show-policy::
   :config-file: ../../config-generator/keystone-policy-generator.conf
