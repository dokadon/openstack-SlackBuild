=============
keystone.conf
=============

Use the ``keystone.conf`` file to configure most Identity service
options:

.. literalinclude:: ../../_static/keystone.conf.sample
