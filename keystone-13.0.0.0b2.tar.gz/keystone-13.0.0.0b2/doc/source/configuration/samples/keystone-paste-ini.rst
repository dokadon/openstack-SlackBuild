==================
keystone-paste.ini
==================

Use the ``keystone-paste.ini`` file to configure the Web Service Gateway
Interface (WSGI) middleware pipeline for the Identity service:

.. literalinclude:: ../../../../etc/keystone-paste.ini
