===============
Advanced Topics
===============

.. toctree::
   :maxdepth: 2

   federation/federated_identity.rst

.. toctree::
   :maxdepth: 1

   configure_tokenless_x509.rst
   auth-totp.rst
   event_notifications.rst
   external-auth.rst
