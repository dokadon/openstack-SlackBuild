:tocdepth: 3

--------------------------------------
 Identity Admin API v2.0 (DEPRECATED)
--------------------------------------

.. rest_expand_all::

.. include:: admin-tenants.inc
.. include:: admin-tokens.inc
.. include:: admin-versions.inc
.. include:: admin-certificates.inc
