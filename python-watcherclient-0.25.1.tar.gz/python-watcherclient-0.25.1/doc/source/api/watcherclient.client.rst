The :mod:`watcherclient.client` Module
======================================

.. automodule:: watcherclient.client
  :members:
  :undoc-members:
  :show-inheritance:
