The :mod:`watcherclient.tests.v1.test_audit_template` Module
============================================================

.. automodule:: watcherclient.tests.v1.test_audit_template
  :members:
  :undoc-members:
  :show-inheritance:
