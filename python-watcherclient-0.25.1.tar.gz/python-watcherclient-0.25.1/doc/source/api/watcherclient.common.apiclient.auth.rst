The :mod:`watcherclient.common.apiclient.auth` Module
=====================================================

.. automodule:: watcherclient.common.apiclient.auth
  :members:
  :undoc-members:
  :show-inheritance:
