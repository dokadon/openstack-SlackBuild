The :mod:`watcherclient.tests.test_http` Module
===============================================

.. automodule:: watcherclient.tests.test_http
  :members:
  :undoc-members:
  :show-inheritance:
