The :mod:`watcherclient.shell` Module
=====================================

.. automodule:: watcherclient.shell
  :members:
  :undoc-members:
  :show-inheritance:
