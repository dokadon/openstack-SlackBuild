The :mod:`watcherclient.v1.shell` Module
========================================

.. automodule:: watcherclient.v1.shell
  :members:
  :undoc-members:
  :show-inheritance:
