The :mod:`watcherclient.v1.action_shell` Module
===============================================

.. automodule:: watcherclient.v1.action_shell
  :members:
  :undoc-members:
  :show-inheritance:
