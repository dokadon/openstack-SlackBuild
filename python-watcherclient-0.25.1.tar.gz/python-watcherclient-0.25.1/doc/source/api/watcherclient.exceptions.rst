The :mod:`watcherclient.exceptions` Module
==========================================

.. automodule:: watcherclient.exceptions
  :members:
  :undoc-members:
  :show-inheritance:
