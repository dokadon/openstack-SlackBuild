The :mod:`watcherclient.tests.v1.test_action_shell` Module
==========================================================

.. automodule:: watcherclient.tests.v1.test_action_shell
  :members:
  :undoc-members:
  :show-inheritance:
