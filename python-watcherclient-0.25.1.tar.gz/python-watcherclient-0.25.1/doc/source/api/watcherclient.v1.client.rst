The :mod:`watcherclient.v1.client` Module
=========================================

.. automodule:: watcherclient.v1.client
  :members:
  :undoc-members:
  :show-inheritance:
