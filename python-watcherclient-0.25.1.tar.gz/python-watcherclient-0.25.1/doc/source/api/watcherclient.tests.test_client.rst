The :mod:`watcherclient.tests.test_client` Module
=================================================

.. automodule:: watcherclient.tests.test_client
  :members:
  :undoc-members:
  :show-inheritance:
