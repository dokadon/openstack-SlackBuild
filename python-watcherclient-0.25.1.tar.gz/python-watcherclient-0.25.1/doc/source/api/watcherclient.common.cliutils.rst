The :mod:`watcherclient.common.cliutils` Module
===============================================

.. automodule:: watcherclient.common.cliutils
  :members:
  :undoc-members:
  :show-inheritance:
