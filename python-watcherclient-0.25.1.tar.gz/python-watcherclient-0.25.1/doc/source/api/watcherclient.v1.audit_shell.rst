The :mod:`watcherclient.v1.audit_shell` Module
==============================================

.. automodule:: watcherclient.v1.audit_shell
  :members:
  :undoc-members:
  :show-inheritance:
