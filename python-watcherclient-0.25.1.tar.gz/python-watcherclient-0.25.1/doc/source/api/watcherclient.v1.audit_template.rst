The :mod:`watcherclient.v1.audit_template` Module
=================================================

.. automodule:: watcherclient.v1.audit_template
  :members:
  :undoc-members:
  :show-inheritance:
