The :mod:`watcherclient.v1.goal_shell` Module
=============================================

.. automodule:: watcherclient.v1.goal_shell
  :members:
  :undoc-members:
  :show-inheritance:
