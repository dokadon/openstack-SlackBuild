The :mod:`watcherclient.v1.metric_collector_shell` Module
=========================================================

.. automodule:: watcherclient.v1.metric_collector_shell
  :members:
  :undoc-members:
  :show-inheritance:
