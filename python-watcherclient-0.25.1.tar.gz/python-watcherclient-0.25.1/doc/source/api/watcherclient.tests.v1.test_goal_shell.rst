The :mod:`watcherclient.tests.v1.test_goal_shell` Module
========================================================

.. automodule:: watcherclient.tests.v1.test_goal_shell
  :members:
  :undoc-members:
  :show-inheritance:
