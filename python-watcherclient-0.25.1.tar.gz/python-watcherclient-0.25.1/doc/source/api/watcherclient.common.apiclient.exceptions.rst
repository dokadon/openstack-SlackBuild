The :mod:`watcherclient.common.apiclient.exceptions` Module
===========================================================

.. automodule:: watcherclient.common.apiclient.exceptions
  :members:
  :undoc-members:
  :show-inheritance:
