The :mod:`watcherclient.tests.v1.test_metric_collector` Module
==============================================================

.. automodule:: watcherclient.tests.v1.test_metric_collector
  :members:
  :undoc-members:
  :show-inheritance:
