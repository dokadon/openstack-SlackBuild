The :mod:`watcherclient.common.http` Module
===========================================

.. automodule:: watcherclient.common.http
  :members:
  :undoc-members:
  :show-inheritance:
