The :mod:`watcherclient.tests.v1.test_audit_shell` Module
=========================================================

.. automodule:: watcherclient.tests.v1.test_audit_shell
  :members:
  :undoc-members:
  :show-inheritance:
