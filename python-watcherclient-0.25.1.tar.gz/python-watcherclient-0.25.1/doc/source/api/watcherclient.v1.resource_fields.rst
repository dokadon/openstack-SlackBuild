The :mod:`watcherclient.v1.resource_fields` Module
==================================================

.. automodule:: watcherclient.v1.resource_fields
  :members:
  :undoc-members:
  :show-inheritance:
