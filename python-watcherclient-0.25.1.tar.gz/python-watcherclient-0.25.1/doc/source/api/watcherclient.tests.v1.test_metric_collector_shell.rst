The :mod:`watcherclient.tests.v1.test_metric_collector_shell` Module
====================================================================

.. automodule:: watcherclient.tests.v1.test_metric_collector_shell
  :members:
  :undoc-members:
  :show-inheritance:
