The :mod:`watcherclient.tests.test_shell` Module
================================================

.. automodule:: watcherclient.tests.test_shell
  :members:
  :undoc-members:
  :show-inheritance:
