The :mod:`watcherclient.common.apiclient.base` Module
=====================================================

.. automodule:: watcherclient.common.apiclient.base
  :members:
  :undoc-members:
  :show-inheritance:
