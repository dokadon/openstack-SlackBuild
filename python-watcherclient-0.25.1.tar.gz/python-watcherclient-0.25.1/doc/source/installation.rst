============
Installation
============

If you have `virtualenvwrapper <https://virtualenvwrapper.readthedocs.org/en/latest/install.html>`_   installed::

    $ mkvirtualenv python-watcherclient
    $ git clone https://git.openstack.org/openstack/python-watcherclient
    $ cd python-watcherclient && python setup.py install
    $ pip install -r ./requirements.txt
