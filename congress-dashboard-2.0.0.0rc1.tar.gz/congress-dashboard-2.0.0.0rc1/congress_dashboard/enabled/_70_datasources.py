PANEL = 'datasources'
PANEL_DASHBOARD = 'admin'
PANEL_GROUP = 'policy'
ADD_PANEL = 'congress_dashboard.datasources.panel.DataSources'
AUTO_DISCOVER_STATIC_FILES = True
