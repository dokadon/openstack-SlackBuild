.. _contributing:

=======================
Contribution Guide
=======================

.. include:: ../../../CONTRIBUTING.rst

Project Hosting Details
-------------------------

Bug tracker
    https://launchpad.net/congress

Code Hosting
    https://git.openstack.org/cgit/openstack/congress-dashboard

Code Review
    https://review.openstack.org/#/q/status:open+project:openstack/congress-dashboard,n,z

