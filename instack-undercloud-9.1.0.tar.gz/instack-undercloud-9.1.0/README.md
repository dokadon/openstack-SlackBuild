Team and repository tags
========================

[![Team and repository tags](https://governance.openstack.org/tc/badges/instack-undercloud.svg)](https://governance.openstack.org/tc/reference/tags/index.html)

<!-- Change things from this point on -->

Undercloud Install via instack
==============================

instack-undercloud is tooling for installing a TripleO undercloud.

It is part of the TripleO project:
https://docs.openstack.org/tripleo-docs/latest/

* Free software: Apache license
* Source: https://git.openstack.org/cgit/openstack/instack-undercloud
* Bugs: https://bugs.launchpad.net/tripleo
