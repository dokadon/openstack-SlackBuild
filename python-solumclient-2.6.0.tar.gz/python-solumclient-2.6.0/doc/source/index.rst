================================
python-solumclient documentation
================================

This is a client for the OpenStack Application Lifecycle Management API.
There's a Python API (the :mod:`solumclient` module) and a
:doc:`command-line script <cli/solum>` (installed as :program:`solum`).

.. toctree::
   :maxdepth: 2

   cli/index
