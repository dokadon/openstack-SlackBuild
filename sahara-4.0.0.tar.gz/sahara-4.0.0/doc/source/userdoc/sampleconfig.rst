Sample sahara.conf file
=======================

This is an automatically generated sample of the sahara.conf file.

.. literalinclude:: ../sample.config
   :language: ini
   :linenos:
