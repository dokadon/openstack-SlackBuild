=====================
Sahara files for EDP
=====================

All files from this directory have been moved to new
sahara-scenario repository: https://github.com/openstack/sahara-scenario
