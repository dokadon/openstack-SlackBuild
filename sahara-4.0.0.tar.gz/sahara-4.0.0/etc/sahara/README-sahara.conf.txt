To generate the sample sahara.conf file, run the following
command from the top level of the sahara directory:

tox -e genconfig
