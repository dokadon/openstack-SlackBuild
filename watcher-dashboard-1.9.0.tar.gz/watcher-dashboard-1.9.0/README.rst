========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/watcher-dashboard.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

OpenStack Dashboard plugin for Watcher project
==============================================

The Watcher dashboard is a Horizon plugin that will allow users to realize a
wide range of cloud optimization goals.

* Free software: Apache license
* Documentation: https://docs.openstack.org/watcher-dashboard/latest
* Source: https://git.openstack.org/cgit/openstack/watcher-dashboard
* Bugs: https://bugs.launchpad.net/watcher-dashboard
