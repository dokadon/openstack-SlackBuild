Element to install an Octavia Amphora agent.


