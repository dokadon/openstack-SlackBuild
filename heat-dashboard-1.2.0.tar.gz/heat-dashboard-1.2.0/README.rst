==========================
Welcome to Heat Dashboard!
==========================

Heat dashboard is a horizon plugin for Heat.

* License: Apache license
* Documentation: https://docs.openstack.org/heat-dashboard/latest/
* Source: https://git.openstack.org/cgit/openstack/heat-dashboard
* Bugs: https://bugs.launchpad.net/heat-dashboard

Team and repository tags
------------------------

.. image:: https://governance.openstack.org/tc/badges/heat-dashboard.svg
    :target: http://governance.openstack.org/reference/tags/index.html
