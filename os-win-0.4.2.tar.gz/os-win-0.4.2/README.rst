===============================
os-win
===============================

Windows / Hyper-V library for OpenStack projects.

Library contains Windows / Hyper-V code commonly used in the OpenStack
projects: nova, cinder, networking-hyperv. The library can be used in any
other OpenStack projects where it is needed.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/os-win
* Source: http://git.openstack.org/cgit/openstack/os-win
* Bugs: http://bugs.launchpad.net/os-win

Features
--------

* TODO
