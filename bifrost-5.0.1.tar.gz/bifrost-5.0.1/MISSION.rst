Bifrost's Mission
~~~~~~~~~~~~~~~~~

The mission of bifrost is to provide an easy path to deploy ironic in
a stand-alone fashion, in order to help facilitate the deployment of
infrastucture. While being a configurable project that can consume
other OpenStack components to allow users to easily customize the
environment to fit there needs, and drive forward the stand-alone
perspective.
