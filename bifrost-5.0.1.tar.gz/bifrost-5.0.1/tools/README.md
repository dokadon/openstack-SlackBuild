Tools
=====

This directory contains some tooling for local developer testing, such as
vagrant config files or libvirt templates.

These are not intended for production use.
