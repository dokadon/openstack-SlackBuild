##################
Bifrost User Guide
##################

As bifrost is primarilly intended to be a tool for use by administrators,
this documentation serves as a blend of both Admin and User documentation.

.. toctree::
   :maxdepth: 1

   vagrant
   virsh
   howto
   troubleshooting

