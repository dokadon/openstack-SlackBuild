import pbr.version

version_info = pbr.version.VersionInfo('zaqar-ui')
