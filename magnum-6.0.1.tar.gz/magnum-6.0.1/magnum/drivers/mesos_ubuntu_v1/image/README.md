Mesos elements
==============

See [Building an image](http://docs.openstack.org/developer/magnum/userguide.html#building-mesos-image) for instructions.
