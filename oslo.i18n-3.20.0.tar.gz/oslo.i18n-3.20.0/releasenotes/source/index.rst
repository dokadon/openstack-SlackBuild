=========================
 oslo.i18n Release Notes
=========================

 .. toctree::
    :maxdepth: 1

    unreleased
    queens
    pike
    ocata
