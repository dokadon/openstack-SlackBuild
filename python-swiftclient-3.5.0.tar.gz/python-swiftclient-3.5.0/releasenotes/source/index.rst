============================
 Swift Client Release Notes
============================

.. toctree::
   :maxdepth: 1

   current
   pike
   ocata
   newton
